﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackTestUtilityApplication
{
    public class Position
    {
        public String client_id = "";
        public String average_buy_price = "";
        public String average_sell_price = "";

        public String buy_quantity = "";
        public String sell_quantity = "";
        public String instrument_token = "";
        public String realized_mtm = "";
        public String exchange = "";
        public String ltp = "";
        public String previous_close = "";
        public String quantity = "";
        public String symbol = "";
        public String token = "";
        public String trading_symbol = "";


    }
    class RichPosition
    {
        String BaseURL = RichUI.BaseURL;
        public Dictionary<String, Position> AllLivenHistoricalPosition = new Dictionary<string, Position>();
        public Dictionary<String, Position> getLivePosition(String AuthToken, String ClientID)
        {
           // AllLivenHistoricalPosition.Clear();
            var client = new RestClient(BaseURL+"/api/v1/positions?type=live&client_id=" + ClientID);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", ClientID);
            //request.AddHeader("Authorization", "Bearer bW48NCDYxN2mEUCljO-bsBqhXvtyx36adAHQ21a9PSE.Y8IUXB4AJwY-EuVLt3SVXsneKtKotr9ebK6OniLK9Tc");
            request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYYVNmdG5jMnBiRDRudlZaZVhWS201ZV82.76EqMgJrrA3ul87MW_cNdcXkOKCGmlm6M0NFpUBrNz0; oauth2_authentication_csrf=MTU4OTYxNzc3OHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFpsT1dOak56RTROakJpTVRRNE16TmlPR1l3TWpFNU9ERmlaV1ExTnpoanw5AGewzQLK8J_G8JUYjaO3t-p-sw1k4I1X_h7THj7jlQ==; oauth2_consent_csrf=MTU4OTYxNzc4N3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRGxoWVRGbU5qSmhORFZsWkRReE16UTRNMkUzTnpBeU1HTmtNemc1TWpKbHweb7i8mSR2m5xyT1Pa3upYztfk66Esnv2Cmioi5Gppaw==");
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
               
                foreach (dynamic item in data.data)
                {
                    try
                    {
                        Position Obj = new Position();

                        dynamic client_idP = item.client_id;
                        dynamic average_buy_price = item.average_buy_price;
                        dynamic average_sell_price = item.average_sell_price;
                        dynamic buy_quantity = item.buy_quantity;
                        dynamic sell_quantity = item.sell_quantity;
                        dynamic instrument_token = item.instrument_token;
                        dynamic realized_mtm = item.realized_mtm;
                        dynamic exchange = item.exchange;
                        dynamic ltp = item.ltp;
                        dynamic previous_close = item.previous_close;
                        dynamic quantityP = item.net_quantity;
                        dynamic symbolP = item.symbol;
                        dynamic tokenP = item.token;
                        dynamic trading_symbol = item.trading_symbol;

                        Obj.client_id = client_idP.ToString();
                        Obj.average_buy_price = average_buy_price.ToString();
                        Obj.average_sell_price = average_sell_price.ToString();
                        Obj.buy_quantity = buy_quantity.ToString();
                        Obj.sell_quantity = sell_quantity.ToString();
                        Obj.instrument_token = instrument_token.ToString();
                        Obj.realized_mtm = realized_mtm.ToString();

                        Obj.exchange = exchange.ToString();
                        Obj.ltp = ltp.ToString();
                        Obj.previous_close = previous_close.ToString();
                        Obj.quantity = quantityP.ToString();
                        Obj.symbol = symbolP.ToString();
                        Obj.token = tokenP.ToString();
                        Obj.trading_symbol = trading_symbol.ToString();
                        AllLivenHistoricalPosition.Add(Obj.trading_symbol, Obj);
                    }
                    catch (Exception jhjk)
                    {
                    }

                }
            }
            return AllLivenHistoricalPosition;
        }
        public Dictionary<String, Position> getHistoricalPosition(String AuthToken, String ClientID)
        {
           // AllLivenHistoricalPosition.Clear();
            var client = new RestClient(BaseURL + "/api/v1/positions?type=historical&client_id=" + ClientID);
            
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", ClientID);
            //request.AddHeader("Authorization", "Bearer bW48NCDYxN2mEUCljO-bsBqhXvtyx36adAHQ21a9PSE.Y8IUXB4AJwY-EuVLt3SVXsneKtKotr9ebK6OniLK9Tc");
            request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYYVNmdG5jMnBiRDRudlZaZVhWS201ZV82.76EqMgJrrA3ul87MW_cNdcXkOKCGmlm6M0NFpUBrNz0; oauth2_authentication_csrf=MTU4OTYxNzc3OHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFpsT1dOak56RTROakJpTVRRNE16TmlPR1l3TWpFNU9ERmlaV1ExTnpoanw5AGewzQLK8J_G8JUYjaO3t-p-sw1k4I1X_h7THj7jlQ==; oauth2_consent_csrf=MTU4OTYxNzc4N3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRGxoWVRGbU5qSmhORFZsWkRReE16UTRNMkUzTnpBeU1HTmtNemc1TWpKbHweb7i8mSR2m5xyT1Pa3upYztfk66Esnv2Cmioi5Gppaw==");
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
                
                foreach (dynamic item in data.data)
                {
                    try
                    {
                        Position Obj = new Position();

                        dynamic client_idP = item.client_id;
                        dynamic average_buy_price = item.average_buy_price;
                        dynamic average_sell_price = item.average_sell_price;
                        dynamic buy_quantity = item.buy_quantity;
                        dynamic sell_quantity = item.sell_quantity;
                        dynamic instrument_token = item.instrument_token;
                        dynamic realized_mtm = item.realized_mtm;
                        dynamic exchange = item.exchange;
                        dynamic ltp = item.ltp;
                        dynamic previous_close = item.previous_close;
                        dynamic quantityP = item.net_quantity;
                        dynamic symbolP = item.symbol;
                        dynamic tokenP = item.token;

                        Obj.client_id = client_idP.ToString();
                        Obj.average_buy_price = average_buy_price.ToString();
                        Obj.average_sell_price = average_sell_price.ToString();
                        Obj.buy_quantity = buy_quantity.ToString();
                        Obj.sell_quantity = sell_quantity.ToString();
                        Obj.instrument_token = instrument_token.ToString();
                        Obj.realized_mtm = realized_mtm.ToString();

                        Obj.exchange = exchange.ToString();
                        Obj.ltp = ltp.ToString();
                        Obj.previous_close = previous_close.ToString();
                        Obj.quantity = quantityP.ToString();
                        Obj.symbol = symbolP.ToString();
                        Obj.token = tokenP.ToString();

                        AllLivenHistoricalPosition.Add(Obj.symbol, Obj);
                    }
                    catch (Exception jhjk)
                    {
                    }

                }
            }
            return AllLivenHistoricalPosition;
        }

    }
}

﻿namespace BackTestUtilityApplication
{
    public class AddStrategyToolStripMenuItem
    {
    }
}
﻿using Nancy;
using Nancy.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Diagnostics;
using System.IO;

namespace BackTestUtilityApplication
{
    public partial class Login : Form
    {
        
        String Host = RichUI.Host;
        String BaseURL =RichUI.BaseURL;
      
        String loginURL = "/api/v1/user/login";
        String TwoFAuthURL = "/api/v1/user/twofa";
        static String FirstToken = "";
        public static String OAuthToken = "";
        public static String ClientID = "";
        public static String Password = "";
        public static String TFA = "";
        public String Allwed = "NA";

        public Login(String allowedString)
        {
            InitializeComponent();
            Allwed = allowedString;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
           // mainWindow = new MainWindow(loginID, "a");
            //this.Close();
            //mainWindow.Show();
        }

       
       
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Process proc = null;
            try
            {
                string batDir = string.Format(@"C:\MasterRest\");
                proc = new Process();
                proc.StartInfo.WorkingDirectory = batDir;
                proc.StartInfo.FileName = "acessTokenGenerator.bat";
                proc.StartInfo.CreateNoWindow = true;
                proc.Start();
               // proc.Kill();
                proc.WaitForExit();
                //MessageBox.Show("Bat file executed !!");
            }
            catch (Exception efd)
            { 
            }
            this.Focus();
            this.BringToFront();
            string path = @"C:\MasterRest\oauth\chromedriver_win32\Login.txt";

            string[] readText = File.ReadAllLines(path);
            foreach (string s in readText)
            {
                String[] data = s.Split(',');
                OAuthToken = data[5];
            }
     
            Update();



            this.Visible = false;
            this.Enabled = false;
        }

      

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {
           
            
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Allwed = "NA";
            if (Allwed.Equals("NA") || Allwed.Equals(txtUsername.Text))
            {
                var client = new RestClient(BaseURL + loginURL);
                var request = new RestRequest(Method.POST);
                request.AddHeader("x-device-type", "WEB");
                request.AddParameter("device", "WEB");
                request.AddParameter("login_id", txtUsername.Text);
                request.AddParameter("password", txtPassword.Text);
                IRestResponse response = client.Execute(request);
                String token = "";
                try
                {
                    dynamic resp = JObject.Parse(response.Content);
                    dynamic tokendata = resp.data;
                    dynamic tokenObject = tokendata.twofa_token;
                    token = tokenObject.Value;
                    FirstToken = token;
                    btnNext.Enabled = false;
                    //Console.WriteLine("Initial Login Sucessfully . Token: " + token);
                    // Console.WriteLine();
                    //Console.WriteLine();
                }
                catch (Exception efgh)
                {
                    MessageBox.Show("Invalid Client ID Or Password:");

                }
            }
            else
            {
                MessageBox.Show("license Allowed for " + Allwed +" Only.");
            }
           
        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            DateTime ds = DateTime.Now;
            Int32 date = Int32.Parse(ds.ToString("dd"));
            Int32 month = Int32.Parse(ds.ToString("MM"));
            Int32 year = Int32.Parse(ds.ToString("yyyy"));


           // if (date <= 16 && month <= 10 && year == 2020)
            //{ 

                var client = new RestClient(BaseURL + TwoFAuthURL);
            var request = new RestRequest(Method.POST);

            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Content-Length", "326");
            request.AddHeader("Accept-Encoding", "gzip, deflate");
            // request.AddHeader("Host", "masterswift-beta.mastertrust.co.in");
            request.AddHeader("Host", Host);

            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.20.1");
            request.AddHeader("X-Device-Type", "web");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("undefined", "{\r\n    \"login_id\": \"" + txtUsername.Text + "\",\r\n    \"twofa\": [\r\n        {\r\n            \"question_id\": 1,\r\n            \"answer\": \"" + txtYearOfBirth.Text + "\"\r\n        }\r\n    ],\r\n    \"twofa_token\": \"" + FirstToken + "\"\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            String Authtoken = "";
            try
            {
                dynamic respNEW = JObject.Parse(response.Content);
                dynamic tokendataNEW = respNEW.data;
                dynamic authToken = tokendataNEW.auth_token;
                Authtoken = authToken.Value;
                OAuthToken = Authtoken;
                ClientID = txtUsername.Text;
                Password = txtPassword.Text;
                TFA = txtYearOfBirth.Text;

                this.Close();
                //Console.WriteLine("Login Sucessfully With 2FA. Auth Token: " + Authtoken);
                //Console.WriteLine();
                //Console.WriteLine();
            }
            catch (Exception egfd)
            {
                MessageBox.Show("Invalid Client ID, Password or TFA:");
                btnNext.Enabled = true;
                //Console.WriteLine("Login Failed.." + e.StackTrace);
                //Console.WriteLine();
                //Console.WriteLine();
            }
        }
       // }
    }
}

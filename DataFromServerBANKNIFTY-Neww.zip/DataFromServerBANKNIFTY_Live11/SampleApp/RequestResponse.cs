﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackTestUtilityApplication
{
    public class RequestResponse
    {
        public RequestResponse()
        {
            
        }
        IRestResponse response;
        RestRequest request;
        Method method;
        RestClient restClient;
        public IRestResponse ProcessReq(String URL,RestRequest request, Method method)
        {
            restClient = new RestClient(URL);
            request = new RestRequest(method);
            response = restClient.Execute(request);
            return response;
        }
    }
}

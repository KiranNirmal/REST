﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackTestUtilityApplication
{

    public partial class RichUI : Form
    {
        public String FileSytem = "";
         public String FromMailID = "piyushsojitra386@gmail.com";
         public String FromMailIDPassword = "Piyush@221";
         public String ToMailID = "piyushsojitra386@gmail.com";
        public String UniquePC = "NA";
        public String ClientOrderID = "0";

        private delegate void SafeCallDelegate(string text);
        public Boolean StartNow = true;
        public CustomMarketData custMarketDataObject = new CustomMarketData();
        public static String BaseURL = "https://masterswift-beta.mastertrust.co.in";
        static String mainURL = "https://masterswift-beta.mastertrust.co.in";
        String orderPlaceURL = mainURL + "/api/v1/orders";
        public static String loginURL = "/api/v1/user/login";
        public static String TwoFAuthURL = "/api/v1/user/twofa";
        public static String Host = "masterswift-beta.mastertrust.co.in";
        public Dictionary<String, Int32> NIFTYFIFTY = new Dictionary<string, Int32>();
        public Dictionary<Int32, StrategyDetailsORB> StratgeysORB = new Dictionary<Int32, StrategyDetailsORB>();
        Thread StartStrategy_Thread;
        //public static String BaseURL = "http://uat.tradelab.in";
        //public static String Host = "uat.tradelab.in";
        public Double TotalMtM = 0;
        public Int32 Timeout = 10;
        public String AllowedAccount = "NA";
        // public String exchange = "NSE-NFO";

        //public static String OAuthAcessToken = "";
        public Boolean start = false;
        public String Historical_Data_Base_URL = "https://masterswift.mastertrust.co.in/api/v1/charts/tdv";
        public Dictionary<String, String> DicClientTokens = new Dictionary<string, String>();
        public Dictionary<String, Int32> NSE_OTH = new Dictionary<string, int>();
        public Dictionary<String, Int32> NSE_IND = new Dictionary<string, int>();
        public Dictionary<String, Int32> NSE = new Dictionary<string, int>();
        public Dictionary<String, Int32> NSE_OPT = new Dictionary<string, int>();
        public Dictionary<String, Int32> NSE_FUT = new Dictionary<string, int>();
        public Dictionary<Int32, Int32> NSE_OPT_LOTSize = new Dictionary<int, int>();
        public Dictionary<Int32, Int32> NSE_FUT_LOTSize = new Dictionary<int, int>();

        public Dictionary<Int32, Int32> MCX_FUT_LOTSize = new Dictionary<int, int>();

        public Dictionary<String, Int32> MCX = new Dictionary<string, int>();
        public List<String> ScriptList = new List<string>();

        public Dictionary<String, StrategyDetails> strategyDetailsALL = new Dictionary<string, StrategyDetails>();
        //  public Dictionary<Int32, StrategyDetails> Stratgeys = new Dictionary<Int32, StrategyDetails>();

        public Dictionary<String, SymbolDetails> NIFTYSYMBOL = new Dictionary<string, SymbolDetails>();
        public Dictionary<String, SymbolDetails> BANKNIFTYSYMBOL = new Dictionary<string, SymbolDetails>();
        public Dictionary<String, SymbolDetails> EXPECTED_SYMBOL = new Dictionary<string, SymbolDetails>();
        public static Dictionary<Int32, CustomMarketdataVALUES> MarketDataDictionary = new Dictionary<int, CustomMarketdataVALUES>();
        //  public static Dictionary<Int32, FullMarketTick> OIMarketDataDictionary = new Dictionary<int, FullMarketTick>();
        public Boolean IsDownload = true;
        public Int32 SID = 0;
        public Int32 AutologinCount = 0;
        public Int32 UOID = 100;
        //Thread THupdateWatchWatch;
        //Thread THupdateTradeBook;
        //Thread THUpdateOrderBook;
        //Thread ThStrategyThread;
        Thread StartStrategy_Thread_New;
        public double HIGH = 0;
        public double LOW = 0;
        public double OPEN = 0;
        public double CLOSE = 0;
        public Int32 TOKEN = 0;

        String FilePath = "";
        public Double plORB = 0;

        /*     public Int64 CandleStartTimeUNIXORB = 0;
             public Int64 CandleEndTimeUNIXORB = 0;
             public Int32 CandleDurationORB = 0;
             DateTime candleStartORB;
             DateTime candleEndORB;
             Int32 CandleStartIntegerORB = 0;
             Int32 CandleEndIntegerORB = 0;*/


        List<String> OrderBookList = new List<string>();
        List<String> TradeBookList = new List<string>();
        public String ExchnageEnable = "NSE-NFO-MCX";
        // public String ExchnageEnable = "NSE-MCX";
        private int TargetORB;
        private int StoplossORB;

        public RichUI()
        {
            InitializeComponent();

        }
        private void Autologin(String clientIDA, String passwordA, String TFAA)
        {
            var client = new RestClient(BaseURL + loginURL);
            var request = new RestRequest(Method.POST);
            request.AddHeader("x-device-type", "WEB");
            request.AddParameter("device", "WEB");
            request.AddParameter("login_id", clientIDA);
            request.AddParameter("password", passwordA);
            IRestResponse response = client.Execute(request);
            SubscribeFeedALL();
            sendmessage("Subscribed Auto Feed Successfully.", 0);
            String token = "";
            try
            {
                dynamic resp = JObject.Parse(response.Content);
                dynamic tokendata = resp.data;
                dynamic tokenObject = tokendata.twofa_token;
                token = tokenObject.Value;
                String FirstToken = token;

                client = new RestClient(BaseURL + TwoFAuthURL);
                request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("Connection", "keep-alive");
                request.AddHeader("Content-Length", "326");
                request.AddHeader("Accept-Encoding", "gzip, deflate");
                // request.AddHeader("Host", "masterswift-beta.mastertrust.co.in");
                request.AddHeader("Host", Host);

                request.AddHeader("Cache-Control", "no-cache");
                request.AddHeader("Accept", "*/*");
                request.AddHeader("User-Agent", "PostmanRuntime/7.20.1");
                request.AddHeader("X-Device-Type", "web");
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("undefined", "{\r\n    \"login_id\": \"" + clientIDA + "\",\r\n    \"twofa\": [\r\n        {\r\n            \"question_id\": 1,\r\n            \"answer\": \"" + TFAA + "\"\r\n        }\r\n    ],\r\n    \"twofa_token\": \"" + FirstToken + "\"\r\n}", ParameterType.RequestBody);
                response = client.Execute(request);
                String Authtoken = "";
                try
                {
                    dynamic respNEW = JObject.Parse(response.Content);
                    dynamic tokendataNEW = respNEW.data;
                    dynamic authToken = tokendataNEW.auth_token;
                    Authtoken = authToken.Value;
                    String OAuthToken = Authtoken;
                    //  OAuthAcessToken = OAuthToken;
                    sendmessage("AutoLogin Successfully.", 0);
                    SubscribeFeedALL();
                    sendmessage("Subscribed Auto Feed Successfully.", 0);

                }
                catch (Exception egfd)
                {
                    //MessageBox.Show("Invalid Client ID, Password or TFA:");
                    sendmessage("AutoLogin Failed .Error:" + response.Content, 0);

                }




            }
            catch (Exception efgh)
            {
                // MessageBox.Show("Invalid Client ID Or Password:");

            }

        }

        private void SubscribeFeedALL()
        {
            try
            {
                foreach (var item in StratgeysORB)
                {
                    custMarketDataObject.Subscribe(item.Value.ExchangeCode, item.Value.IntumentToken);
                }
               // custMarketDataObject.Subscribe(1, 26000);
                //custMarketDataObject.Subscribe(1, 26009);

            }
            catch (Exception edf)
            {
            }
        }

        private void KryptonButton1_Click(object sender, EventArgs e)
        {
           // StartNow = true;
            if (DicClientTokens.Count == 0)
            {
                MessageBox.Show("Login Clients First.");
            }
            else
            {
                try
                {
                    DownloadTokens();
                    //  StartStrategyThread();
                }
                catch (Exception sdfgh)
                {
                }
                // StartMarketWatchThread();
                btnStart.Enabled = false;
                FilePath = Directory.GetCurrentDirectory() + "\\OHLC.CSV";

                try
                {
                    String OHLCBaseURPATH = Directory.GetCurrentDirectory() + "\\Config.krt";
                    var reader = new StreamReader(File.OpenRead(OHLCBaseURPATH));
                    String lineHeader = reader.ReadLine();
                    if (!lineHeader.Trim().Equals(""))
                    {
                        Historical_Data_Base_URL = lineHeader;
                        sendmessage("Base URL:" + Historical_Data_Base_URL, 0);
                    }
                    else
                    {
                        sendmessage("Base URL:" + Historical_Data_Base_URL, 0);
                    }
                }
                catch (Exception sdf)
                {
                    sendmessage("Base URL:" + Historical_Data_Base_URL, 0);
                }


                try
                {
                    //Reading Existing Portfolio
                    if (!File.Exists(FilePath))
                    {
                        File.Create(FilePath);
                    }

                    string[] lines = System.IO.File.ReadAllLines(FilePath);
                    foreach (string line in lines)
                    {
                        try
                        {
                            string[] columns = line.Split(',');
                            StrategyDetails sd = new StrategyDetails();
                            sd.SID = Int32.Parse(columns[0]);
                            sd.Side = columns[1];
                            sd.Lot = Int32.Parse(columns[2]);
                            sd.Symbol = columns[3];
                            sd.StartPrice = Double.Parse(columns[4]);
                            sd.TotalStep = Double.Parse(columns[5]);
                            sd.StepDiff = Double.Parse(columns[6]);
                            sd.Target = Double.Parse(columns[7]);
                            sd.Stoploss = Double.Parse(columns[8]);
                            sd.Product = columns[9];
                            sd.IntumentToken = Int32.Parse(columns[10]);
                            Int32 exe = 0;
                            sd.Exchange = columns[13];
                            if (sd.Exchange.Equals("NSE"))
                            {
                                exe = 1;
                            }
                            else if (sd.Exchange.Equals("NFO"))
                            {
                                exe = 2;
                            }
                            else if (sd.Exchange.Equals("MCX"))
                            {
                                exe = 4;
                            }
                            sd.ExchangeCode = exe;
                            try
                            {
                                custMarketDataObject.Subscribe(sd.ExchangeCode, sd.IntumentToken);

                            }
                            catch (Exception asdf)
                            {
                            }


                            sd.Account = columns[14];
                            sd.Status = columns[15];
                            //KryptonDGV.Rows.Add(sd.SID, sd.Account,sd.Status, sd.Symbol, sd.SymbolLTP, sd.Side, sd.Lot, sd.StartPrice, sd.TotalStep, sd.StepDiff, sd.Target, sd.Stoploss, sd.Position, sd.MTM);

                            // Stratgeys.Add(SID, sd);
                            SID = SID + 1;
                            sendmessage(sd.Symbol + " Script Added Successfully..", 0);

                        }
                        catch (Exception wed)
                        {

                        }

                    }



                }
                catch (Exception error)
                {
                }

               
                /* try
                 {
                     StartSave();
                 }
                 catch (Exception edf)
                 {
                 }*/

            }

        }
        private async void StartSave()
        {
            /* while (true)
             {
                 await SaveStrategy();
             }*/
        }
        private async Task<string> SaveStrategy()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(FilePath))
                {
                    writer.WriteLine("SID,SIDE,LOT,SYMBOL,STARTPRICE,TOTALSTEP,SETPDIFF,TARGET,STOPLOSS,PRDTYPE,TOKEN,STEPDETAILS,STEPOID,EXCHANGE,ACCOUNT");
                    // writer.WriteLine("Script,ClientID,NextDay,script,Counter,MTM,StartDate,Token");
                    foreach (var item in StratgeysORB)
                    {
                        Int32 SID = item.Key;
                        StrategyDetailsORB sd = item.Value;
                        String StepDetails = "";
                        /*  foreach (var sp in sd.StepLevel)
                          {
                              StepDetails = StepDetails + sp.Key.ToString() + "@" + sp.Value.ToString() + "#";
                          }
                          String StepOIDs = "";
                          foreach (var sp in sd.StepLevelOID)
                          {
                              StepOIDs = StepOIDs + sp.Key.ToString() + "@" + sp.Value.ToString() + "#";
                          }
                          writer.WriteLine(SID.ToString() + "," + sd.Side + "," + sd.Lot.ToString() + "," + sd.Symbol + "," + sd.StartPrice.ToString() + "," + sd.TotalStep.ToString()
                              + "," + sd.StepDiff.ToString() + "," + sd.Target.ToString() + "," + sd.Stoploss.ToString() + "," + sd.Product + "," + sd.IntumentToken.ToString() + "," + StepDetails + "," + StepOIDs + "," + sd.Exchange + "," + sd.Account+","+sd.Status);
                  */
                    }
                }
            }
            catch (Exception sdfghjk)
            {
            }

           // await Task.Delay(5000);
            return DateTime.Now.Ticks.ToString();
        }

        private async void StartMarketWatchThread()
        {
            while (true)
            {
                await StartMarketW();
            }

        }
        private async Task<string> StartMarketW()
        {
/*
            foreach (DataGridViewRow row in KryptonMarketWatch.Rows)
            {
                try
                {
                    String exchange = row.Cells["V_Exe"].Value.ToString();
                    String symbol = row.Cells["V_Sym"].Value.ToString();
                    String token = row.Cells["V_Token"].Value.ToString();
                    CustomMarketdataVALUES data = MarketDataDictionary[Int32.Parse(token)];

                    Double Newbid = 0, NewbidQ = 0, Newask = 0, NewaskQ = 0, Newltq = 0;

                    Double Newltp = 0;
                    Newbid = data.BestBidPrice;
                    NewbidQ = data.BestBidQty;
                    Newask = data.BestAskPrice;
                    NewaskQ = data.BestAskQty;
                    Newltp = data.LastTradedPrice;
                    Newltq = data.LastTradeQty;

                    Double bid = 0, bidQ = 0, ask = 0, askQ = 0, ltp = 0, ltq = 0;

                    // String bidString = row.Cells["V_Bid"].ToString();
                    *//* bid = Double.Parse(row.Cells["V_Bid"].Value.ToString());
                     bidQ = Double.Parse(row.Cells["V_BidQ"].Value.ToString());
                     ask = Double.Parse(row.Cells["V_Ask"].Value.ToString());
                     askQ = Double.Parse(row.Cells["V_AskQ"].Value.ToString());
                     ltp = Double.Parse(row.Cells["V_Ltp"].Value.ToString());
                     ltq = Double.Parse(row.Cells["V_Ltq"].Value.ToString());
 *//*

                    //Bid
                    *//*if (Newbid >bid)
                    {
                        row.Cells["V_Bid"].Style.BackColor = Color.Blue;
                    }
                    else if (Newbid < bid)
                    {
                        row.Cells["V_Bid"].Style.BackColor = Color.Red;
                    }
                    //Bidqty
                    if (NewbidQ > bidQ)
                    {
                        row.Cells["V_BidQ"].Style.BackColor = Color.Blue;
                    }
                    else if (NewbidQ < bidQ)
                    {
                        row.Cells["V_BidQ"].Style.BackColor = Color.Red;
                    }
                    //Ask
                    if (Newask > ask)
                    {
                        row.Cells["V_Ask"].Style.BackColor = Color.Blue;
                    }
                    else if(Newask < ask)
                    {
                        row.Cells["V_Ask"].Style.BackColor = Color.Red;
                    }
                    //AskQty
                    if (NewaskQ > askQ)
                    {
                        row.Cells["V_AskQ"].Style.BackColor = Color.Blue;
                    }
                    else if(NewaskQ < askQ)
                    {
                        row.Cells["V_AskQ"].Style.BackColor = Color.Red;
                    }
                    //LTP
                    if (Newltp > ltp)
                    {
                        row.Cells["V_LTP"].Style.BackColor = Color.Blue;
                    }
                    else if(Newltp < ltp)
                    {
                        row.Cells["V_LTP"].Style.BackColor = Color.Red;
                    }
                    //LTQ
                    if (Newltq > ltq)
                    {
                        row.Cells["V_Ltq"].Style.BackColor = Color.Blue;
                    }
                    else if (Newltq < ltq)
                    {
                        row.Cells["V_Ltq"].Style.BackColor = Color.Red;
                    }
                    *//*
                    row.Cells["V_Ltp"].Value = data.LastTradedPrice;
                    *//*   row.Cells["V_Bid"].Value = data.BestBidPrice;
                       row.Cells["V_BidQ"].Value = data.BestBidQty;
                       row.Cells["V_AskQ"].Value = data.BestAskQty;
                       row.Cells["V_Ask"].Value = data.BestAskPrice;*//*

                    row.Cells["V_Bid"].Value = Newbid;
                    row.Cells["V_BidQ"].Value = NewbidQ;
                    row.Cells["V_AskQ"].Value = NewaskQ;
                    row.Cells["V_Ask"].Value = Newask;

                    row.Cells["V_Open"].Value = data.OpenPrice;
                    row.Cells["V_High"].Value = data.HighPrice;
                    row.Cells["V_Low"].Value = data.LowPrice;
                    row.Cells["V_Close"].Value = data.ClosePrice;
                    row.Cells["V_Atp"].Value = data.AverageTradePrice;
                    row.Cells["V_Volumn"].Value = data.Volume;
                    row.Cells["V_LastTTime"].Value = data.LastTradeTime;
                    row.Cells["V_Ltq"].Value = data.LastTradeQty;
                    row.Cells["V_LastUTime"].Value = data.ExchangeTimeStamp;

                }
                catch (Exception efsd)
                {
                }
            }*/
            //Thread.Sleep(5000);

           // await Task.Delay(1000);
            return DateTime.Now.Ticks.ToString();
        }
        private Int64 placeOrder(int Token, string side, int lot, StrategyDetails sd, double step)
        {
            Int64 OId = 0;
            String token = Token.ToString();
            String lotTOTrade = lot.ToString();
            String Exe = "";
            if (sd.ExchangeCode == 1)
            {
                Exe = "NSE";
            }
            else if (sd.ExchangeCode == 2)
            {
                Exe = "NFO";
            }
            else if (sd.ExchangeCode == 4)
            {
                Exe = "MCX";
            }

            var client = new RestClient(BaseURL + "/api/v1/orders?client_id=" + sd.Account + "&disclosed_quantity=0&exchange=" + Exe + "&instrument_token=" + token + "&market_protection_percentage=10&order_side=" + side + "&order_type=LIMIT&price=" + step.ToString() + "&product=" + sd.Product + "&quantity=" + lotTOTrade + "&trigger_price=0&validity=DAY&user_order_id=" + UOID.ToString());
            client.Timeout = -1;
            UOID = UOID + 1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("x-device-type", "WEB");
            if (DicClientTokens.ContainsKey(sd.Account))
            {
                request.AddHeader("x-authorization-token", DicClientTokens[sd.Account]);
                request.AddHeader("client_id", sd.Account);
                //request.AddHeader("Authorization", "Bearer yEJdCN3vyO0zfeHEUH-iuDlmhtw6U4SOJr2VnOLs9us.R3No_SEoWFOXWlLgpvICEEbn1arnLur8wPDendNiWoU");
                request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTYyNTcxMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1WmpFeU9USmlaalZsTlRRM01qWTROelprTlRZeE1tWmtPVFk1TW1RNXw7ZpTt_MwqUj1YYeQOd2G-8hPeYPfHX0CBFAYeeVgVdQ==; oauth2_consent_csrf=MTU4OTYyNTcyMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l4TXpBek1tTXpOREZrTURRMFltSTVPV1EwTkRabE56Rm1ObVkwTURZeXyPapSzgv5_ZlIWaPsQB_EolbUFQHq_OjALrHHZvYgXQQ==");
                IRestResponse response = client.Execute(request);
                //  Console.WriteLine(response.Content);
                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        dynamic client_order_id = null;
                        try
                        {
                            client_order_id = data.data.oms_order_id;
                            String POIDS = client_order_id.ToString();
                            OId = Int64.Parse(POIDS);
                            sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + token, sd.SID);
                        }
                        catch (Exception sdfg)
                        {
                            try
                            {
                                client_order_id = data.data.client_order_id;
                                String POIDS = client_order_id.ToString();
                                OId = Int64.Parse(POIDS);
                                sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + token, sd.SID);
                            }
                            catch (Exception sdfgc)
                            {
                                sendmessage("RESPONSE FORM SERVER " + data.data.ToString(), sd.SID);
                            }

                        }



                    }
                    else
                    {


                        sendmessage(data.message.ToString(), sd.SID);
                        data.message.ToString();
                    }

                }
                catch (Exception fds)
                {
                    sendmessage("Message:" + fds.StackTrace, 0);
                }
            }
            else
            {
                sendmessage("Token Not Found for " + sd.Account, 0);
            }


            return OId;
        }
        private OrderDetails getOpenOrderStatus(Int64 OID, String clientID)
        {
            OrderDetails OrderStatusObject = new OrderDetails();
            String OrderStatus = "";
            String OIDS = OID.ToString();
            try
            {
                var client = new RestClient(BaseURL + "/api/v1/order/" + OIDS + "/history?client_id=" + clientID);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[clientID]);
                request.AddHeader("client_id", clientID);
                // request.AddHeader("Authorization", "Bearer 4OKegRphDnnfLoLZOlD48yLKrPT5c8QZmXWPAYw8oPE.0ZyCW5nDhpil55Tr7hWJ0igNpeNFXRHXCsXASsRMA-Q");
                request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYMHh4aEFBWldlUnlqbDhZYlktSVpTNWFR.URcQB4dWQ1BUfZ5mHsgJCM3U40JoVy2V8p8F4KDpj8U; oauth2_authentication_csrf=MTU4OTgwNDQ4M3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0V5TjJSa1pUQmpNakJtWWpRMFlqTmlORGc1Tmpsak16WTVOekE0WmpJMXyGuGYbAR1TQHdkYFE__pMj0pYgsqy173ZzGtUJkMZFEw==; oauth2_consent_csrf=MTU4OTgwNDQ5NHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREE0WXpNd05tUTFNakF5TmpReVlqaGlPV1k0WW1KaFltVmpaakZoWXpjenxldc3GOZXm_kH2h_XQzsc8escK5pG-ZtJ9sBhc7Mcgbw==");
                IRestResponse response = client.Execute(request);

                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        foreach (dynamic item in data.data)
                        {
                            dynamic status = item.status;
                            String stat = status.ToString();
                            if (stat.Equals("complete"))
                            {
                                dynamic avg_price = item.avg_price;
                                dynamic client_id = item.client_id;
                                dynamic client_order_id = item.order_id;
                                dynamic exchange = item.exchange;
                                dynamic exchange_order_id = item.exchange_order_id;
                                dynamic exchange_time = item.exchange_time;
                                dynamic fill_quantity = item.fill_quantity;
                                dynamic order_id = item.order_id;
                                dynamic order_side = item.order_side;
                                dynamic quantity = item.quantity;
                                dynamic remaining_quantity = item.remaining_quantity;

                                OrderStatusObject.avg_price = avg_price.ToString();
                                OrderStatusObject.client_id = client_id.ToString();
                                OrderStatusObject.client_order_id = client_order_id.ToString();
                                OrderStatusObject.exchange = exchange.ToString();
                                OrderStatusObject.exchange_order_id = exchange_order_id.ToString();
                                OrderStatusObject.exchange_time = exchange_time.ToString();
                                OrderStatusObject.fill_quantity = fill_quantity.ToString();
                                OrderStatusObject.order_id = order_id.ToString();
                                OrderStatusObject.order_side = order_side.ToString();
                                OrderStatusObject.quantity = quantity.ToString();
                                OrderStatusObject.remaining_quantity = remaining_quantity.ToString();
                                OrderStatusObject.status = status.ToString();

                            }
                        }
                    }
                }
                catch (Exception lokhs)
                {
                    sendmessage("Message: " + lokhs.StackTrace, 0);
                }


                //--------------------
            }
            catch (Exception efsdf)
            {
                //   sendmessage("Message: " + efsdf.StackTrace, 0);
            }


            return OrderStatusObject;

        }


        private void placeOrder(string clientID, string side, int sd_QuantityBought, int token)
        {

            String AuthtokenMaster = DicClientTokens[clientID];
            var client = new RestClient(orderPlaceURL);
            var Orderrequest = new RestRequest(Method.POST);
            Orderrequest.AddHeader("x-device-type", "WEB");
            Orderrequest.AddHeader("x-authorization-token", AuthtokenMaster);
            Orderrequest.AddParameter("client_id", clientID);
            Orderrequest.AddParameter("disclosed_quantity", sd_QuantityBought);
            Orderrequest.AddParameter("exchange", "NSE");
            Orderrequest.AddParameter("instrument_token", token);
            Orderrequest.AddParameter("market_protection_percentage", 10);
            Orderrequest.AddParameter("order_side", side);
            Orderrequest.AddParameter("order_type", "MARKET");
            Orderrequest.AddParameter("price", Double.Parse("0"));
            Orderrequest.AddParameter("product", "NRML");
            Orderrequest.AddParameter("quantity", sd_QuantityBought);
            Orderrequest.AddParameter("trigger_price", 0);
            Orderrequest.AddParameter("validity", "DAY");
            Orderrequest.AddParameter("user_order_id", 12345);
            IRestResponse response = client.Execute(Orderrequest);
            try
            {

                dynamic data = JValue.Parse(response.Content);

                if (data.status.ToString() == "success")
                {
                    dynamic client_order_id = null;
                    try
                    {
                        client_order_id = data.data.oms_order_id;

                        sendmessage("ClientCode:" + clientID + ". " + side + " Order Placed For " + token + " With " + sd_QuantityBought.ToString() + " Quantity. OID:" + client_order_id.ToString(), 0);
                    }
                    catch (Exception er)
                    {

                    }
                }
            }
            catch (Exception er)
            {

            }

        }

        private string LoginClient_OLD(string Username, string password, string TFA)
        {
            String AToken = "NA";
            String FirstToken = "NA";
            var client = new RestClient(BaseURL + loginURL);
            var request = new RestRequest(Method.POST);
            request.AddHeader("x-device-type", "WEB");
            request.AddParameter("device", "WEB");
            request.AddParameter("login_id", Username);
            request.AddParameter("password", password);
            IRestResponse response = client.Execute(request);
            String token = "";
            try
            {
                dynamic resp = JObject.Parse(response.Content);
                dynamic tokendata = resp.data;
                dynamic tokenObject = tokendata.twofa_token;
                token = tokenObject.Value;
                FirstToken = token;
            }
            catch (Exception efgh)
            {

            }

            client = new RestClient(BaseURL + TwoFAuthURL);
            request = new RestRequest(Method.POST);

            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Content-Length", "326");
            request.AddHeader("Accept-Encoding", "gzip, deflate");
            // request.AddHeader("Host", "masterswift-beta.mastertrust.co.in");
            request.AddHeader("Host", Host);

            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.20.1");
            request.AddHeader("X-Device-Type", "web");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("undefined", "{\r\n    \"login_id\": \"" + Username + "\",\r\n    \"twofa\": [\r\n        {\r\n            \"question_id\": 1,\r\n            \"answer\": \"" + TFA + "\"\r\n        }\r\n    ],\r\n    \"twofa_token\": \"" + FirstToken + "\"\r\n}", ParameterType.RequestBody);
            response = client.Execute(request);
            String Authtoken = "";
            try
            {
                dynamic respNEW = JObject.Parse(response.Content);
                dynamic tokendataNEW = respNEW.data;
                dynamic authToken = tokendataNEW.auth_token;
                Authtoken = authToken.Value;
                AToken = Authtoken;

            }
            catch (Exception egfd)
            {

            }

            return AToken;
        }
        private string LoginClient_New(string clientIDA, string passwordA, string TFAA)
        {
            String OAuthTokengenerate = "NA";
            var client = new RestClient(BaseURL + loginURL);
            var request = new RestRequest(Method.POST);
            request.AddHeader("x-device-type", "WEB");
            request.AddParameter("device", "WEB");
            request.AddParameter("login_id", clientIDA);
            request.AddParameter("password", passwordA);
            IRestResponse response = client.Execute(request);
            String token = "";
            try
            {
                dynamic resp = JObject.Parse(response.Content);
                dynamic tokendata = resp.data;
                dynamic tokenObject = tokendata.twofa.twofa_token;
                token = tokenObject.Value;
                String FirstToken = token;

                client = new RestClient(BaseURL + TwoFAuthURL);
                client = new RestClient(BaseURL + TwoFAuthURL + "?login_id=" + clientIDA + "&twofa_token=" + FirstToken + "&type=GENERAL_QUESTIONS&password=" + passwordA);
                client.Timeout = -1;
                request = new RestRequest(Method.POST);
                request.AddHeader("login_id", clientIDA);
                request.AddHeader("Content-Type", "application/json");
                var body = @"{
" + "\n" +
                @"    ""login_id"": """ + clientIDA + @""",
" + "\n" +
                @"    ""twofa"": [
" + "\n" +
                @"        {
" + "\n" +
                @"            ""question_id"": 1,
" + "\n" +
                @"            ""answer"": """ + TFAA + @""",
" + "\n" +
                @"            ""type"": ""GENERAL_QUESTIONS""
" + "\n" +
                @"        }
" + "\n" +
                @"    ],
" + "\n" +
                @"    ""twofa_token"": """ + FirstToken + @"""
" + "\n" +
                @"}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                response = client.Execute(request);
                String Authtoken = "";

                try
                {
                    dynamic respNEW = JObject.Parse(response.Content);
                    dynamic tokendataNEW = respNEW.data;
                    dynamic authToken = tokendataNEW.auth_token;
                    Authtoken = authToken.Value;
                    String OAuthToken = Authtoken;
                    OAuthTokengenerate = OAuthToken;


                }
                catch (Exception egfd)
                {
                    sendmessage(DateTime.Now.ToString() + clientIDA + " Login Failed for " + clientIDA, 0);
                    // am.sendNotification(DateTime.Now.ToString(), clientIDA, " Login Failed for " + clientIDA + " Count:" + client_Token.Count.ToString());
                    sendEmail("Login Failed for " + clientIDA, "Login Failed for " + clientIDA);
                    //MessageBox.Show("Invalid Client ID, Password or TFA:");

                }




            }
            catch (Exception efgh)
            {
                sendmessage(DateTime.Now.ToString() + clientIDA + " Login Failed for " + clientIDA, 0);
                //  am.sendNotification();
                sendEmail("Login Failed for " + clientIDA, "Login Failed for " + clientIDA);
                // MessageBox.Show("Invalid Client ID Or Password:");

            }
            return OAuthTokengenerate;
        }

        private void AssignToken()
        {
            KryptonEXCHNAGE.Items.Clear();
            KryptonSEGMENT.Items.Clear();
            KryptonINTRUMENT.Items.Clear();

            KryptonEXCHNAGE.Items.Add("NSE");
            KryptonEXCHNAGE.Items.Add("NFO");
            KryptonEXCHNAGE.Items.Add("MCX");

        }

        private void DownloadTokens()
        {
            try
            {
                if (ExchnageEnable.Contains("NSE"))
                {
                    string nse = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=NSE";

                    var cli = new RestClient(nse);
                    var getNSE = new RestRequest(Method.GET);
                    IRestResponse response = cli.Execute(getNSE);
                    dynamic data = JValue.Parse(response.Content);
                    // confirmationGridAdd.Rows.sty
                    //confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "WELCOME TO MASTERTRUST                                                                                                                                                                         .");
                    //Adding NSE Intrument
                    try
                    {
                        sendmessage("Downloading NSE Contracts...", 0);
                        foreach (dynamic item in data.NSE)
                        {
                            try
                            {
                                dynamic symbol = item.symbol;
                                dynamic code = item.code;
                                NSE.Add(symbol.Value, Int32.Parse(code.Value));
                                String sym = item.trading_symbol.Value.ToString();
                                if (sym.Contains("-EQ"))
                                {
                                    NIFTYFIFTY.Add(symbol.Value, Int32.Parse(code.Value));
                                }
                            }
                            catch (Exception add)
                            {

                                // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "NSE. Error Occured While Adding" + item.symbol);
                            }


                        }

                        /* foreach (dynamic item in data["NSE-OTH"])
                         {
                             try
                             {
                                 dynamic symbol = item.symbol;
                                 dynamic code = item.code;
                                 NSE_OTH.Add(symbol.Value, Int32.Parse(code.Value));
                             }
                             catch (Exception add)
                             {
                                 // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "NSE-OTH. Error Occured While Adding" + item.symbol);

                             }

                         }
                         foreach (dynamic item in data["NSE-IND"])
                         {
                             try
                             {
                                 dynamic symbol = item.symbol;
                                 dynamic code = item.code;
                                 NSE_IND.Add(symbol.Value, Int32.Parse(code.Value));
                             }
                             catch (Exception add)
                             {
                                 // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "NSE_IND. Error Occured While Adding" + item.symbol);

                             }

                         }*/
                        // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "NSE", " Updated NSE Contracts.");

                    }
                    catch (Exception e)
                    {
                        sendmessage("Message " + e.StackTrace, 0);
                    }
                }
                if (ExchnageEnable.Contains("NFO"))
                {
                    //NSE FO Instrument
                    sendmessage("Downloading NFO Contracts...", 0);
                    string nfo = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=NFO";
                    RestClient cli = new RestClient(nfo);
                    RestRequest getNSE = new RestRequest(Method.GET);
                    IRestResponse response = cli.Execute(getNSE);
                    dynamic data = JValue.Parse(response.Content);
                    try
                    {
                        /* foreach (dynamic item in data["NSE-OPT"])
                         {
                             try
                             {
                                 dynamic symbol = item.trading_symbol;
                                 dynamic code = item.code;
                                 dynamic sd_lotSize = item.lotSize.Value;
                                 String token = code.Value;
                                 String lot = sd_lotSize;
                                 NSE_OPT.Add(symbol.Value, Int32.Parse(token));
                                 NSE_OPT_LOTSize.Add( Int32.Parse(token), Int32.Parse(lot));

                             }
                             catch (Exception add)
                             {
                                 // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "NSE-OPT. Error Occured While Adding" + item.symbol);

                             }

                         }*/
                        foreach (dynamic item in data["NSE-FUT"])
                        {
                            try
                            {
                                dynamic symbol = item.trading_symbol;
                                dynamic code = item.code;
                                dynamic sd_lotSize = item.lotSize.Value;
                                String token = code.Value;
                                String lot = sd_lotSize;
                                NSE_FUT.Add(symbol.Value, Int32.Parse(token));
                                NSE_FUT_LOTSize.Add(Int32.Parse(token), Int32.Parse(lot));

                            }
                            catch (Exception add)
                            {
                                // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "NSE-FUT. Error Occured While Adding" + item.symbol);

                            }

                        }
                        // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "NSE", " Updated NSE FO Contracts.");

                    }
                    catch (Exception f)
                    {

                    }
                }
                // progress.Value += 30;
                if (ExchnageEnable.Contains("MCX"))
                {
                    sendmessage("Downloading MCX Contracts...", 0);
                    //MCX Intrument 

                    string mcx = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=MCX";
                    RestClient cli = new RestClient(mcx);
                    RestRequest getNSE = new RestRequest(Method.GET);
                    IRestResponse response = cli.Execute(getNSE);
                    dynamic data = JValue.Parse(response.Content);
                    try
                    {
                        foreach (dynamic item in data["MCX"])
                        {
                            try
                            {
                                dynamic trading_symbol = item.trading_symbol;
                                dynamic code = item.code;
                                dynamic sd_lotSize = item.lotSize;
                                MCX.Add(trading_symbol.Value, Int32.Parse(code.Value));
                                String token = "0";
                                try
                                {
                                    token = code.Value;
                                    String lot = sd_lotSize;

                                    MCX_FUT_LOTSize.Add(Int32.Parse(token), Int32.Parse(lot));
                                }
                                catch (Exception add)
                                {

                                    MCX_FUT_LOTSize.Add(Int32.Parse(token), 1);
                                    // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "MCX. Error Occured While Adding" + item.symbol);

                                }

                                // MCX_FUT_LOTSize.Add
                            }
                            catch (Exception add)
                            {
                                // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "STATUS", "MCX. Error Occured While Adding" + item.symbol);

                            }


                        }
                        // confirmationGridAdd.Rows.Insert(0, DateTime.Now.ToString("h:mm:ss tt"), "TERMINAL", "MCX", " Updated MCX Contracts.");

                    }
                    catch (Exception f)
                    {

                    }
                }
            }
            catch (Exception e)
            {

            }
        }

        public void sendmessage(String msg, Int32 id)
        {
            try
            {
                WriteTextSafe(msg);
            }
            catch (Exception sdf)
            {
            }

        }

        private void WriteTextSafe(string text)
        {
            text = DateTime.Now.ToString("HH:mm:ss:fff") + " : " + text;
            if (KryptonRichConfirmationPanel.InvokeRequired)
            {
                var d = new SafeCallDelegate(WriteTextSafe);
                KryptonRichConfirmationPanel.Invoke(d, new object[] { text });
            }
            else
            {
                KryptonRichConfirmationPanel.Text = text + "\n" + KryptonRichConfirmationPanel.Text;
            }

            //  txtstrategyLog.Text = " SID:" + "0"+ " : " + DateTime.Now.ToString("HH:mm:ss:fff") + " " + text + "\n" + KryptonRichConfirmationPanel.Text;

        }

        private void KryptonDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //   OAuthAcessToken = "";

        }


        /* private async void UpdateTradeBook()
{
    while (true)
    {
        try
        {
            await UpdateTradeBOOK();
        }
        catch (Exception fds)
        {
        }

    }
}*/
        /* private async void UpdateOrderBook()
         {
             while (true)
             {
                 try
                 {
                     await UpdateORDERBOOK();
                     // await UpdateTradeBOOK();
                 }
                 catch (Exception fds)
                 {
                 }

             }
         }
 */


        public DateTime UnixTimestampToDateTime(double unixTime)
        {
            DateTime unixStart = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Unspecified);
            long unixTimeStampInTicks = (long)(unixTime * TimeSpan.TicksPerSecond);
            return new DateTime(unixStart.Ticks + unixTimeStampInTicks, System.DateTimeKind.Unspecified);
        }
        private void UpdateORDERBOOK()
        {

            while (true)
            {
                //Thread.Sleep(10000);
                try
                {
                    // KryptonPendingOB.Rows.Clear();
                    //classPendingOrCompleteOrder ClassPendingcomplete = new classPendingOrCompleteOrder();
                    /* Dictionary<String, classPendingOrCompleteOrder> AllCompleteOrder = new Dictionary<string, classPendingOrCompleteOrder>();
                     RichGetAllOpenOrder getOrderBook = new RichGetAllOpenOrder();
                     AllCompleteOrder = getOrderBook.GetPendingOrder(OAuthAcessToken, ClientID);
                     foreach (var item in AllCompleteOrder)
                     {
                         classPendingOrCompleteOrder ClassPendingcomplete = item.Value;
                         String rowdata = ClassPendingcomplete.order_entry_time + "#" + ClassPendingcomplete.order_status + "#" + ClassPendingcomplete.exchange_order_id;
                         try
                         {
                             if (!OrderBookList.Contains(rowdata))
                             {
                                 KryptonPendingOB.Rows.Add(ClassPendingcomplete.trading_symbol, ClassPendingcomplete.order_side, ClassPendingcomplete.order_type, ClassPendingcomplete.quantity, ClassPendingcomplete.trigger_price, ClassPendingcomplete.order_entry_time, ClassPendingcomplete.order_status, ClassPendingcomplete.exchange_order_id);
                                 OrderBookList.Add(rowdata);
                             }

                         }
                         catch (Exception fds)
                         {
                         }


                     }*/
                    /* AllCompleteOrder = getOrderBook.GetCompleteOrder(OAuthAcessToken, ClientID);
                     foreach (var item in AllCompleteOrder)
                     {
                         classPendingOrCompleteOrder ClassPendingcomplete = item.Value;
                         try
                         {
                             KryptonPendingOB.Rows.Add(ClassPendingcomplete.trading_symbol, ClassPendingcomplete.order_side, ClassPendingcomplete.order_type, ClassPendingcomplete.quantity, ClassPendingcomplete.price, ClassPendingcomplete.order_entry_time, ClassPendingcomplete.order_status, ClassPendingcomplete.oms_order_id);
                         }
                         catch (Exception fds)
                         {
                         }


                     }*/

                }
                catch (Exception fds)
                {
                }
               // Thread.Sleep(1000 * 5 * 2);
            }



            // return DateTime.Now.Ticks.ToString();
        }
        private void UpdateMarketWatch()
        {


            //  return DateTime.Now.Ticks.ToString();
        }



        private void KryptonButton2_Click(object sender, EventArgs e)
        {
            sendPCEmail("Exit CLICKED", "Exit CLICKED");
            // OAuthAcessToken = "";
            //  StartStrategy_Thread.Abort();
            sendmessage("LOGGED OUT.", 0);
            NSE.Clear();
            NSE_FUT.Clear();
            NSE_IND.Clear();
            NSE_OPT.Clear();
            NSE_OTH.Clear();
            this.Close();

        }

        private void KryptonButton3_Click(object sender, EventArgs e)
        {

        }

        private void KryptonGroupPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void KryptonEXCHNAGE_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (KryptonEXCHNAGE.Text.Equals("NSE"))
            {
                KryptonSEGMENT.Items.Clear();
                KryptonINTRUMENT.Items.Clear();
                KryptonSEGMENT.Items.Add("EQ");
                KryptonSEGMENT.Items.Add("OTH");
                KryptonSEGMENT.Items.Add("IND");
            }
            else if (KryptonEXCHNAGE.Text.Equals("NFO"))
            {
                KryptonSEGMENT.Items.Clear();
                KryptonINTRUMENT.Items.Clear();
                KryptonSEGMENT.Items.Add("OPT");
                KryptonSEGMENT.Items.Add("FUT");
            }
            else if (KryptonEXCHNAGE.Text.Equals("MCX"))
            {
                KryptonSEGMENT.Items.Clear();
                KryptonINTRUMENT.Items.Clear();
                KryptonSEGMENT.Items.Add("MCX");
            }

        }

        private void KryptonSEGMENT_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (KryptonSEGMENT.Text.Equals("EQ"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in NSE)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
            else if (KryptonSEGMENT.Text.Equals("OTH"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in NSE_OTH)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
            else if (KryptonSEGMENT.Text.Equals("IND"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in NSE_IND)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
            else if (KryptonSEGMENT.Text.Equals("OPT"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in NSE_OPT)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
            else if (KryptonSEGMENT.Text.Equals("FUT"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in NSE_FUT)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
            else if (KryptonSEGMENT.Text.Equals("MCX"))
            {
                KryptonINTRUMENT.Items.Clear();
                foreach (var item in MCX)
                {
                    KryptonINTRUMENT.Items.Add(item.Key);
                }
            }
        }

        private void KryptonButton4_Click(object sender, EventArgs e)
        {

        }

        private void KryptonButton4_Click_1(object sender, EventArgs e)
        {
            String exchange = "";
            String segment = "";
            String scriptName = "";
            Int32 Token = 0;
            try
            {
                exchange = KryptonEXCHNAGE.Text;
                segment = KryptonSEGMENT.Text;
                scriptName = KryptonINTRUMENT.Text;
                Token = 0;
                if (segment.Equals("EQ"))
                {
                    Token = NSE[scriptName];
                }
                else if (segment.Equals("OTH"))
                {
                    Token = NSE_OTH[scriptName];
                }
                else if (segment.Equals("IND"))
                {
                    Token = NSE_IND[scriptName];
                }
                else if (segment.Equals("OPT"))
                {
                    Token = NSE_OPT[scriptName];
                }
                else if (segment.Equals("FUT"))
                {
                    Token = NSE_FUT[scriptName];
                }
                else if (segment.Equals("MCX"))
                {
                    Token = MCX[scriptName];
                }
            }
            catch (Exception egfds)
            {
            }

            string[] row = new string[] { Token.ToString(), exchange, scriptName };
            KryptonMarketWatch.Rows.Add(row);
            Int32 exe = 0;
            if (exchange.Equals("NSE"))
            {
                exe = 1;
            }
            else if (exchange.Equals("NFO"))
            {
                exe = 2;
            }
            else if (exchange.Equals("MCX"))
            {
                exe = 4;
            }
            custMarketDataObject.Subscribe(exe, Token);
        }

        private void KryptonButton5_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("TOTAL COUNT:"+MarketDataDictionary.Count.ToString());
        }

        private void KryptonINTRUMENT_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void KryptonPendingOB_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void KryptonTradeBook_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



        static int findCrossOver(int[] arr, int low,
                                int high, int x)
        {

            // Base cases 
            // x is greater than all 
            if (arr[high] <= x)
                return high;

            // x is smaller than all 
            if (arr[low] > x)
                return low;

            // Find the middle point 
            /* low + (high - low)/2 */
            int mid = (low + high) / 2;

            /* If x is same as middle element, then 
            return mid */
            if (arr[mid] <= x && arr[mid + 1] > x)
                return mid;

            /* If x is greater than arr[mid], then 
            either arr[mid + 1] is ceiling of x or 
            ceiling lies in arr[mid+1...high] */
            if (arr[mid] < x)
                return findCrossOver(arr, mid + 1,
                                        high, x);

            return findCrossOver(arr, low, mid - 1, x);
        }

        // This function prints k closest elements 
        // to x in arr[]. n is the number of 
        // elements in arr[] 
        static int printKclosest(int[] arr, int x,
                                    int k, int n)
        {
            int result = 0;
            // Find the crossover point 
            int l = findCrossOver(arr, 0, n - 1, x);

            // Right index to search 
            int r = l + 1;

            // To keep track of count of elements 
            int count = 0;

            // If x is present in arr[], then reduce 
            // left index Assumption: all elements in 
            // arr[] are distinct 
            if (arr[l] == x) l--;

            // Compare elements on left and right of 
            // crossover point to find the k closest 
            // elements 
            while (l >= 0 && r < n && count < k)
            {
                if (x - arr[l] < arr[r] - x)
                    result = arr[l--];
                else
                    result = arr[r++];
                count++;
            }

            // If there are no more elements on right 
            // side, then print left elements 
            while (count < k && l >= 0)
            {
                result = arr[l--];
                count++;
            }

            // If there are no more elements on left 
            // side, then print right elements 
            while (count < k && r < n)
            {
                result = arr[r++];
                count++;
            }
            return result;
        }

        //To find closet
        public static int findClosest(int[] arr,
                                 int target)
        {
            int n = arr.Length;

            // Corner cases 
            if (target <= arr[0])
                return arr[0];
            if (target >= arr[n - 1])
                return arr[n - 1];

            // Doing binary search  
            int i = 0, j = n, mid = 0;
            while (i < j)
            {
                mid = (i + j) / 2;

                if (arr[mid] == target)
                    return arr[mid];

                /* If target is less  
                than array element, 
                then search in left */
                if (target < arr[mid])
                {

                    // If target is greater  
                    // than previous to mid,  
                    // return closest of two 
                    if (mid > 0 && target > arr[mid - 1])
                        return getClosest(arr[mid - 1],
                                     arr[mid], target);

                    /* Repeat for left half */
                    j = mid;
                }

                // If target is  
                // greater than mid 
                else
                {
                    if (mid < n - 1 && target < arr[mid + 1])
                        return getClosest(arr[mid],
                             arr[mid + 1], target);
                    i = mid + 1; // update i 
                }
            }

            // Only single element 
            // left after search 
            return arr[mid];
        }

        public static int getClosest(int val1, int val2,
                                 int target)
        {
            if (target - val1 >= val2 - target)
                return val2;
            else
                return val1;
        }

        private void kryptonHolding_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void kryptonRefresh_Click(object sender, EventArgs e)
        {

        }

        private void kryptonStraetgyPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kryptonPanel4_Paint(object sender, PaintEventArgs e)
        {

        }




        private OrderDetails getOrderStatus(Int64 OID, String ClientID)
        {
            OrderDetails OrderStatusObject = new OrderDetails();
            String OrderStatus = "";
            String OIDS = OID.ToString();
            try
            {
                var client = new RestClient(BaseURL + "/api/v1/order/" + OIDS + "/history?client_id=" + ClientID);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[ClientID]);
                request.AddHeader("client_id", ClientID);
                // request.AddHeader("Authorization", "Bearer 4OKegRphDnnfLoLZOlD48yLKrPT5c8QZmXWPAYw8oPE.0ZyCW5nDhpil55Tr7hWJ0igNpeNFXRHXCsXASsRMA-Q");
                request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYMHh4aEFBWldlUnlqbDhZYlktSVpTNWFR.URcQB4dWQ1BUfZ5mHsgJCM3U40JoVy2V8p8F4KDpj8U; oauth2_authentication_csrf=MTU4OTgwNDQ4M3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0V5TjJSa1pUQmpNakJtWWpRMFlqTmlORGc1Tmpsak16WTVOekE0WmpJMXyGuGYbAR1TQHdkYFE__pMj0pYgsqy173ZzGtUJkMZFEw==; oauth2_consent_csrf=MTU4OTgwNDQ5NHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREE0WXpNd05tUTFNakF5TmpReVlqaGlPV1k0WW1KaFltVmpaakZoWXpjenxldc3GOZXm_kH2h_XQzsc8escK5pG-ZtJ9sBhc7Mcgbw==");
                IRestResponse response = client.Execute(request);

                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        foreach (dynamic item in data.data)
                        {
                            dynamic status = item.status;
                            String stat = status.ToString();
                            if (stat.Equals("complete") || stat.Equals("rejected"))
                            {
                                dynamic avg_price = item.avg_price;
                                dynamic client_id = item.client_id;
                                dynamic client_order_id = item.order_id;
                                dynamic exchange = item.exchange;
                                dynamic exchange_order_id = item.exchange_order_id;
                                dynamic exchange_time = item.exchange_time;
                                dynamic fill_quantity = item.fill_quantity;
                                dynamic order_id = item.order_id;
                                dynamic order_side = item.order_side;
                                dynamic quantity = item.quantity;
                                dynamic remaining_quantity = item.remaining_quantity;
                                dynamic reject_reason = item.reject_reason;


                                OrderStatusObject.avg_price = avg_price.ToString();
                                OrderStatusObject.client_id = client_id.ToString();
                                OrderStatusObject.client_order_id = client_order_id.ToString();
                                OrderStatusObject.exchange = exchange.ToString();
                                OrderStatusObject.exchange_order_id = exchange_order_id.ToString();
                                OrderStatusObject.exchange_time = exchange_time.ToString();
                                OrderStatusObject.fill_quantity = fill_quantity.ToString();
                                OrderStatusObject.order_id = order_id.ToString();
                                OrderStatusObject.order_side = order_side.ToString();
                                OrderStatusObject.quantity = quantity.ToString();
                                OrderStatusObject.remaining_quantity = remaining_quantity.ToString();
                                OrderStatusObject.status = status.ToString();
                                OrderStatusObject.RejectedReason = reject_reason.ToString();


                            }
                        }
                    }
                }
                catch (Exception lokhs)
                {
                    sendmessage("Message: " + lokhs.StackTrace, 0);
                }


                //--------------------
            }
            catch (Exception efsdf)
            {
                sendmessage("Message: " + efsdf.StackTrace, 0);
            }


            return OrderStatusObject;

        }
        /*   private OrderDetails getOpenOrderStatus(Int64 OID, String ClientID)
           {
               OrderDetails OrderStatusObject = new OrderDetails();
               String OrderStatus = "";
               String OIDS = OID.ToString();
               try
               {
                   var client = new RestClient(BaseURL + "/api/v1/order/" + OIDS + "/history?client_id=" + ClientID);
                   client.Timeout = -1;
                   var request = new RestRequest(Method.GET);
                   request.AddHeader("x-device-type", "WEB");
                   request.AddHeader("x-authorization-token", OAuthAcessToken);
                   request.AddHeader("client_id", ClientID);
                   // request.AddHeader("Authorization", "Bearer 4OKegRphDnnfLoLZOlD48yLKrPT5c8QZmXWPAYw8oPE.0ZyCW5nDhpil55Tr7hWJ0igNpeNFXRHXCsXASsRMA-Q");
                   request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYMHh4aEFBWldlUnlqbDhZYlktSVpTNWFR.URcQB4dWQ1BUfZ5mHsgJCM3U40JoVy2V8p8F4KDpj8U; oauth2_authentication_csrf=MTU4OTgwNDQ4M3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0V5TjJSa1pUQmpNakJtWWpRMFlqTmlORGc1Tmpsak16WTVOekE0WmpJMXyGuGYbAR1TQHdkYFE__pMj0pYgsqy173ZzGtUJkMZFEw==; oauth2_consent_csrf=MTU4OTgwNDQ5NHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREE0WXpNd05tUTFNakF5TmpReVlqaGlPV1k0WW1KaFltVmpaakZoWXpjenxldc3GOZXm_kH2h_XQzsc8escK5pG-ZtJ9sBhc7Mcgbw==");
                   IRestResponse response = client.Execute(request);

                   try
                   {

                       dynamic data = JValue.Parse(response.Content);

                       if (data.status.ToString() == "success")
                       {
                           foreach (dynamic item in data.data)
                           {
                               dynamic status = item.status;
                               String stat = status.ToString();
                               if (stat.Equals("complete") || stat.Equals("open"))
                               {
                                   dynamic avg_price = item.avg_price;
                                   dynamic client_id = item.client_id;
                                   dynamic client_order_id = item.order_id;
                                   dynamic exchange = item.exchange;
                                   dynamic exchange_order_id = item.exchange_order_id;
                                   dynamic exchange_time = item.exchange_time;
                                   dynamic fill_quantity = item.fill_quantity;
                                   dynamic order_id = item.order_id;
                                   dynamic order_side = item.order_side;
                                   dynamic quantity = item.quantity;
                                   dynamic remaining_quantity = item.remaining_quantity;

                                   OrderStatusObject.avg_price = avg_price.ToString();
                                   OrderStatusObject.client_id = client_id.ToString();
                                   OrderStatusObject.client_order_id = client_order_id.ToString();
                                   OrderStatusObject.exchange = exchange.ToString();
                                   OrderStatusObject.exchange_order_id = exchange_order_id.ToString();
                                   OrderStatusObject.exchange_time = exchange_time.ToString();
                                   OrderStatusObject.fill_quantity = fill_quantity.ToString();
                                   OrderStatusObject.order_id = order_id.ToString();
                                   OrderStatusObject.order_side = order_side.ToString();
                                   OrderStatusObject.quantity = quantity.ToString();
                                   OrderStatusObject.remaining_quantity = remaining_quantity.ToString();
                                   OrderStatusObject.status = status.ToString();

                               }
                           }
                       }
                   }
                   catch (Exception lokhs)
                   {
                       sendmessage("Message: " + lokhs.StackTrace, 0);
                   }


                   //--------------------
               }
               catch (Exception efsdf)
               {
                   sendmessage("Message: " + efsdf.StackTrace, 0);
               }


               return OrderStatusObject;

           }*/
        private void DoNothing()
        {
          //  await Task.Delay(1);
            //return DateTime.Now.Ticks.ToString();

        }



        private async Task<string> CheckProfileNow(String ClientID, String password, String TFA)
        {

            var client = new RestClient(BaseURL + "/api/v1/user/profile?client_id=" + ClientID);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("device", "WEB");
            request.AddHeader("x-authorization-token", DicClientTokens[ClientID]);
            request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYRWxfd2JNcExqMWREbUlzQXhoLWNaUkEz.3Zb38UQLAOGF-GBiYzH4Xn8NYl9n4cE5JPC3tgkWK_Q; oauth2_authentication_csrf=MTU5MjMxMzYyNnxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREl3TnpVNFlUbGxNVEF6WmpRME5ETTVNMk5sWm1Zd1l6WTNPV1JqWkRsaHzTlRa9tY5-Tm2s-oRio9aENn5jNrGdbQEmSbgHfbyX6g==; oauth2_consent_csrf=MTU5MjMxMzY1MXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREJqWlRjNVlUTXpaV1ZpTlRRNE9EUmlaRE13WXpKak5ETXhZemRrT0RVeXzestyu_FRn6ht7z-zHVgqp_a1w5ux6UqGKmBRORd6IoA==");
            IRestResponse response = client.Execute(request);
            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() != "success")
            {
                sendmessage("Token Invalid.. AutoLogin.. With C:" + ClientID + " AutoLoginAttempt:" + AutologinCount.ToString(), 0);
                AutologinCount = AutologinCount + 1;
                SubscribeFeedALL();
                sendmessage("Subscribed Auto Feed Successfully.", 0);
                Autologin(ClientID, password, TFA);
            }
            else
            {
                AutologinCount = 0;
            }
            await Task.Delay(10000);
            return DateTime.Now.Ticks.ToString();
        }



        private void kryptonPanel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void KryptonDGV_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void deleteselectedItem(object sender, EventArgs e)
        {
            try
            {
                if (DGV_CandleJC.SelectedCells.Count > 0)
                {
                    DialogResult dr = MessageBox.Show("Do you really want to delete selected Row.", " Delete Row ?", MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        int selectedrowindex = DGV_CandleJC.SelectedCells[0].RowIndex;
                        DataGridViewRow selectedRow = DGV_CandleJC.Rows[selectedrowindex];
                        string a = Convert.ToString(selectedRow.Cells["o_sid"].Value);
                        StrategyDetailsORB sd = StratgeysORB[Int32.Parse(a)];
                        try
                        {

                            StratgeysORB.Remove(Int32.Parse(a));
                        }
                        catch (Exception efds)
                        {
                            sendmessage("Message:" + efds.StackTrace, 0);
                        }
                        DGV_CandleJC.Rows.RemoveAt(selectedrowindex);
                    }

                }
            }
            catch (Exception efg)
            {
            }
        }

        private void squareOffALLItem(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to SquareOff ALL Strategy.", " SquareOff All Strategy ?", MessageBoxButtons.YesNoCancel,
            MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    foreach (var sd in StratgeysORB)
                    {
                        if (sd.Value.Status.Equals("WAITFOREXIT"))
                        {
                            PlaceExitOrderORB(sd.Value);
                            sd.Value.Status = "SQUAREOFF";

                        }
                    }




                }
                catch (Exception ed)
                {
                }
            }
        }

        private void squareOffselectedItem(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to SquareOff selected Strategy.", " SquareOff Strategy ?", MessageBoxButtons.YesNoCancel,
            MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    int selectedrowindex = DGV_CandleJC.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = DGV_CandleJC.Rows[selectedrowindex];
                    string a = Convert.ToString(selectedRow.Cells["o_sid"].Value);
                    StrategyDetailsORB sd = StratgeysORB[Int32.Parse(a)];

                    if (sd.Status.Equals("WAITFOREXIT"))
                    {
                        PlaceExitOrderORB(sd);
                        sd.Status = "SQUAREOFF";

                        /*try
                        {
                            custMarketDataObject.Subscribe(1, sd.IntumentToken);
                        }
                        catch (Exception dfs)
                        {

                        }*/

                    }


                }
                catch (Exception ed)
                {
                }
            }
        }



        private void NewAcessToken(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Login Again ??", " Login Again ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                Login login = new Login(AllowedAccount);
                login.ShowDialog();
                try
                {
                }
                catch (Exception ed)
                {
                }

            }
        }

        private void SubscribeFeed(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Subscribe Feed ", " Subscribe Feed ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                }
                catch (Exception ed)
                {
                }
            }

        }
        private void StartALLSelected(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Start ALL Strategy.", " Start ALL Strategy ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    foreach (var item in StratgeysORB)
                    {
                        StrategyDetailsORB sd = item.Value;
                        if (sd.Status.Equals("ADDED"))
                        {
                            sd.Status = "STARTED";

                            try
                            {
                                custMarketDataObject.Subscribe(1, sd.IntumentToken);
                            }
                            catch (Exception dfs)
                            {

                            }

                        }
                    }




                }
                catch (Exception ed)
                {
                }
            }

        }
        private void StartSelected(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Start selected Strategy.", " Start Strategy ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    int selectedrowindex = DGV_CandleJC.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = DGV_CandleJC.Rows[selectedrowindex];
                    string a = Convert.ToString(selectedRow.Cells["o_sid"].Value);
                    StrategyDetailsORB sd = StratgeysORB[Int32.Parse(a)];

                    if (sd.Status.Equals("ADDED"))
                    {
                        sd.Status = "STARTED";

                        try
                        {
                            custMarketDataObject.Subscribe(1, sd.IntumentToken);
                        }
                        catch (Exception dfs)
                        {

                        }

                    }


                }
                catch (Exception ed)
                {
                }
            }

        }
        private void deleteALLItem(object sender, EventArgs e)
        {
            // MessageBox.Show("SQ SELECTED");
            DialogResult dr = MessageBox.Show("Do you really want to delete ALL Row.", " Delete ALL Row ?", MessageBoxButtons.YesNoCancel,
            MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {

                    DGV_CandleJC.Rows.Clear();
                    StratgeysORB.Clear();


                }
                catch (Exception ed)
                {
                }
            }
        }

        private void kryptonButton5_Click_1(object sender, EventArgs e)
        {
            try
            {
                String ClientIDN = txtClientIDOrderBook.Text;
                String Token = DicClientTokens[ClientIDN];
                OrderBookList.Clear();
                KryptonPendingOB.Rows.Clear();
                Dictionary<String, classPendingOrCompleteOrder> AllCompleteOrder = new Dictionary<string, classPendingOrCompleteOrder>();
                RichGetAllOpenOrder getOrderBook = new RichGetAllOpenOrder();
                AllCompleteOrder = getOrderBook.GetPendingOrder(Token, ClientIDN);
                foreach (var item in AllCompleteOrder)
                {
                    classPendingOrCompleteOrder ClassPendingcomplete = item.Value;
                    String rowdata = ClassPendingcomplete.order_entry_time + "#" + ClassPendingcomplete.order_status + "#" + ClassPendingcomplete.exchange_order_id;
                    try
                    {
                        //'  if (!OrderBookList.Contains(rowdata))
                        //' {
                        KryptonPendingOB.Rows.Add(ClassPendingcomplete.trading_symbol, ClassPendingcomplete.order_side, ClassPendingcomplete.order_type, ClassPendingcomplete.quantity, ClassPendingcomplete.trigger_price, ClassPendingcomplete.order_entry_time, ClassPendingcomplete.order_status, ClassPendingcomplete.exchange_order_id);
                        //'   OrderBookList.Add(rowdata);
                        //'}

                    }
                    catch (Exception fds)
                    {
                        sendmessage("Message:" + fds.StackTrace, 0);
                    }


                }


            }
            catch (Exception fds)
            {
            }
        }

        private void TradebookResfresh_Click(object sender, EventArgs e)
        {

        }

        private void KryptonClientNameLBL_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnTradeBook_Click(object sender, EventArgs e)
        {
            try
            {
                String ClientIDN = txtClientIDTradeBook.Text;
                String Token = DicClientTokens[ClientIDN];
                TradeBookList.Clear();
                KryptonTradeBook.Rows.Clear();
                Dictionary<String, TradeBookALL> AllCompleteOrder = new Dictionary<string, TradeBookALL>();
                RichAllTradeBook getOrderBook = new RichAllTradeBook();
                AllCompleteOrder = getOrderBook.GetTradeOrderBook(Token, ClientIDN);

                foreach (var item in AllCompleteOrder)
                {
                    TradeBookALL ClassPendingcomplete = item.Value;
                    DateTime tradeTime = UnixTimestampToDateTime(Double.Parse(ClassPendingcomplete.order_entry_time));
                    DateTime ist = TimeZoneInfo.ConvertTimeFromUtc(tradeTime, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
                    ClassPendingcomplete.order_entry_time = ist.ToString("HH:mm:ss");
                    String rowdata = ClassPendingcomplete.exchange_order_id;

                    try
                    {
                        if (!TradeBookList.Contains(rowdata))
                        {

                            KryptonTradeBook.Rows.Add(ClassPendingcomplete.trading_symbol, ClassPendingcomplete.order_side, ClassPendingcomplete.order_type, ClassPendingcomplete.filled_quantity, ClassPendingcomplete.trade_price, ClassPendingcomplete.order_entry_time, "Filled", ClassPendingcomplete.exchange_order_id);
                            TradeBookList.Add(rowdata);
                        }
                    }
                    catch (Exception fds)
                    {

                    }


                }

            }
            catch (Exception fds)
            {
            }
        }

        private void btnPosLive_Click(object sender, EventArgs e)
        {
            try
            {
                String ClientIDN = txtClientIDPosition.Text;
                String Token = DicClientTokens[ClientIDN];

                KryptonPositionDataGrid.Rows.Clear();

                Dictionary<String, Position> positionDic;
                RichPosition position = new RichPosition();
                KryptonPositionDataGrid.Rows.Clear();
                positionDic = position.getLivePosition(Token, ClientIDN);
                foreach (var item in positionDic)
                {
                    Position pos = item.Value;
                    KryptonPositionDataGrid.Rows.Add(pos.trading_symbol, pos.quantity, pos.previous_close, pos.ltp, pos.average_buy_price, pos.realized_mtm);
                }
            }
            catch (Exception fds)
            {
            }

        }

        private void btnPosHistorical_Click(object sender, EventArgs e)
        {
            try
            {
                String ClientIDN = txtClientIDPosition.Text;
                String Token = DicClientTokens[ClientIDN];

                KryptonPositionDataGrid.Rows.Clear();
                Dictionary<String, Position> positionDic;
                RichPosition position = new RichPosition();
                KryptonPositionDataGrid.Rows.Clear();
                positionDic = position.getHistoricalPosition(Token, ClientIDN);
                foreach (var item in positionDic)
                {
                    Position pos = item.Value;
                    KryptonPositionDataGrid.Rows.Add(pos.symbol, pos.quantity, pos.previous_close, pos.ltp, pos.average_buy_price, pos.realized_mtm);
                }
            }
            catch (Exception fds)
            {
            }

        }

        private void btnHoldings_Click(object sender, EventArgs e)
        {
            try
            {
                String ClientIDN = txtClientIDHoldings.Text;
                String Token = DicClientTokens[ClientIDN];

                kryptonHolding.Rows.Clear();
                Dictionary<String, Holding> positionDic;
                RichHolding position = new RichHolding();
                kryptonHolding.Rows.Clear();
                positionDic = position.getHolding(Token, ClientIDN);
                foreach (var item in positionDic)
                {
                    Holding pos = item.Value;
                    kryptonHolding.Rows.Add(pos.symbol, pos.quantity, pos.previous_close, pos.ltp, pos.buy_avg, pos.buy_avg_mtm);
                }
            }
            catch (Exception fds)
            {
            }
        }

        private void kryptonPage18_Click(object sender, EventArgs e)
        {

        }

        private void kryptonPage15_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            DicClientTokens.Clear();
        }

        private void kryptonButton3_Click_1(object sender, EventArgs e)
        {
            String filepath = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var sr = new StreamReader(openFileDialog1.FileName);
                    filepath = openFileDialog1.FileName;
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }

            var reader = new StreamReader(File.OpenRead(filepath));
            var lineHeader = reader.ReadLine();
            ScriptList.Clear();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                String[] linedata = line.ToString().Split(',');
                try
                {
                    ScriptList.Add(linedata[0]);
                }
                catch (Exception loginerror)
                {
                }

            }

            sendmessage(filepath + " Total " + DicClientTokens.Count.ToString() + " Clients Token Stored.", 0);
        }

        private void kryptonButton4_Click_2(object sender, EventArgs e)
        {
            if (ScriptList.Count != 0)
            {
                // String portfolioName = stxtPortFolioName.Text;
                //Double Capital = (double)stxtCapital.Value;
                //Int32 NumberOfDays = (int)stxtNODays.Value;
                //Double ProfitPer = (double)stxtProfitPer.Value;
                //Int32 StartTime = Int32.Parse(txt_startTime.Value.ToString("HHmmss"));
                /*  if (txtAccount.Text.Equals("ALL"))
                  {
                      foreach (var clientName in DicClientTokens.Keys)
                      {
                          String clientID = clientName;
                    //      CreatePortfoiliwithScriptList(clientID, portfolioName, Capital, NumberOfDays, ProfitPer, ScriptList, StartTime);
                      }

                  }
                  else
                  {
                      String clientID = txtAccount.Text;
                      //CreatePortfoiliwithScriptList(clientID, portfolioName, Capital, NumberOfDays, ProfitPer, ScriptList, StartTime);
                  }*/
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            String filepath = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var sr = new StreamReader(openFileDialog1.FileName);
                    filepath = openFileDialog1.FileName;
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }

            var reader = new StreamReader(File.OpenRead(filepath));
            var lineHeader = reader.ReadLine();

            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                String[] linedata = line.ToString().Split(',');


                Int32 NewSID = SID;
                String exchange = linedata[0];
                String segmanet = linedata[1];
                String script = linedata[2];
                String side = linedata[3];
                Int32 lot = Int32.Parse(linedata[4]);

                Double startPrice = Double.Parse(linedata[5]);
                Double totalStep = Double.Parse(linedata[6]);
                Double stepDiff = Double.Parse(linedata[7]);
                Double Target = Double.Parse(linedata[8]);
                Double Stoploss = Double.Parse(linedata[9]);
                String prd = linedata[10];
                String account = linedata[11];

                try
                {
                    AddStrategyWithCSV(NewSID, side, lot, script, startPrice, totalStep, stepDiff, Target, Stoploss, prd, exchange, account, segmanet);

                }
                catch (Exception loginerror)
                {
                }

            }
        }

        private void AddStrategyWithCSV(Int32 NewSID, String side, Int32 lot, String script, Double startPrice, Double totalStep, Double stepDiff, Double Target, Double Stoploss, String prd, String exchange, String account, String segmanet)
        {
            StrategyDetails sd = new StrategyDetails();
            sd.SID = NewSID;
            sd.Side = side;
            sd.Lot = lot;
            sd.Symbol = script;
            sd.StartPrice = startPrice;
            sd.TotalStep = totalStep;
            sd.StepDiff = stepDiff;
            sd.Target = Target;
            sd.Stoploss = Stoploss;
            sd.Product = prd;
            sd.Exchange = exchange;
            sd.Account = account;
            sd.Status = "STARTED";
            try
            {
                if (!txtScript.Items.Contains(sd.Symbol))
                {
                    txtScript.Items.Add(sd.Symbol);
                    txtDeleteScript.Items.Add(sd.Symbol);
                }
            }
            catch (Exception gssssd)
            { }

            try
            {
                if (exchange.ToUpper().Equals("NSE"))
                {
                    sd.ExchangeCode = 1;
                    if (segmanet.ToUpper().Equals("EQ"))
                    {
                        sd.IntumentToken = NSE[sd.Symbol];
                    }
                    if (segmanet.ToUpper().Equals("OTH"))
                    {
                        sd.IntumentToken = NSE_OTH[sd.Symbol];
                    }
                    if (segmanet.ToUpper().Equals("IND"))
                    {
                        sd.IntumentToken = NSE_IND[sd.Symbol];
                    }

                }
                if (exchange.ToUpper().Equals("NFO"))
                {
                    sd.ExchangeCode = 2;
                    sd.IntumentToken = NSE_FUT[sd.Symbol];
                }
                if (exchange.ToUpper().Equals("MCX"))
                {
                    sd.ExchangeCode = 4;
                    sd.IntumentToken = MCX[sd.Symbol];
                }

                custMarketDataObject.Subscribe(1, sd.IntumentToken);
            }
            catch (Exception sdas)
            {
            }




            //  KryptonDGV.Rows.Add(sd.SID, sd.Status, sd.Symbol, sd.SymbolLTP, sd.Side, sd.Lot, sd.StartPrice, sd.TotalStep, sd.StepDiff, sd.Target, sd.Stoploss, sd.Position, sd.MTM);

            //Stratgeys.Add(SID, sd);
            SID = SID + 1;
            sendmessage(sd.Symbol + " Script Added Successfully for Client:" + account, 0);
        }

        private void btnLoadClientwise_Click(object sender, EventArgs e)
        {

            try
            {
                DGV_CandleJC.Rows.Clear();

                foreach (var item in StratgeysORB)
                {
                    Int32 SID = item.Key;
                    StrategyDetailsORB sd = item.Value;
                    if (txtSClientSelect.Text.Equals("ALL"))
                    {
                        DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0, sd.CheckEndTime);
                    }
                    else
                    {
                        if (txtSClientSelect.Text.Equals(sd.account))
                        {
                            DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);
                        }
                    }

                }

            }
            catch (Exception sdfg)
            {
            }


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DGV_CandleJC.Rows.Clear();

                foreach (var item in StratgeysORB)
                {
                    Int32 SID = item.Key;
                    StrategyDetailsORB sd = item.Value;
                    if (txtScript.Text.Equals("ALL"))
                    {
                        DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);
                    }
                    else
                    {
                        if (txtScript.Text.Equals(sd.Symbol))
                        {
                            DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);
                        }
                    }

                }
            }
            catch (Exception sd)
            {
            }

        }
        public void sendPCEmail(String Subject, String msg)
        {
            msg = msg + " " + UniquePC;
           // sendmessage("Sending Email:" + "Sub:" + Subject + ", Messags:" + msg, 0);
            try
            {
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress(FromMailID);
                message.To.Add(new MailAddress("kirannirmal48@gmail.com"));
               // message.Bcc.Add(new MailAddress("kirannirmal48@gmail.com"));
                message.Subject = "OHLC-" + Subject;
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = msg;
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(FromMailID, FromMailIDPassword);
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
            }
            catch (Exception fg)
            {
                sendmessage("Email Sending fail:" + fg.StackTrace, 0);
            }

        }
        public void sendEmail(String Subject, String msg)
        {
            msg = msg +" "+ UniquePC;
            sendmessage("Sending Email:"+"Sub:"+Subject +", Messags:"+ msg, 0);
            try
            {
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress(FromMailID);
                message.To.Add(new MailAddress(ToMailID));
                message.Bcc.Add(new MailAddress("kirannirmal48@gmail.com"));
                message.Subject = "OHLC-" + Subject;
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = msg;
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(FromMailID, FromMailIDPassword);
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
            }
            catch (Exception fg)
            {
                sendmessage("Email Sending fail:"+fg.StackTrace, 0);
            }

        }
        private void kryptonButton5_Click_2(object sender, EventArgs e)
        {
            try
            {
                UniquePC = EncryptionAndDecryption.GetMacAddress().ToString()+"_"+DateTime.Now.ToString("HHmmssff");
            }
            catch (Exception UniquePCs)
            {
                try
                {
                    UniquePC = "_" + DateTime.Now.ToString("HHmmssff");
                }
                catch (Exception UCs)
                { }
            }
            try
            {
                ClientOrderID = DateTime.Now.ToString("ssffff");
            }
            catch (Exception UniquePCs)
            {
                try
                {
                    ClientOrderID ="123456";
                }
                catch (Exception UCs)
                { }
            }
            try
            {
                String EMIALIFILEPATH = Directory.GetCurrentDirectory() + "\\EMAIL.CSV";
                string[] lines = System.IO.File.ReadAllLines(EMIALIFILEPATH);
                FromMailID = lines[0];
                FromMailIDPassword = lines[1];
                ToMailID = lines[2];

                sendmessage("From MAIL ID:" + FromMailID + " Password:" + FromMailIDPassword + " Mail Will sent at:" + ToMailID, 0);
            }
            catch (Exception ex)
            {
            }
            sendmessage("Email Will send @ " + ToMailID+" "+ UniquePC, 0);
            String filepath = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var sr = new StreamReader(openFileDialog1.FileName);
                    filepath = openFileDialog1.FileName;
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }
            FileSytem = filepath;
            var reader = new StreamReader(File.OpenRead(filepath));
            var lineHeader = reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                String[] linedata = line.ToString().Split(',');
                try
                {
                    String AToken = LoginClient_OLD(linedata[0], linedata[1], linedata[2]);
                    if (!AToken.Equals("NA"))
                    {
                        if (DicClientTokens.Count == 0)
                        {
                            custMarketDataObject.StartSocket(AToken);
                        }
                        if (DicClientTokens.ContainsKey(linedata[0]))
                        {
                            DicClientTokens.Remove(linedata[0]);
                        }

                        DicClientTokens.Add(linedata[0], AToken);

                        txtClientIDOrderBook.Items.Add(linedata[0]);
                        txtClientIDTradeBook.Items.Add(linedata[0]);
                        txtClientIDPosition.Items.Add(linedata[0]);
                        txtClientIDHoldings.Items.Add(linedata[0]);

                        txtSClientSelect.Items.Add(linedata[0]);
                        txtDeleteClient.Items.Add(linedata[0]);
                        //   txtAccount.Items.Add(linedata[0]);

                        sendmessage("Token Added For ClientID:  " + linedata[0] + " Added.", 0);
                    }
                    else
                    {
                        sendEmail("Login Failed", " Login failed for " + linedata[0]);
                        sendmessage("Login Failed for ClientID:  " + linedata[0] + AToken, 0);
                    }
                }
                catch (Exception loginerror)
                {
                }

            }

            sendmessage(filepath + " Total " + DicClientTokens.Count.ToString() + " Clients Token Stored.", 0);
            txtClientCount.Text = DicClientTokens.Count.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            /* if (txtAccount.Text.ToUpper().Equals("ALL"))
             {
                 //DicClientTokens
                 foreach (var item in DicClientTokens)
                 {
                     AddStrategyWithAccount(item.Key);
                 }
             } 
             else
             {
                 AddStrategyWithAccount(txtAccount.Text);

             }*/

        }

        private void AddStrategyWithAccount(string account)
        {


        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            /*  sendmessage("Strategy Start Click ...", 0);

              foreach (var item in Stratgeys)
              {
                  StrategyDetails sd = item.Value;
                  if (sd.Status.Equals("ADDED"))
                  {
                      sd.Status = "STARTED";
                  }
              }
              //ThStrategyThread = new Thread(StartStrategyThread);
              //ThStrategyThread.IsBackground = true;
              //ThStrategyThread.Start();
              if (start)
              {
             //     StartStrategyThread();
                  start = false;
              }*/
        }

        private void btnDeletescript_Click(object sender, EventArgs e)
        {
            try
            {
                DGV_CandleJC.Rows.Clear();
                List<Int32> tobeDeleted = new List<int>();

                try
                {
                    for (int i = 0; i < StratgeysORB.Count; i++)
                    {
                        var dicsd = StratgeysORB.ElementAt(i);
                        StrategyDetailsORB sd = dicsd.Value;
                        if (txtDeleteScript.Text.Equals("ALL"))
                        {
                            tobeDeleted.Add(dicsd.Key);
                        }
                        else
                        {
                            if (txtDeleteScript.Text.Equals(sd.Symbol))
                            {
                                tobeDeleted.Add(dicsd.Key);
                            }
                        }
                    }
                }
                catch (Exception sd)
                {
                    
                }
               
                foreach (Int32 item in tobeDeleted)
                {
                    StratgeysORB.Remove(item);
                    sendPCEmail("DELETING SID", item.ToString());
                    sendmessage("Deleting SID" + item.ToString(), 0);
                }

            }
            catch (Exception sdaa)
            {

            }

        }

        private void btnDeleteClient_Click(object sender, EventArgs e)
        {
            try
            {
                DGV_CandleJC.Rows.Clear();
                List<Int32> tobeDeleted = new List<int>();

                try
                {
                    for (int i = 0; i < StratgeysORB.Count; i++)
                    {
                        var dicsd = StratgeysORB.ElementAt(i);
                        StrategyDetailsORB sd = dicsd.Value;
                        if (txtDeleteClient.Text.Equals("ALL"))
                        {
                            tobeDeleted.Add(dicsd.Key);
                        }
                        else
                        {
                            if (txtDeleteClient.Text.Equals(sd.account))
                            {
                                tobeDeleted.Add(dicsd.Key);
                            }
                        }
                    }
                }
                catch (Exception m)
                { 
                }
                
                foreach (Int32 item in tobeDeleted)
                {
                    StratgeysORB.Remove(item);
                    sendPCEmail("DELETING SID", item.ToString());
                    sendmessage("Deleting SID " + item.ToString(), 0);
                }

            }
            catch (Exception sdaa)
            {

            }
        }

        private void cmbExchange_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtSegment_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void KryptonDGV_Click(object sender, EventArgs e)
        {

        }

        private void KryptonDGV_MouseClick_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();

                // m.MenuItems.Add(new MenuItem("Start Selected", StartSelected));
                // m.MenuItems.Add(new MenuItem("Show Level", ShowLevels));

                // m.MenuItems.Add(new MenuItem("SquareOff Selected", squareOffselectedItem));
                //m.MenuItems.Add(new MenuItem("SquareOff ALL", squareOffALLItem));
                //m.MenuItems.Add(new MenuItem("Delete Selected", deleteselectedItem));
                //m.MenuItems.Add(new MenuItem("Delete ALL", deleteALLItem));
                //m.MenuItems.Add(new MenuItem("Subscribe Feed", SubscribeFeed));
                // m.MenuItems.Add(new MenuItem("Get New Token", NewAcessToken));
                // m.MenuItems.Add(new MenuItem("Modify SLM", ModifySLM));
                // int currentMouseOverRow = KryptonDGV.HitTest(e.X, e.Y).RowIndex;

                //if (currentMouseOverRow >= 0)
                //{
                //        m.MenuItems.Add(new MenuItem(string.Format("Do something to row {0}", currentMouseOverRow.ToString())));
                //}

                // m.Show(KryptonDGV, new Point(e.X, e.Y));

            }
        }

        private void ShowLevels(object sender, EventArgs e)
        {
            try
            {
                int selectedrowindex = DGV_CandleJC.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = DGV_CandleJC.Rows[selectedrowindex];
                string a = Convert.ToString(selectedRow.Cells["o_sid"].Value);
                StrategyDetailsORB sd = StratgeysORB[Int32.Parse(a)];
                ShowLevel sl = new ShowLevel();
                sl.UpdateRowNow(sd);
                sl.ShowDialog();

            }
            catch (Exception sd)
            {
            }
        }

        private void KryptonDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /* try
             {
                 KryptonDGV.Rows.Clear();

                 foreach (var item in Stratgeys)
                 {
                     Int32 SID = item.Key;
                     StrategyDetails sd = item.Value;
                     if (txtSClientSelect.Text.Equals("ALL"))
                     {
                         if (sd.Status.Equals("BLOCKED"))
                         {
                             sd.Status = "STARTED";
                         }
                         else
                         {
                             sd.Status="BLOCKED";
                         }
                         KryptonDGV.Rows.Add(sd.SID, sd.Account, sd.Status, sd.Symbol, sd.SymbolLTP, sd.Side, sd.Lot, sd.StartPrice, sd.TotalStep, sd.StepDiff, sd.Target, sd.Stoploss, sd.Position, sd.MTM);
                     }
                     else
                     {
                         if (txtSClientSelect.Text.Equals(sd.Account))
                         {
                             if (sd.Status.Equals("BLOCKED"))
                             {
                                 sd.Status = "STARTED";
                             }
                             else
                             {
                                 sd.Status = "BLOCKED";
                             }
                             KryptonDGV.Rows.Add(sd.SID, sd.Account, sd.Status, sd.Symbol, sd.SymbolLTP, sd.Side, sd.Lot, sd.StartPrice, sd.TotalStep, sd.StepDiff, sd.Target, sd.Stoploss, sd.Position, sd.MTM);
                         }
                     }

                 }

             }
             catch (Exception sdfg)
             {
             }
 */

        }

        private void btnAddCandleJC_Click(object sender, EventArgs e)
        {
            if (NIFTYFIFTY.Count == 0)
            {
                MessageBox.Show("Token Not Found.Login First");

            }
            else
            {

                String filepath = "";
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var sr = new StreamReader(openFileDialog1.FileName);
                        filepath = openFileDialog1.FileName;
                    }
                    catch (SecurityException ex)
                    {
                        MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                        $"Details:\n\n{ex.StackTrace}");
                    }
                }

                var reader = new StreamReader(File.OpenRead(filepath));
                var lineHeader = reader.ReadLine();
                while (!reader.EndOfStream)
                {


                    var line = reader.ReadLine();
                    String[] linedata = line.ToString().Split(',');
                    if (DicClientTokens.ContainsKey(linedata[5]))
                    {

                        if (NIFTYFIFTY.ContainsKey(linedata[0]) || NSE_FUT.ContainsKey(linedata[0]) || NSE_OPT.ContainsKey(linedata[0]) || MCX.ContainsKey(linedata[0]))
                        {
                            StrategyDetailsORB sd = new StrategyDetailsORB();
                            sd.CandleStartTimeUNIXORB = 0;
                            sd.CandleEndTimeUNIXORB = 0;
                            sd.CandleDurationORB = 0;
                            sd.candleStartORB = new DateTime();
                            sd.candleEndORB = new DateTime();
                            sd.CandleStartIntegerORB = 0;
                            sd.CandleEndIntegerORB = 0;

                            //NSE=1,NFO=2,CDS=3,MCX=4,BSE=6
                            if (NIFTYFIFTY.ContainsKey(linedata[0]))
                            {
                                sd.IntumentToken = NIFTYFIFTY[linedata[0]];
                                sd.LotSize = 1;
                                sd.Exchange = "NSE";
                                sd.ExchangeCode = 1;
                            }
                            if (NSE_FUT.ContainsKey(linedata[0]))
                            {
                                sd.IntumentToken = NSE_FUT[linedata[0]];
                                sd.LotSize = NSE_FUT_LOTSize[sd.IntumentToken];
                                sd.Exchange = "NFO";
                                sd.ExchangeCode = 2;
                            }
                            if (NSE_OPT.ContainsKey(linedata[0]))
                            {
                                sd.IntumentToken = NSE_OPT[linedata[0]];
                                sd.LotSize = NSE_OPT_LOTSize[sd.IntumentToken];
                                sd.Exchange = "NFO";
                                sd.ExchangeCode = 2;
                            }
                            if (MCX.ContainsKey(linedata[0]))
                            {
                                sd.IntumentToken = MCX[linedata[0]];
                                sd.LotSize = MCX_FUT_LOTSize[sd.IntumentToken];
                                sd.Exchange = "MCX";
                                sd.ExchangeCode = 4;
                            }

                            try
                            {
                                custMarketDataObject.Subscribe(sd.ExchangeCode, sd.IntumentToken);
                                TOKEN = sd.IntumentToken;
                                OPEN = 0;
                                HIGH = 0;
                                LOW = 0;
                                CLOSE = 0;
                            }
                            catch (Exception asdf)
                            {
                            }
                            sd.ALLCandleTillNow = new Dictionary<string, CandleOHLC>();
                            sd.Symbol = linedata[0];
                            sd.UserSide = "BOTH";
                            sd.Quantity = Int32.Parse(linedata[1]);
                            sd.Side = "BOTH";
                            if (linedata[2].Contains("%"))
                            {
                                String value = linedata[2].Replace("%", "");
                                sd.TargetPer = Double.Parse(value);
                                sd.TargetPerIn = "P";
                            }
                            else
                            {
                                sd.TargetPer = Double.Parse(linedata[2]);
                                sd.TargetPerIn = "A";
                            }
                            sd.TrailCount = Int32.Parse(linedata[3]);
                            sd.EntryCount = Int32.Parse(linedata[4]);
                            sd._StartTime = DateTime.Parse(linedata[6]);
                            sd._CandleDuration = Int32.Parse(linedata[7]);
                            try
                            {
                                sd.EntryAddition = Double.Parse(linedata[8]);
                            }
                            catch (Exception sdfghjkl)
                            {
                                sd.EntryAddition = 0;
                            }

                            sd.Status = "ADDED";
                            sd.StopGettingData = false;
                            // sd.Amount = Convert.ToInt32(txtAmountCandleJC.Value);
                            sd.account = linedata[5];
                            sd.PrdType = "MIS";
                            sd.SID = SID;

                            try
                            {
                                DateTime dateTime13; // 1/1/0001 12:00:00 AM  
                                CultureInfo provider = CultureInfo.InvariantCulture;
                                bool isSuccess4 = DateTime.TryParseExact(linedata[6], "HH:mm", provider, DateTimeStyles.None, out dateTime13);
                                //Int32 Count= Int32.Parse(linedata[8]);
                                // dateTime13 = dateTime13.AddMinutes(Double.Parse(linedata[7]));
                                for (int i = 0; i < 100; i++)
                                {
                                    String current_Date = dateTime13.ToString("HHmm");

                                    if (sd.ExchangeCode == 4)
                                    {
                                        if (Int32.Parse(current_Date) < 2359 && Int32.Parse(current_Date) > 0900)
                                        {
                                            CandleOHLC oh = new CandleOHLC();
                                            sd.ALLCandleTillNow.Add(current_Date, oh);
                                            dateTime13 = dateTime13.AddMinutes(Double.Parse(linedata[7]));
                                        }
                                    }
                                    else
                                    {
                                        if (Int32.Parse(current_Date) < 1535 && Int32.Parse(current_Date) > 0900)
                                        {
                                            CandleOHLC oh = new CandleOHLC();
                                            sd.ALLCandleTillNow.Add(current_Date, oh);
                                            dateTime13 = dateTime13.AddMinutes(Double.Parse(linedata[7]));
                                        }
                                    }


                                }

                            }
                            catch (Exception sdfgh)
                            {

                            }
                            sd.Quantity = sd.Quantity * sd.LotSize;
                            DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);
                            sendEmail("ADDED "+sd.Symbol+" for " + sd.account, line);
                            StratgeysORB.Add(SID, sd);
                            SID = SID + 1;

                            try
                            {
                                if (!txtScript.Items.Contains(sd.Symbol))
                                {
                                    txtScript.Items.Add(sd.Symbol);
                                }
                                if (!txtDeleteScript.Items.Contains(sd.Symbol))
                                {
                                    txtDeleteScript.Items.Add(sd.Symbol);
                                }
                            }
                            catch (Exception sdfgh)
                            {
                            }

                        }
                        else
                        {
                            sendmessage(linedata[0] + "-EQ Not Found ", 0);
                        }
                    }
                    else
                    {
                        sendEmail("Not adding for Ac:" + linedata[5], "Token not found for " + linedata[5] + ". Not adding "+line);
                        sendmessage(linedata[5] + "Not Adding Because Login Not done.", 0);
                    }
                }

                sendmessage(filepath + " Script File uploaded Successfully..", 0);
            }
        }

        private void btnStartCandleJC_Click(object sender, EventArgs e)
        {

            TargetORB = (int)txttargetCandleJC.Value;
            StoplossORB = (int)txtstoplossCandleJC.Value;

            Int32 currentDay = Int32.Parse(DateTime.Now.ToString("dd"));
            Int32 currentMonth = Int32.Parse(DateTime.Now.ToString("MM"));
            Int32 currentYear = Int32.Parse(DateTime.Now.ToString("yyyy"));

            if (currentYear == 2022)
            {
                sendmessage("Strategy Started...", 0);
                //  DateTime Start = txtstartTimeORB.Value;

                foreach (var item in StratgeysORB)
                {
                    StrategyDetailsORB sd = item.Value;

                    if (sd.Status.Equals("ADDED"))
                    {
                        sd.Status = "STARTED";
                        //  DateTime Current = DateTime.Now;
                        /* Int32 year = Int32.Parse(Current.ToString("yyyy"));
                         Int32 month = Int32.Parse(Current.ToString("MM"));
                         Int32 day = Int32.Parse(Current.ToString("dd"));
                         Int32 hour = Int32.Parse(sd._StartTime.ToString("HH"));
                         Int32 min = Int32.Parse(sd._StartTime.ToString("mm"));*/

                        /* var dateTime = new DateTime(year, month, day, hour, min, 0, DateTimeKind.Local);
                         var dateTimeOffset = new DateTimeOffset(dateTime);
                         var unixDateTime = dateTimeOffset.ToUnixTimeSeconds();
                         sd.CandleStartTimeUNIXORB = unixDateTime;*/

                        /*sd._StartTime = sd._StartTime.AddMinutes((double)sd._CandleDuration);

                        year = Int32.Parse(Current.ToString("yyyy"));
                        month = Int32.Parse(Current.ToString("MM"));
                        day = Int32.Parse(Current.ToString("dd"));

                        hour = Int32.Parse(sd._StartTime.ToString("HH"));
                        min = Int32.Parse(sd._StartTime.ToString("mm"));

                        dateTime = new DateTime(year, month, day, hour, min, 0, DateTimeKind.Local);
                        dateTimeOffset = new DateTimeOffset(dateTime);

                        unixDateTime = dateTimeOffset.ToUnixTimeSeconds();
                        sd.CandleEndTimeUNIXORB = unixDateTime;*/

                        // sendmessage("Candle START: " + sd.CandleStartTimeUNIXORB.ToString() + "  EndTIME:" + sd.CandleEndTimeUNIXORB.ToString(), 0);

                        try
                        {
                            custMarketDataObject.Subscribe(sd.ExchangeCode, sd.IntumentToken);
                        }
                        catch (Exception dfs)
                        {

                        }
                        /*        sd.MyStartTime = sd._StartTime;
                                DateTime nowTime = DateTime.Now;
                                sd.CurrentCandle = Int32.Parse(sd.MyStartTime.ToString("HHmmss"));
                                sd.NextCandle = Int32.Parse((sd.MyStartTime.AddMinutes(sd._CandleDuration)).ToString("HHmmss"));


                                sd.candleStartORB = sd._StartTime;
                                sd.candleEndORB = sd._StartTime.AddMinutes(sd._CandleDuration);

                                sd.CandleDurationORB = sd._CandleDuration;


                                sd.CandleStartIntegerORB = Int32.Parse(sd.candleStartORB.ToString("HHmmss"));
                                sd.CandleEndIntegerORB = Int32.Parse(sd.candleEndORB.ToString("HHmmss"));*/
                    }
                }


                TargetORB = (int)txttargetCandleJC.Value;
                StoplossORB = (int)txtstoplossCandleJC.Value;

                //  UpdateCandleValuesORB();
                if (StartNow)
                {
                    UOID = Int32.Parse(ClientOrderID);
                    StartNow = false;
                    StartStrategy_Thread_New = new Thread(StartStrategyThreadORB);
                    StartStrategy_Thread_New.Start();
                }

            }
            else
            {
                MessageBox.Show("CandleJC Token Expired.. ");
            }
        }

        private void UpdateCandleValuesORB()
        {
            DateTime current = DateTime.Now;
            Int32 currentTime = Int32.Parse(current.ToString("HHmmss"));
            /*  if (currentTime <= CandleEndIntegerORB)
              {
                  Thread.Sleep(1000);
                  UpdateCandleValuesORB();
              }
              else
              {*/
            foreach (DataGridViewRow row in DGV_CandleJC.Rows)
            {
                try
                {
                    String SID = row.Cells["o_sid"].Value.ToString();
                    StrategyDetailsORB sd = StratgeysORB[Int32.Parse(SID)];
                    //getcandledataORB(sd, CandleStartTimeUNIXORB.ToString(), CandleEndTimeUNIXORB.ToString(), CandleDurationORB.ToString());
                }
                catch (Exception sed)
                {

                }

            }

            //StartStrategyThreadORB();
            //  }

        }

        private void StartStrategyThreadORB()
        {
            Int32 StartTime = Int32.Parse(txtstartTimeORB.Value.ToString("HHmm"));
            Int32 SqTime = Int32.Parse(txt_SqTimeORB.Value.ToString("HHmm"));
            Int32 EndTime = Int32.Parse(txt_EndTimeORB.Value.ToString("HHmm"));

            sendmessage("Start Time:" + StartTime.ToString() + " SquareOff Time:" + SqTime.ToString() + " End Time:" + EndTime.ToString(), 0);
            while (true)
            {

                try
                {
                    Int32 CurrentTime = Int32.Parse(DateTime.Now.ToString("HHmm"));
                    if (CurrentTime >= StartTime)
                    {
                         ExecutingStrategyORB();
                    }
                  
                    if (CurrentTime >= SqTime && SqTime != 0)
                    {
                        sendmessage("SQ Time Reached CurrentTime:" + CurrentTime.ToString() + " SQTime:" + SqTime.ToString(), 0);
                        SqTime = 0;
                        foreach (var sd in StratgeysORB)
                        {
                            // String SID = row.Cells["o_sid"].Value.ToString();
                            //StrategyDetailsORB sd = StratgeysORB[Int32.Parse(SID)];
                            try
                            {
                                if (!sd.Value.Status.Equals("SQTIMEREACHED") && !sd.Value.Status.Equals("COMPLETE"))
                                {
                                    PlaceExitOrderORB(sd.Value);
                                    sd.Value.Status = "SQTIMEREACHED";
                                }
                            }
                            catch (Exception edf)
                            {

                            }
                            try
                            {
                                if (sd.Value.OIDEXit != 0)
                                {
                                    OrderDetails EntryOrderStatus = getOrderStatus(sd.Value.OIDEXit, sd.Value.account);

                                    if (EntryOrderStatus.status.Equals("rejected"))
                                    {
                                        sendEmail(sd.Value.Symbol + " Exit Order Rejected For " + sd.Value.account, EntryOrderStatus.RejectedReason);
                                        sendmessage(sd.Value.Symbol + " Exit Order Rejected For " + sd.Value.account + " Reason:" + EntryOrderStatus.RejectedReason, sd.Value.SID);
                                        sd.Value.OIDEXit = 0;
                                    }


                                }
                            }
                            catch (Exception edf)
                            {

                            }
                        }
                      
                    }
                    if (CurrentTime >= EndTime)
                    {
                        StartTime = 0;
                        EndTime = 0;
                        SqTime = 0;
                        foreach (DataGridViewRow row in DGV_CandleJC.Rows)
                        {
                            String SID = row.Cells["o_sid"].Value.ToString();
                            StrategyDetailsORB sd = StratgeysORB[Int32.Parse(SID)];
                            sd.Status = "STOPPED";
                        }
                        //await UpdateGridViewORB();
                        break;
                    }
                   
                }
                catch (Exception fds)
                {
                }
                //Thread.Sleep(5000);
            }
        }

        private long PlaceExitOrderORB(StrategyDetailsORB sd)
        {
            Int64 OId = 0;
            String side = "";
            if (sd.Side.Equals("BUY"))
            {
                side = "SELL";
            }
            else
            {
                side = "BUY";
            }
            OrderDetails entryOrderStatus = getOrderStatus(sd.OIDEntry, sd.account);

            if (entryOrderStatus.status.Equals("complete"))
            {
                String tokenID = sd.IntumentToken.ToString();
                String lotTO = entryOrderStatus.quantity;
                var client = new RestClient(BaseURL + "/api/v1/orders?client_id=" + sd.account + "&disclosed_quantity=0&exchange=" + sd.Exchange + "&instrument_token=" + tokenID + "&market_protection_percentage=10&order_side=" + side + "&order_type=MARKET&price=0&product=" + sd.PrdType + "&quantity=" + lotTO + "&trigger_price=0&validity=DAY&user_order_id=" + UOID.ToString() + "&x-authorization-token=" + DicClientTokens[sd.account]);
                client.Timeout = -1;
                UOID = UOID + 1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[sd.account]);
                request.AddHeader("client_id", sd.account);
                // request.AddHeader("Authorization", "Bearer "+ OAuthAcessToken);
                request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTYyNTcxMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1WmpFeU9USmlaalZsTlRRM01qWTROelprTlRZeE1tWmtPVFk1TW1RNXw7ZpTt_MwqUj1YYeQOd2G-8hPeYPfHX0CBFAYeeVgVdQ==; oauth2_consent_csrf=MTU4OTYyNTcyMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l4TXpBek1tTXpOREZrTURRMFltSTVPV1EwTkRabE56Rm1ObVkwTURZeXyPapSzgv5_ZlIWaPsQB_EolbUFQHq_OjALrHHZvYgXQQ==");
                IRestResponse response = client.Execute(request);
                //  Console.WriteLine(response.Content);
                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        sd.OIDEntry = 0;
                        dynamic client_order_id = data.data.client_order_id;
                        String POIDS = client_order_id.ToString();
                        OId = Int64.Parse(POIDS);

                        sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + tokenID, 0);
                    }
                    else
                    {
                        sendmessage("Request Unauthorised." + " For " + sd.account, sd.SID);
                        sendEmail("Order Rejected For " + sd.account, "Request Unauthorised.");
                    }


                }
                catch (Exception fds)
                {
                }

            }
            return OId;
        }

        private long PlaceExitTargetORB(StrategyDetailsORB sd, Int32 Qty, String ClientID)
        {
            Int64 OId = 0;
            String side = "";
            if (sd.Side.Equals("BUY"))
            {
                side = "SELL";
            }
            else
            {
                side = "BUY";
            }
            OrderDetails entryOrderStatus = getOrderStatus(sd.OIDEntry, sd.account);

            if (entryOrderStatus.status.Equals("complete"))
            {
                String tokenID = sd.IntumentToken.ToString();
                String lotTO = Qty.ToString();
                var client = new RestClient(BaseURL + "/api/v1/orders?client_id=" + ClientID + "&disclosed_quantity=0&exchange=" + sd.Exchange + "&instrument_token=" + tokenID + "&market_protection_percentage=10&order_side=" + side + "&order_type=MARKET&price=0&product=" + sd.PrdType + "&quantity=" + lotTO + "&trigger_price=0&validity=DAY&user_order_id=" + UOID.ToString() + "&x-authorization-token=" + DicClientTokens[sd.account]);
                client.Timeout = -1;
                UOID = UOID + 1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[sd.account]);
                request.AddHeader("client_id", ClientID);

                // request.AddHeader("Authorization", "Bearer "+ OAuthAcessToken);
                request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTYyNTcxMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1WmpFeU9USmlaalZsTlRRM01qWTROelprTlRZeE1tWmtPVFk1TW1RNXw7ZpTt_MwqUj1YYeQOd2G-8hPeYPfHX0CBFAYeeVgVdQ==; oauth2_consent_csrf=MTU4OTYyNTcyMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l4TXpBek1tTXpOREZrTURRMFltSTVPV1EwTkRabE56Rm1ObVkwTURZeXyPapSzgv5_ZlIWaPsQB_EolbUFQHq_OjALrHHZvYgXQQ==");
                IRestResponse response = client.Execute(request);
                //  Console.WriteLine(response.Content);
                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        dynamic client_order_id = data.data.client_order_id;
                        String POIDS = client_order_id.ToString();
                        OId = Int64.Parse(POIDS);
                        sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + tokenID, 0);
                    }
                    else
                    {
                        sendEmail(" Order Rejection" + " for " + sd.account, data.message.ToString());
                        sendmessage(data.message.ToString(), sd.SID);
                       
                    }
                }
                catch (Exception fds)
                {
                    sendEmail(" Order Rejection" + " for " + sd.account, "Exception in getting OrderID, because of Session Expired for "+sd.account);
                }

            }
            return OId;
        }

        private OrderDetails getOrderStatus(Int64 OID, String ClientID, String cli)
        {
            OrderDetails OrderStatusObject = new OrderDetails();
            String OrderStatus = "";
            String OIDS = OID.ToString();
            try
            {
                var client = new RestClient(BaseURL + "/api/v1/order/" + OIDS + "/history?client_id=" + ClientID);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[ClientID]);
                request.AddHeader("client_id", ClientID);
                // request.AddHeader("Authorization", "Bearer 4OKegRphDnnfLoLZOlD48yLKrPT5c8QZmXWPAYw8oPE.0ZyCW5nDhpil55Tr7hWJ0igNpeNFXRHXCsXASsRMA-Q");
                request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYMHh4aEFBWldlUnlqbDhZYlktSVpTNWFR.URcQB4dWQ1BUfZ5mHsgJCM3U40JoVy2V8p8F4KDpj8U; oauth2_authentication_csrf=MTU4OTgwNDQ4M3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0V5TjJSa1pUQmpNakJtWWpRMFlqTmlORGc1Tmpsak16WTVOekE0WmpJMXyGuGYbAR1TQHdkYFE__pMj0pYgsqy173ZzGtUJkMZFEw==; oauth2_consent_csrf=MTU4OTgwNDQ5NHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREE0WXpNd05tUTFNakF5TmpReVlqaGlPV1k0WW1KaFltVmpaakZoWXpjenxldc3GOZXm_kH2h_XQzsc8escK5pG-ZtJ9sBhc7Mcgbw==");
                IRestResponse response = client.Execute(request);

                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        foreach (dynamic item in data.data)
                        {
                            dynamic status = item.status;
                            String stat = status.ToString();
                            if (stat.Equals("complete"))
                            {
                                dynamic avg_price = item.avg_price;
                                dynamic client_id = item.client_id;
                                dynamic client_order_id = item.order_id;
                                dynamic exchange = item.exchange;
                                dynamic exchange_order_id = item.exchange_order_id;
                                dynamic exchange_time = item.exchange_time;
                                dynamic fill_quantity = item.fill_quantity;
                                dynamic order_id = item.order_id;
                                dynamic order_side = item.order_side;
                                dynamic quantity = item.quantity;
                                dynamic remaining_quantity = item.remaining_quantity;

                                OrderStatusObject.avg_price = avg_price.ToString();
                                OrderStatusObject.client_id = client_id.ToString();
                                OrderStatusObject.client_order_id = client_order_id.ToString();
                                OrderStatusObject.exchange = exchange.ToString();
                                OrderStatusObject.exchange_order_id = exchange_order_id.ToString();
                                OrderStatusObject.exchange_time = exchange_time.ToString();
                                OrderStatusObject.fill_quantity = fill_quantity.ToString();
                                OrderStatusObject.order_id = order_id.ToString();
                                OrderStatusObject.order_side = order_side.ToString();
                                OrderStatusObject.quantity = quantity.ToString();
                                OrderStatusObject.remaining_quantity = remaining_quantity.ToString();
                                OrderStatusObject.status = status.ToString();

                            }
                        }
                    }
                }
                catch (Exception lokhs)
                {
                    sendmessage("Message: " + lokhs.StackTrace, 0);
                }


                //--------------------
            }
            catch (Exception efsdf)
            {
                sendmessage("Message: " + efsdf.StackTrace, 0);
            }


            return OrderStatusObject;

        }
        private OrderDetails getOpenOrderStatus(Int64 OID, String ClientID, String cli)
        {
            OrderDetails OrderStatusObject = new OrderDetails();
            String OrderStatus = "";
            String OIDS = OID.ToString();
            try
            {
                var client = new RestClient(BaseURL + "/api/v1/order/" + OIDS + "/history?client_id=" + ClientID);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("x-device-type", "WEB");
                request.AddHeader("x-authorization-token", DicClientTokens[ClientID]);
                request.AddHeader("client_id", ClientID);
                // request.AddHeader("Authorization", "Bearer 4OKegRphDnnfLoLZOlD48yLKrPT5c8QZmXWPAYw8oPE.0ZyCW5nDhpil55Tr7hWJ0igNpeNFXRHXCsXASsRMA-Q");
                request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYMHh4aEFBWldlUnlqbDhZYlktSVpTNWFR.URcQB4dWQ1BUfZ5mHsgJCM3U40JoVy2V8p8F4KDpj8U; oauth2_authentication_csrf=MTU4OTgwNDQ4M3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0V5TjJSa1pUQmpNakJtWWpRMFlqTmlORGc1Tmpsak16WTVOekE0WmpJMXyGuGYbAR1TQHdkYFE__pMj0pYgsqy173ZzGtUJkMZFEw==; oauth2_consent_csrf=MTU4OTgwNDQ5NHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREE0WXpNd05tUTFNakF5TmpReVlqaGlPV1k0WW1KaFltVmpaakZoWXpjenxldc3GOZXm_kH2h_XQzsc8escK5pG-ZtJ9sBhc7Mcgbw==");
                IRestResponse response = client.Execute(request);

                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {
                        foreach (dynamic item in data.data)
                        {
                            dynamic status = item.status;
                            String stat = status.ToString();
                            if (stat.Equals("complete"))
                            {
                                dynamic avg_price = item.avg_price;
                                dynamic client_id = item.client_id;
                                dynamic client_order_id = item.order_id;
                                dynamic exchange = item.exchange;
                                dynamic exchange_order_id = item.exchange_order_id;
                                dynamic exchange_time = item.exchange_time;
                                dynamic fill_quantity = item.fill_quantity;
                                dynamic order_id = item.order_id;
                                dynamic order_side = item.order_side;
                                dynamic quantity = item.quantity;
                                dynamic remaining_quantity = item.remaining_quantity;

                                OrderStatusObject.avg_price = avg_price.ToString();
                                OrderStatusObject.client_id = client_id.ToString();
                                OrderStatusObject.client_order_id = client_order_id.ToString();
                                OrderStatusObject.exchange = exchange.ToString();
                                OrderStatusObject.exchange_order_id = exchange_order_id.ToString();
                                OrderStatusObject.exchange_time = exchange_time.ToString();
                                OrderStatusObject.fill_quantity = fill_quantity.ToString();
                                OrderStatusObject.order_id = order_id.ToString();
                                OrderStatusObject.order_side = order_side.ToString();
                                OrderStatusObject.quantity = quantity.ToString();
                                OrderStatusObject.remaining_quantity = remaining_quantity.ToString();
                                OrderStatusObject.status = status.ToString();

                            }
                        }
                    }
                }
                catch (Exception lokhs)
                {
                    sendmessage("Message: " + lokhs.StackTrace, 0);
                }


                //--------------------
            }
            catch (Exception efsdf)
            {
                sendmessage("Message: " + efsdf.StackTrace, 0);
            }


            return OrderStatusObject;

        }

        private Int64 placeOrderORB(int callToken, string side, int lot, StrategyDetailsORB sd)
        {
            Int64 OId = 0;
            String token = callToken.ToString();
            Int32 qty = sd.Quantity;
            //sd.Quantity = qty * sd.LotSize;
            String lotTOTrade = qty.ToString();
            String OrderType = "MARKET";
            String OrderPrice = "0";
            if (sd.EntryAddition != 0)
            {
                OrderType = "LIMIT";
                if (side.Equals("BUY"))
                {
                    OrderPrice = (sd.SymbolLTP + sd.EntryAddition).ToString();
                }
                else
                {
                    OrderPrice = (sd.SymbolLTP - sd.EntryAddition).ToString();
                }

            }
            if (qty != 0)
            {
                var client = new RestClient(BaseURL + "/api/v1/orders?client_id=" + sd.account + "&disclosed_quantity=" + lotTOTrade + "&exchange=" + sd.Exchange + "&instrument_token=" + token + "&market_protection_percentage=10&order_side=" + side + "&order_type=" + OrderType + "&price=" + OrderPrice + "&product=" + sd.PrdType + "&quantity=" + lotTOTrade + "&trigger_price=0&validity=DAY&user_order_id=" + UOID.ToString());
                client.Timeout = -1;
                UOID = UOID + 1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("x-device-type", "WEB");

                request.AddHeader("x-authorization-token", DicClientTokens[sd.account]);
                request.AddHeader("client_id", sd.account);
                // request.AddHeader("Authorization", "Bearer " + OAuthAcessToken);
                request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTYyNTcxMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1WmpFeU9USmlaalZsTlRRM01qWTROelprTlRZeE1tWmtPVFk1TW1RNXw7ZpTt_MwqUj1YYeQOd2G-8hPeYPfHX0CBFAYeeVgVdQ==; oauth2_consent_csrf=MTU4OTYyNTcyMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l4TXpBek1tTXpOREZrTURRMFltSTVPV1EwTkRabE56Rm1ObVkwTURZeXyPapSzgv5_ZlIWaPsQB_EolbUFQHq_OjALrHHZvYgXQQ==");
                IRestResponse response = client.Execute(request);
                //  Console.WriteLine(response.Content);
                try
                {

                    dynamic data = JValue.Parse(response.Content);

                    if (data.status.ToString() == "success")
                    {

                        dynamic client_order_id = data.data.client_order_id;
                        String POIDS = client_order_id.ToString();
                        OId = Int64.Parse(POIDS);
                        sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + token, 0);
                    }
                    else
                    {
                        sendEmail(" Order Rejection" + " for " + sd.account, data.message.ToString());
                        sendmessage(data.message.ToString() + " For " + sd.account, sd.SID);
                    }

                }
                catch (Exception fds)
                {
                }
            }
            return OId;
        }
        private Int64 placeEntryOrderORB(int callToken, string side, int lot, StrategyDetailsORB sd, Double EntryOrder)
        {
            Int64 OId = 0;
            try
            {
                String token = callToken.ToString();
                Int32 qty = sd.Quantity;
                //sd.Quantity = qty- * sd.LotSize;
                String lotTOTrade = qty.ToString();
                String OrderType = "MARKET";
                String OrderPrice = "0";
                if (sd.EntryAddition != 0)
                {
                    OrderType = "LIMIT";
                    if (side.Equals("BUY"))
                    {
                        OrderPrice = (EntryOrder + sd.EntryAddition).ToString();
                    }
                    else
                    {
                        OrderPrice = (EntryOrder - sd.EntryAddition).ToString();
                    }

                }
                if (qty != 0)
                {
                    var client = new RestClient(BaseURL + "/api/v1/orders?client_id=" + sd.account + "&disclosed_quantity=" + lotTOTrade + "&exchange=" + sd.Exchange + "&instrument_token=" + token + "&market_protection_percentage=10&order_side=" + side + "&order_type=" + OrderType + "&price=" + OrderPrice + "&product=" + sd.PrdType + "&quantity=" + lotTOTrade + "&trigger_price=0&validity=DAY&user_order_id=" + UOID.ToString());
                    client.Timeout = -1;
                    UOID = UOID + 1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("x-device-type", "WEB");

                    request.AddHeader("x-authorization-token", DicClientTokens[sd.account]);
                    request.AddHeader("client_id", sd.account);
                    // request.AddHeader("Authorization", "Bearer " + OAuthAcessToken);
                    request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTYyNTcxMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1WmpFeU9USmlaalZsTlRRM01qWTROelprTlRZeE1tWmtPVFk1TW1RNXw7ZpTt_MwqUj1YYeQOd2G-8hPeYPfHX0CBFAYeeVgVdQ==; oauth2_consent_csrf=MTU4OTYyNTcyMXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l4TXpBek1tTXpOREZrTURRMFltSTVPV1EwTkRabE56Rm1ObVkwTURZeXyPapSzgv5_ZlIWaPsQB_EolbUFQHq_OjALrHHZvYgXQQ==");
                    IRestResponse response = client.Execute(request);
                    //  Console.WriteLine(response.Content);
                    try
                    {

                        dynamic data = JValue.Parse(response.Content);

                        if (data.status.ToString() == "success")
                        {

                            dynamic client_order_id = data.data.client_order_id;
                            String POIDS = client_order_id.ToString();
                            OId = Int64.Parse(POIDS);
                            sendmessage("Order Placed Successfully. Order ID:" + OId.ToString() + " Token:" + token, 0);
                        }
                        else
                        {
                            sendEmail(" Order Rejection" + " for " + sd.account, data.message.ToString());
                            sendmessage(data.message.ToString() + " For " + sd.account, sd.SID);
                        }

                    }
                    catch (Exception fds)
                    {
                    }
                }

            }
            catch (Exception sdf)
            { 
            }
            return OId;
        }

        private void getcandledataORB(StrategyDetailsORB sd, String StartTime, String EndTime, String Duration)
        {

            var client = new RestClient(Historical_Data_Base_URL + "?exchange=" + sd.Exchange + "&token=" + sd.IntumentToken.ToString() + "&candletype=1&starttime=" + StartTime + "&endtime=" + EndTime + "&data_duration=" + "5");//sd._CandleDuration.ToString());
            //var client = new RestClient("https://masterswift.mastertrust.co.in/api/v1/charts/tdv?exchange=" + sd.Exchange + "&token=" + sd.IntumentToken.ToString() + "&candletype=1&starttime=" + "1628826600" + "&endtime=" + "1628829000" + "&data_duration=" + "5");//sd._CandleDuration.ToString());
            //var client = new RestClient("https://masterswift.mastertrust.co.in/api/v1/charts/tdv?exchange=" + sd.Exchange + "&token=" + sd.IntumentToken.ToString() + "&candletype=1&starttime=" + "1628826600" + "&endtime=" + "1628856127" + "&data_duration=" + "5");//sd._CandleDuration.ToString());

            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);
            try
            {

                dynamic data = JValue.Parse(response.Content);
                if (data.status.ToString() == "success")
                {
                    //  sd.ALLCandleTillNow.Clear();
                    String startTime = "";
                    String key = "";
                    Double OPEN = 0, HIGH = 0, LOW = 0, CLOSE = 0;
                    String NextStartTime = "";
                    String CurrentCandleTime = "";
                    foreach (dynamic obj in data.data.candles)
                    {
                        //8/13/2021 9:20:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:25:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:30:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:35:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:40:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:45:00 AM , OPEN,HIGH,LOW,CLOSE
                        //8/13/2021 9:50:00 AM , OPEN,HIGH,LOW,CLOSE
                        CandleOHLC candledata = new CandleOHLC();
                        Int32 count = 0;

                        foreach (dynamic DataEachRow in obj)
                        {
                            //8/13/2021 9:20:00 AM ,
                            //OPEN
                            //HIGH
                            //LOW
                            //CLOSE

                            if (count == 0)
                            {

                                if (startTime.Equals(""))
                                {
                                    //8/13/2021 9:20:00 AM
                                    count = count + 1;
                                    key = DataEachRow.Value.ToString();
                                    DateTime dateTime13; // 1/1/0001 12:00:00 AM  
                                    CultureInfo provider = CultureInfo.InvariantCulture;
                                    bool isSuccess4 = DateTime.TryParseExact(key, "M/dd/yyyy h:mm:ss tt", provider, DateTimeStyles.None, out dateTime13);
                                    if (!isSuccess4)
                                    {
                                        isSuccess4 = DateTime.TryParseExact(key, "M/d/yyyy h:mm:ss tt", provider, DateTimeStyles.None, out dateTime13);
                                        if (!isSuccess4)
                                        {
                                            isSuccess4 = DateTime.TryParseExact(key, "MM/dd/yyyy h:mm:ss tt", provider, DateTimeStyles.None, out dateTime13);
                                        }
                                        if (!isSuccess4)
                                        {
                                            isSuccess4 = DateTime.TryParseExact(key, "MM/d/yyyy h:mm:ss tt", provider, DateTimeStyles.None, out dateTime13);
                                        }
                                    }
                                    if (startTime.Equals(""))
                                    {
                                        startTime = dateTime13.ToString("HHmm");
                                    }
                                    Int32 canlde = sd._CandleDuration;
                                    NextStartTime = dateTime13.AddMinutes(canlde).ToString("HHmm");
                                    CurrentCandleTime = startTime;
                                }
                                else
                                {
                                    count = count + 1;
                                    key = DataEachRow.Value.ToString();
                                    DateTime dateTime13; // 1/1/0001 12:00:00 AM  
                                    CultureInfo provider = CultureInfo.InvariantCulture;
                                    bool isSuccess4 = DateTime.TryParseExact(key, "M/d/yyyy h:mm:ss tt", provider, DateTimeStyles.None, out dateTime13);
                                    CurrentCandleTime = dateTime13.ToString("HHmm");

                                    if (CurrentCandleTime.Equals(NextStartTime))
                                    {
                                        if (sd.ALLCandleTillNow.ContainsKey(startTime))
                                        {
                                            sd.ALLCandleTillNow[startTime].OPEN = OPEN;
                                            sd.ALLCandleTillNow[startTime].High = HIGH;
                                            sd.ALLCandleTillNow[startTime].Low = LOW;
                                            sd.ALLCandleTillNow[startTime].Close = CLOSE;
                                            startTime = CurrentCandleTime;
                                            Int32 canlde = sd._CandleDuration;
                                            NextStartTime = dateTime13.AddMinutes(canlde).ToString("HHmm");
                                            CurrentCandleTime = startTime;
                                            if (sd.OPEN == 0 && sd.HIGH == 0 && sd.LOW == 0 && sd.CLOSE == 0)
                                            {
                                                sd.OPEN = OPEN;
                                                sd.HIGH = HIGH;
                                                sd.LOW = LOW;
                                                sd.CLOSE = CLOSE;
                                            }

                                            OPEN = 0;
                                            HIGH = 0;
                                            LOW = 0;
                                            CLOSE = 0;

                                        }
                                        /* else
                                         {
                                             candledata.OPEN = OPEN;
                                             candledata.High = HIGH;
                                             candledata.Low = LOW;
                                             candledata.Close = CLOSE;
                                             sd.ALLCandleTillNow.Add(startTime, candledata);
                                         }*/

                                        // CurrentCandleTime = "";
                                        //NextStartTime = "";


                                    }
                                }

                            }

                            else if (count == 1 && OPEN == 0)
                            {
                                OPEN = Double.Parse(DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 2 && (HIGH < Double.Parse(DataEachRow.Value.ToString()) || HIGH == 0))
                            {
                                HIGH = Double.Parse(DataEachRow.Value.ToString());
                                //MessageBox.Show("High:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 3 && (LOW > Double.Parse(DataEachRow.Value.ToString()) || LOW == 0))
                            {
                                LOW = Double.Parse(DataEachRow.Value.ToString());
                                //MessageBox.Show("Low:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 4)
                            {
                                CLOSE = Double.Parse(DataEachRow.Value.ToString());
                                // MessageBox.Show("Close:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 5)
                            {
                                //MessageBox.Show("Volume:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else
                            {
                                count = count + 1;
                            }
                        }

                    }


                }
                /*if (data.status.ToString() == "success")
                {
                    sd.ALLCandleTillNow.Clear();
                    foreach (dynamic obj in data.data.candles)
                    {
                        CandleOHLC candledata = new CandleOHLC();
                        Int32 count = 0;
                        String key = "";
                        Double OPEN=0, HIGH=0, LOW=0, CLOSE = 0;
                        foreach (dynamic DataEachRow in obj)
                        {
                            if (count == 0)
                            {
                                count = count + 1;
                                key = DataEachRow.Value.ToString();
                            }
                            else if (count == 1)
                            {
                                OPEN = Double.Parse(DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 2)
                            {
                                HIGH = Double.Parse(DataEachRow.Value.ToString());
                                //MessageBox.Show("High:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 3)
                            {
                                LOW = Double.Parse(DataEachRow.Value.ToString());
                                //MessageBox.Show("Low:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 4)
                            {
                                CLOSE = Double.Parse(DataEachRow.Value.ToString());
                                // MessageBox.Show("Close:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                            else if (count == 5)
                            {
                                //MessageBox.Show("Volume:" + DataEachRow.Value.ToString());
                                count = count + 1;
                            }
                        }
                        candledata.OPEN = OPEN;
                        candledata.High = HIGH;
                        candledata.Low = LOW;
                        candledata.Close = CLOSE;

                        try
                        {
                            if (sd.ALLCandleTillNow.ContainsKey(key))
                            {
                                CandleOHLC old = sd.ALLCandleTillNow[key];
                                if (old.OPEN == 0 && old.High == 0 && old.Low == 0 && old.Close == 0)
                                {
                                    sd.ALLCandleTillNow.Remove(key);
                                    sd.ALLCandleTillNow.Add(key, candledata);

                                }
                            }
                            else
                            {
                                sd.ALLCandleTillNow.Add(key, candledata);
                            }

                        }
                        catch (Exception ed)
                        { 
                        }

                    }

                }*/

            }
            catch (Exception jhgf)
            {

            }

        }


        private async Task<string> UpdateGridViewORB()
        {
           // 
            foreach (DataGridViewRow row in DGV_CandleJC.Rows)
            {
                try
                {
                    String SID = row.Cells["o_sid"].Value.ToString();
                    StrategyDetailsORB sd = StratgeysORB[Int32.Parse(SID)];
                    row.Cells["o_status"].Value = sd.Status;
                    CustomMarketdataVALUES data = MarketDataDictionary[sd.IntumentToken];
                    row.Cells["o_symbolltp"].Value = data.LastTradedPrice;

                    row.Cells["o_high"].Value = sd.HIGH;
                    row.Cells["o_open"].Value = sd.OPEN;
                    row.Cells["o_low"].Value = sd.LOW;

                    row.Cells["col_Trail"].Value = sd.TrailCount;
                    row.Cells["o_EntryC"].Value = sd.EntryCount;
                    //row.Cells["o_EntryC"].Value = sd.ALLCandleTillNow.Count;

                    //-------------------'
                    row.Cells["o_targetPrice"].Value = sd.TargetPrice;
                    row.Cells["o_stoplossPrice"].Value = sd.StoplossPrice;

                    row.Cells["o_quantity"].Value = sd.Quantity;
                    row.Cells["o_PL"].Value = sd.PL;
                    sd.SymbolLTP = data.LastTradedPrice;

                }
                catch (Exception sdf)
                { 
                }
                
            }
            await Task.Delay(1000);
            return DateTime.Now.Ticks.ToString();
        }

        private void ExecutingStrategyORB()
        {
            plORB = 0;
            foreach (var item in StratgeysORB)
            {
               
                StrategyDetailsORB sd = item.Value;
                Int32 CurrentTime = Int32.Parse(DateTime.Now.ToString("HHmm"));
                Int32 StartTime = Int32.Parse(sd._StartTime.ToString("HHmm"));
                if (CurrentTime >= StartTime)
                {

                    try
                    {
                        if (!sd.StopGettingData)
                        {
                            DateTime currentDateTime = DateTime.Now;
                            DateTime startDateTime = sd._StartTime;
                            Int32 IntCurrent = Int32.Parse(startDateTime.ToString("HHmmss"));

                            sd.CurrentCandle = Int32.Parse(sd.MyStartTime.ToString("HHmmss"));

                            Int32 year = Int32.Parse(currentDateTime.ToString("yyyy"));
                            Int32 month = Int32.Parse(currentDateTime.ToString("MM"));
                            Int32 day = Int32.Parse(currentDateTime.ToString("dd"));


                            Int32 hour = Int32.Parse(sd._StartTime.ToString("HH"));
                            Int32 min = Int32.Parse(sd._StartTime.ToString("mm"));

                            var dateTime = new DateTime(year, month, day, hour, min, 0, DateTimeKind.Local);
                            var dateTimeOffset = new DateTimeOffset(dateTime);
                            var unixDateTime = dateTimeOffset.ToUnixTimeSeconds();
                            sd.CandleStartTimeUNIXORB = unixDateTime;

                            if (!sd.IsUpdated) 
                            {
                                sd.MyStartTime = sd._StartTime.AddMinutes(sd._CandleDuration);
                                sd.IsUpdated = true;
                            }

                            sd.NextCandle = Int32.Parse(sd.MyStartTime.ToString("HHmmss")); ;// Int32.Parse((Current.AddMinutes(Convert.ToInt32(txtcandleDurationORB.Value))).ToString("HHmmss"));

                            year = Int32.Parse(currentDateTime.ToString("yyyy"));
                            month = Int32.Parse(currentDateTime.ToString("MM"));
                            day = Int32.Parse(currentDateTime.ToString("dd"));

                            hour = Int32.Parse(currentDateTime.ToString("HH"));
                            min = Int32.Parse(currentDateTime.ToString("mm"));

                            dateTime = new DateTime(year, month, day, hour, min, 0, DateTimeKind.Local);
                            dateTimeOffset = new DateTimeOffset(dateTime);
                            unixDateTime = dateTimeOffset.ToUnixTimeSeconds();
                            sd.CandleEndTimeUNIXORB = unixDateTime;
                            //CurrentTime
                            Int32 EndTime = Int32.Parse(sd.MyStartTime.ToString("HHmm"));
                            sd.CheckEndTime = EndTime;
                            if (EndTime <= CurrentTime)
                            {
                                sendmessage(sd.Symbol+" EndTime Reached:"+EndTime.ToString()+" & CurrentTime:"+CurrentTime.ToString(), sd.SID);
                                ///sendPCEmail("Start Time Reached:",sd.Symbol + " EndTime Reached:" + EndTime.ToString() + " & CurrentTime:" + CurrentTime.ToString());
                                updateThisSide(sd);
                                sd.StopGettingData = true;
                            }
                             //getcandledataORB(sd, sd.CandleStartTimeUNIXORB.ToString(), sd.CandleEndTimeUNIXORB.ToString(), sd._CandleDuration.ToString());
                            String data = sd.CurrentCandle.ToString() + " - " + sd.NextCandle.ToString();
                            String Start = "";
                            String End = "";
                            try
                            {
                                Start = sd.CurrentCandle.ToString();
                                DateTime oDate = DateTime.ParseExact(Start, "HHmmss", null);
                                //MessageBox.Show(oDate.ToString());
                                Start = oDate.ToString("HH:mm");

                                End = sd.NextCandle.ToString();
                                DateTime oDatew = DateTime.ParseExact(End, "HHmmss", null);
                                //MessageBox.Show(oDate.ToString());
                                End = oDatew.ToString("HH:mm");
                                data = Start + " - " + End;
                            }
                            catch (Exception sdf)
                            {
                            }
                        }
                  
                    }
                    catch (Exception edf)
                    {

                    }

                    try
                    {
                        //row.Cells["o_status"].Value = sd.Status;
                        if (MarketDataDictionary.ContainsKey(sd.IntumentToken))
                        {
              
                            //row.Cells["o_symbolltp"].Value = data.LastTradedPrice;
                            try
                            {

                                CustomMarketdataVALUES data = MarketDataDictionary[sd.IntumentToken];
                                sd.SymbolLTP = data.LastTradedPrice;
                            }
                            catch (Exception sdf)
                            {
                                
                            }

                            if (sd.Status.Equals("STARTED"))
                            {
                                if (sd.HIGH != 0 && sd.LOW != 0 && sd.OPEN != 0 && sd.SymbolLTP != 0 && sd.EntryCount >= 0)
                                {
                                    if (sd.UserSide.Equals("BOTH") || sd.UserSide.Equals("BUY"))
                                    {
                                        if (sd.SymbolLTP > sd.HIGH)
                                        {
                                            sd.Status = "HIGH_TRIGGRED";
                                        }
                                    }

                                    if (sd.UserSide.Equals("BOTH") || sd.UserSide.Equals("SELL"))
                                    {
                                        if (sd.SymbolLTP < sd.LOW)
                                        {
                                            sd.Status = "LOW_TRIGGRED";
                                        }
                                    }
                                }


                            }
                            else if (sd.Status.Equals("HIGH_TRIGGRED"))
                            {
                                sendmessage("Buy Activated. LTP:" + sd.SymbolLTP.ToString() + " > " + sd.HIGH.ToString(), sd.SID);
                                sd.BaseTarget = sd.HIGH;
                                sd.Side = "BUY";
                                sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.HIGH);
                                sd.EntryCount = sd.EntryCount - 1;
                                try
                                {
                                    sd.StoplossPrice = sd.LOW;
                                    sd.Stoploss_Exit = "LOW";
                                    sendmessage("Buy Sent. New SL:" + sd.StoplossPrice.ToString() + " SLWillbe " + sd.Stoploss_Exit.ToString() + " AC:" + sd.account, sd.SID);

                                }
                                catch (Exception edf)
                                {
                                }
                                sd.Status = "ENTRY_SEND";

                            }
                            else if (sd.Status.Equals("LOW_TRIGGRED"))
                            {
                                sendmessage("Sell Activated. LTP:" + sd.SymbolLTP.ToString() + " < " + sd.LOW.ToString(), sd.SID);
                                sd.BaseTarget = sd.LOW;
                                sd.Side = "SELL";
                                sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.LOW);
                                sd.EntryCount = sd.EntryCount - 1;
                                try
                                {
                                    sd.StoplossPrice = sd.HIGH;
                                    sd.Stoploss_Exit = "HIGH";
                                    sendmessage("Sell Sent. New SL:" + sd.StoplossPrice.ToString() + " SLWillbe " + sd.Stoploss_Exit.ToString() + " AC:" + sd.account, sd.SID);
                                }
                                catch (Exception edf)
                                {

                                }
                                sd.Status = "ENTRY_SEND";

                            }
                            else if (sd.Status.Equals("ENTRY_SEND"))
                            {
                                sd.StopGettingData = true;
                                if (sd.OIDEntry != 0)
                                {
                                   
                                    OrderDetails EntryOrderStatus = getOrderStatus(sd.OIDEntry, sd.account);

                                    if (EntryOrderStatus.status.Equals("complete"))
                                    {
                                        sd.AvgEntryPrice = Double.Parse(EntryOrderStatus.avg_price);
                                        sendmessage("AVG Entry Price:" + sd.AvgEntryPrice.ToString(), sd.SID);

                                        if (sd.Side.Equals("BUY"))
                                        {
                                            Int32 RQty = sd.Quantity;
                                            if (sd.TargetPerIn.Equals("P"))
                                            {
                                                if (sd.TargetPer != 0)
                                                {
                                                    Double ABS = (sd.TargetPer / 100) * sd.AvgEntryPrice;
                                                  //  /sd.BaseTarget = sd.SymbolLTP;
                                                    sd.TargetPrice = /*sd.AvgEntryPrice*/ sd.BaseTarget + ABS;

                                                }
                                            }
                                            else
                                            {
                                                if (sd.TargetPer != 0)
                                                {
                                                    Double Difference = sd.HIGH - sd.LOW;
                                                    if (Difference < 0)
                                                    {
                                                        Difference = Difference * -1;
                                                    }
                                                    Double ABS = Difference * sd.TargetPer;
                                                    //sd.BaseTarget = sd.SymbolLTP;
                                                    sd.TargetPrice =/* sd.AvgEntryPrice */  sd.BaseTarget + ABS;

                                                }
                                            }


                                        }
                                        else
                                        {
                                            Int32 RQty = sd.Quantity;

                                            if (sd.TargetPerIn.Equals("P"))
                                            {
                                                if (sd.TargetPer != 0)
                                                {
                                                    Double ABS = (sd.TargetPer / 100) * sd.AvgEntryPrice;
                                                    //sd.BaseTarget = sd.SymbolLTP;
                                                    sd.TargetPrice = /*sd.AvgEntryPrice*/ sd.BaseTarget - ABS;

                                                }
                                            }
                                            else
                                            {
                                                if (sd.TargetPer != 0)
                                                {
                                                    Double Difference = sd.HIGH - sd.LOW;
                                                    if (Difference < 0)
                                                    {
                                                        Difference = Difference * -1;
                                                    }
                                                    Double ABS = Difference * sd.TargetPer;
                                                    //sd.BaseTarget = sd.SymbolLTP;
                                                    sd.TargetPrice = /*sd.AvgEntryPrice*/ sd.BaseTarget - ABS;

                                                }
                                            }

                                        }

                                        sendmessage("Status Change To WAITFOREXIT.", sd.SID);
                                        //sd.OPEN = 0;
                                        //sd.HIGH = 0;
                                        //sd.LOW = 0;
                                        //sd.CLOSE = 0;

                                        sd.Status = "WAITFOREXIT";
                                    }
                                    else if (EntryOrderStatus.status.Equals("rejected"))
                                    {
                                        //sd.Status = "REJECTED";
                                        sendEmail(sd.Symbol + " Entry Order Rejected For " + sd.account, EntryOrderStatus.RejectedReason);
                                        sendmessage(sd.Symbol + " Entry Order Rejected For " + sd.account + " Reason:" + EntryOrderStatus.RejectedReason, sd.SID);
                                        sd.OIDEntry = 0;
                                    }


                                }
                                if (sd.OIDEXit != 0)
                                {
                                    OrderDetails EntryOrderStatus = getOrderStatus(sd.OIDEXit, sd.account);

                                    if (EntryOrderStatus.status.Equals("rejected"))
                                    {
                                        sendEmail(sd.Symbol + " Exit Order Rejected For " + sd.account, EntryOrderStatus.RejectedReason);
                                        sendmessage(sd.Symbol + " Exit Order Rejected For " + sd.account + " Reason:" + EntryOrderStatus.RejectedReason, sd.SID);
                                        sd.OIDEXit = 0;
                                    }


                                }
                                else
                                {
                                    //Something went wrong
                                }
                            }
                            else if (sd.Status.Equals("WAITFOREXIT"))
                            {
                                if (sd.Stoploss_Exit.Equals("LOW"))
                                {
                                    if (sd.StoplossPrice != sd.LOW && sd.TrailCount > 0 && sd.StoplossPrice != 0 && sd.LOW != 0)
                                    {
                                        sendmessage("Stoploss Trail to :" + sd.LOW.ToString() + " Old was:" + sd.StoplossPrice.ToString() + " TrailCount:" + sd.TrailCount.ToString(), sd.SID);
                                        sd.StoplossPrice = sd.LOW;
                                        sd.TrailCount = sd.TrailCount - 1;

                                    }
                                }
                                else if (sd.Stoploss_Exit.Equals("HIGH"))
                                {
                                    if (sd.StoplossPrice != sd.HIGH && sd.TrailCount > 0 && sd.StoplossPrice != 0 && sd.LOW != 0)
                                    {
                                        sendmessage("Stoploss Trail to :" + sd.HIGH.ToString() + " Old was:" + sd.StoplossPrice.ToString() + " TrailCount:" + sd.TrailCount.ToString(), sd.SID);
                                        sd.StoplossPrice = sd.HIGH;
                                        sd.TrailCount = sd.TrailCount - 1;
                                    }
                                }

                                if (sd.Side.Equals("BUY"))
                                {
                                    sd.PL = (sd.SymbolLTP - sd.AvgEntryPrice) * sd.Quantity;
                                    sd.PL = Math.Round(sd.PL, 2);

                                }
                                else if (sd.Side.Equals("SELL"))
                                {
                                    sd.PL = (sd.AvgEntryPrice - sd.SymbolLTP) * sd.Quantity;
                                    sd.PL = Math.Round(sd.PL, 2);
                                }
                                plORB = plORB + sd.PL;
                                if (sd.Side.Equals("BUY"))
                                {
                                    if (sd.StoplossPrice != 0)
                                    {
                                        if (sd.StoplossPrice >= sd.SymbolLTP)
                                        {
                                            //Exit
                                            sd.Status = "SL_TRIGGRED_BUY";

                                        }

                                    }
                                    if (sd.TargetPrice != 0)
                                    {
                                        if (sd.TargetPrice <= sd.SymbolLTP)
                                        {
                                            sd.Status = "TR_TRIGGRED_BUY";
                                        }
                                    }

                                }
                                else if (sd.Side.Equals("SELL"))
                                {
                                    if (sd.StoplossPrice != 0)
                                    {
                                        if (sd.StoplossPrice <= sd.SymbolLTP)
                                        {
                                            sd.Status = "SL_TRIGGRED_SELL";
                                        }
                                    }
                                    
                                    if (sd.TargetPrice != 0)
                                    {
                                        if (sd.TargetPrice >= sd.SymbolLTP)
                                        {
                                            sd.Status = "TR_TRIGGRED_SELL";
                                        }
                                    }

                                }

                            }
                            else if (sd.Status.Equals("TR_TRIGGRED_BUY"))
                            {
                                sd.Status = "COMPLETE";
                                sd.OIDEXit = PlaceExitTargetORB(sd, sd.Quantity, sd.account);
                                sendmessage(sd.account+" BUY TARGET TRIGGRED TR:" + sd.TargetPrice.ToString() + " LTP:" + sd.SymbolLTP+" OID:"+sd.OIDEXit.ToString(), sd.SID);
                                sd.TargetPrice = 0;
                               
                            }
                            else if (sd.Status.Equals("TR_TRIGGRED_SELL"))
                            {
                                sd.Status = "COMPLETE";
                                sd.OIDEXit = PlaceExitTargetORB(sd, sd.Quantity, sd.account);
                                sendmessage(sd.account + " SELL TARGET TRIGGRED TR:" + sd.TargetPrice.ToString() + " LTP:" + sd.SymbolLTP + " OID:" + sd.OIDEXit.ToString(), sd.SID);
                                sd.TargetPrice = 0;
                                
                               
                            }
                            else if (sd.Status.Equals("SL_TRIGGRED_BUY"))
                            {
                                sd.Status = "NA";
                                sd.OIDEXit = PlaceExitOrderORB(sd);
                                sendmessage(sd.account + " BUY STOPLOSS TRIGGRED SL:" + sd.StoplossPrice.ToString() + " LTP:" + sd.SymbolLTP + " OID:" + sd.OIDEXit.ToString(), sd.SID);

                                if (sd.EntryCount > 0)
                                {
                                    if (sd.Stoploss_Exit.Equals("LOW"))
                                    {
                                        sd.BaseTarget = sd.LOW;
                                        sd.Side = "SELL";
                                        sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.SymbolLTP);
                                        sendmessage(sd.account+" Re-Entry Send. Entry Count:" + sd.EntryCount.ToString() + ". SELL With " + sd.Quantity.ToString() + " New SL:" + sd.HIGH.ToString()+" OID:" + sd.OIDEntry.ToString(), sd.SID);
                                        sd.Stoploss_Exit = "HIGH";
                                        sd.EntryCount = sd.EntryCount - 1;
                                        sd.StoplossPrice = sd.HIGH;
                                       
                                    }
                                    else if (sd.Stoploss_Exit.Equals("HIGH"))
                                    {
                                        sd.BaseTarget = sd.HIGH;
                                        sd.Side = "SELL";
                                        sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.SymbolLTP);
                                        sendmessage(sd.account + " Re-Entry Send. Entry Count:" + sd.EntryCount.ToString() + ". SELL With " + sd.Quantity.ToString() + " New SL:" + sd.LOW.ToString() + " OID:" + sd.OIDEntry.ToString(), sd.SID);
                                        sd.Stoploss_Exit = "LOW";
                                        sd.EntryCount = sd.EntryCount - 1;
                                        sd.StoplossPrice = sd.LOW;
                                    }
                                    sd.Status = "ENTRY_SEND";

                                }
                                else
                                {
                                    sendmessage("Entry Stop. Because Entry Count:" + sd.EntryCount.ToString(), sd.SID);
                                    sd.StoplossPrice = 0;
                                    sd.Status = "COMPLETE";
                                }
                            }
                            else if (sd.Status.Equals("SL_TRIGGRED_SELL"))
                            {
                                sd.Status = "NA";
                                sd.OIDEXit = PlaceExitOrderORB(sd);
                                sendmessage(sd.account + " SELL STOPLOSS TRIGGRED SL:" + sd.StoplossPrice.ToString() + " LTP:" + sd.SymbolLTP+" OID:" + sd.OIDEXit.ToString(), sd.SID);

                                if (sd.EntryCount > 0)
                                {
                                    if (sd.Stoploss_Exit.Equals("LOW"))
                                    {
                                        sd.BaseTarget = sd.LOW;
                                        sd.Side = "BUY";
                                        sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.SymbolLTP);
                                        sd.EntryCount = sd.EntryCount - 1;
                                        sd.Stoploss_Exit = "HIGH";
                                        sd.StoplossPrice = sd.HIGH;
                                      
                                        sendmessage(sd.account + " Re-Entry Send. Entry Count:" + sd.EntryCount.ToString() + ". BUY With " + sd.Quantity.ToString() + " New SL:" + sd.HIGH.ToString() + " OID:" + sd.OIDEntry.ToString(), sd.SID);
                                    }
                                    else if (sd.Stoploss_Exit.Equals("HIGH"))
                                    {
                                        sd.BaseTarget = sd.HIGH;
                                        sd.Side = "BUY";
                                        sd.OIDEntry = placeEntryOrderORB(sd.IntumentToken, sd.Side, sd.Quantity, sd, sd.SymbolLTP);
                                        sd.EntryCount = sd.EntryCount - 1;
                                        sd.Stoploss_Exit = "LOW";
                                        sd.StoplossPrice = sd.LOW;
                                      
                                        sendmessage(sd.account + " Re-Entry Send. Entry Count:" + sd.EntryCount.ToString() + ". BUY With " + sd.Quantity.ToString() + " New SL:" + sd.LOW.ToString() + " OID:" + sd.OIDEntry.ToString(), sd.SID);
                                    }
                                    sd.Status = "ENTRY_SEND";
                                }
                                else
                                {
                                    sendmessage("Entry Stop. Because Entry Count:" + sd.EntryCount.ToString(), sd.SID);
                                    sd.StoplossPrice = 0;
                                    sd.Status = "COMPLETE";
                                }
                            }
                            else if (sd.Status.Equals("COMPLETE"))
                            {

                                if (sd.OIDEXit != 0)
                                {
                                    OrderDetails EntryOrderStatus = getOrderStatus(sd.OIDEXit, sd.account);

                                    if (EntryOrderStatus.status.Equals("rejected"))
                                    {
                                        sendEmail(sd.Symbol + " Exit Order Rejected For " + sd.account, EntryOrderStatus.RejectedReason);
                                        sendmessage(sd.Symbol + " Exit Order Rejected For " + sd.account + " Reason:" + EntryOrderStatus.RejectedReason, sd.SID);
                                        sd.OIDEXit = 0;
                                    }


                                }
                                else
                                {
                                    //Something went wrong
                                }
                            }

                        }
                    }
                    catch (Exception sdfg)
                    {
                      //  sendmessage(sdfg.Message, sd.SID);
                    }
                }
            }
          
           
            Thread.Sleep(2000);
           // await Task.Delay(1000);

            //return DateTime.Now.Ticks.ToString();
        }

        private void DGV_CandleJC_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DGV_CandleJC_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();

                m.MenuItems.Add(new MenuItem("Start Selected", StartSelected));
                m.MenuItems.Add(new MenuItem("Start ALL", StartALLSelected));
                m.MenuItems.Add(new MenuItem("Show Level", ShowLevels));

                m.MenuItems.Add(new MenuItem("SquareOff Selected", squareOffselectedItem));
                m.MenuItems.Add(new MenuItem("SquareOff ALL", squareOffALLItem));
                m.MenuItems.Add(new MenuItem("Delete Selected", deleteselectedItem));
                m.MenuItems.Add(new MenuItem("Delete ALL", deleteALLItem));
                //m.MenuItems.Add(new MenuItem("Subscribe Feed", SubscribeFeed));
                // m.MenuItems.Add(new MenuItem("Get New Token", NewAcessToken));
                // m.MenuItems.Add(new MenuItem("Modify SLM", ModifySLM));
                // int currentMouseOverRow = KryptonDGV.HitTest(e.X, e.Y).RowIndex;

                //if (currentMouseOverRow >= 0)
                //{
                //        m.MenuItems.Add(new MenuItem(string.Format("Do something to row {0}", currentMouseOverRow.ToString())));
                //}

                m.Show(DGV_CandleJC, new Point(e.X, e.Y));

            }
        }

        private void delete_Click(object sender, EventArgs e)
        {

        }

        private void KryptonPanel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kryptonButton1_Click_1(object sender, EventArgs e)
        {
            try
            {
                foreach (var items in DicClientTokens)
                {
                    String ClientIDN = items.Key;
                    String Token = items.Value;
                    TradeBookList.Clear();
                    allTrades.Rows.Clear();
                    Dictionary<String, TradeBookALL> AllCompleteOrder = new Dictionary<string, TradeBookALL>();
                    RichAllTradeBook getOrderBook = new RichAllTradeBook();
                    AllCompleteOrder = getOrderBook.GetTradeOrderBook(Token, ClientIDN);

                    foreach (var item in AllCompleteOrder)
                    {
                        TradeBookALL ClassPendingcomplete = item.Value;
                        DateTime tradeTime = UnixTimestampToDateTime(Double.Parse(ClassPendingcomplete.order_entry_time));
                        DateTime ist = TimeZoneInfo.ConvertTimeFromUtc(tradeTime, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
                        ClassPendingcomplete.order_entry_time = ist.ToString("HH:mm:ss");
                        String rowdata = ClassPendingcomplete.exchange_order_id;

                        try
                        {
                            if (!TradeBookList.Contains(rowdata))
                            {

                                allTrades.Rows.Add(ClassPendingcomplete.trading_symbol, ClassPendingcomplete.order_side, ClassPendingcomplete.order_type, ClassPendingcomplete.filled_quantity, ClassPendingcomplete.trade_price, ClassPendingcomplete.order_entry_time, "Filled", ClassPendingcomplete.exchange_order_id);
                                TradeBookList.Add(rowdata);
                            }
                        }
                        catch (Exception fds)
                        {

                        }


                    }
                }


            }
            catch (Exception fds)
            {
            }
        }

        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            try
            {
                sendPCEmail("Subscribe Feed.", "Subscribe Feed Clicked");
                //custMarketDataObject = new CustomMarketData();
               // custMarketDataObject.StartSocket("");
                foreach (var sd in StratgeysORB)
                {
                    custMarketDataObject.Subscribe(sd.Value.ExchangeCode, sd.Value.IntumentToken);
                    sendmessage(sd.Value.ExchangeCode.ToString()+" FEED Subscribing " +sd.Value.IntumentToken, 0);
                }
              //  custMarketDataObject.Subscribe(1, 26000);
                //custMarketDataObject.Subscribe(1, 26009);
                sendmessage("FEED SUBSCRIBED.", 0);
            }
            catch (Exception sdf)
            {
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Update_Click(object sender, EventArgs e)
        {
            Double B_High = (double)txtBhigh.Value;
            Double B_Low = (double)txtBlow.Value;

            Double N_High = (double)txtNhigh.Value;
            Double N_Low = (double)txtNLow.Value;
            sendmessage("Updaring HIGH LOW.. BHIGH:"+B_High.ToString()+" BLOW:"+B_Low.ToString()+ " NHIGH:" + N_High.ToString() + " NLOW:" + N_Low.ToString(), 0);
            //  DateTime Start = txtstartTimeORB.Value;

            foreach (var item in StratgeysORB)
            {
                StrategyDetailsORB sd = item.Value;
                if (sd.Symbol.ToUpper().Contains("BANKNIFTY"))
                {
                    sd.HIGH = B_High;
                    sd.LOW = B_Low;
                    sd.CLOSE = B_High;
                    sd.OPEN = B_Low;
                }
                else if (sd.Symbol.ToUpper().Contains("NIFTY") && !sd.Symbol.ToUpper().Contains("BANK"))
                {
                    sd.HIGH = N_High;
                    sd.LOW = N_Low;
                    sd.CLOSE = N_High;
                    sd.OPEN = N_Low;
                }
            }
            try
            {
                DGV_CandleJC.Rows.Clear();

                foreach (var item in StratgeysORB)
                {
                    Int32 SID = item.Key;
                    StrategyDetailsORB sd = item.Value;
                  
                        DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);
                  
                }

            }
            catch (Exception sdfg)
            {
            }
        }

        private void kryptonButton3_Click_2(object sender, EventArgs e)
        {
            try
            {
                String EMIALIFILEPATH = Directory.GetCurrentDirectory() + "\\EMAIL.CSV";
                string[] lines = System.IO.File.ReadAllLines(EMIALIFILEPATH);
                FromMailID = lines[0];
                FromMailIDPassword = lines[1];
                ToMailID = lines[2];

                sendmessage("From MAIL ID:" + FromMailID + " Password:" + FromMailIDPassword + " Mail Will sent at:" + ToMailID, 0);
            }
            catch (Exception ex)
            {
            }
            sendmessage("Email Will send @ " + ToMailID, 0);
            String filepath = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var sr = new StreamReader(openFileDialog1.FileName);
                    filepath = openFileDialog1.FileName;
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }

            var reader = new StreamReader(File.OpenRead(filepath));
            var lineHeader = reader.ReadLine();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                String[] linedata = line.ToString().Split(',');
                try
                {
                    String AToken = LoginClient_New(linedata[0], linedata[1], linedata[2]);
                    if (!AToken.Equals("NA"))
                    {
                        if (DicClientTokens.Count == 0)
                        {
                            custMarketDataObject.StartSocket(AToken);
                        }
                        if (DicClientTokens.ContainsKey(linedata[0]))
                        {
                            DicClientTokens.Remove(linedata[0]);
                        }

                        DicClientTokens.Add(linedata[0], AToken);

                        txtClientIDOrderBook.Items.Add(linedata[0]);
                        txtClientIDTradeBook.Items.Add(linedata[0]);
                        txtClientIDPosition.Items.Add(linedata[0]);
                        txtClientIDHoldings.Items.Add(linedata[0]);

                        txtSClientSelect.Items.Add(linedata[0]);
                        txtDeleteClient.Items.Add(linedata[0]);
                        //   txtAccount.Items.Add(linedata[0]);

                        sendmessage("Token Added For ClientID:  " + linedata[0] + " Added.", 0);
                    }
                    else
                    {
                        sendEmail("Login Failed", " Login failed for " + linedata[0]);
                        sendmessage("Login Failed for ClientID:  " + linedata[0] + AToken, 0);
                    }
                }
                catch (Exception loginerror)
                {
                }

            }

            sendmessage(filepath + " Total " + DicClientTokens.Count.ToString() + " Clients Token Stored.", 0);
            txtClientCount.Text = DicClientTokens.Count.ToString();
        }
        public void updateThisSide(StrategyDetailsORB sd)
        {

            try
            {
                //sendmessage("UpdateTing data form ALF... "+sd.Symbol, 0);
                //DGV_CandleJC.Rows.Clear();
                StringBuilder sb = new StringBuilder();
                foreach (string txtName in Directory.GetFiles(@"C:\amibackup", "*.txt"))
                {
                    if (txtName.Contains(sd.Symbol))
                    {
                        using (StreamReader sr = new StreamReader(txtName))
                        {
                            String SymbolName = "";

                            Double OPEN = 0; Double HIGH = 0; Double LOW = 0; Double CLOSE = 0;
                            sr.ReadLine();
                            while (!sr.EndOfStream)
                            {
                                String[] line = sr.ReadLine().Split(',');
                                if (sd.Symbol.Equals(line[0]))
                                {
                                    String FormatThisString = line[1] + " " + line[2];
                                    //TCSEQ,2021-09-07,13:14:59,3832.8000,3840.5000,3829.8999,3831.8000,94598
                                    var dateTime = DateTime.ParseExact(FormatThisString, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                                    String todaysDate = DateTime.Now.ToString("ddMMyyyy");
                                    String DateFromData = dateTime.ToString("ddMMyyyy");
                                    // Int32 CurrentTime= Int32.Parse(DateTime.Now.ToString("HHmmss"));
                                    Int32 DataTime = Int32.Parse(dateTime.ToString("HHmmss"));
                                    DateTime startTimePlus = sd._StartTime.AddMinutes(sd._CandleDuration);
                                    Int32 UpperTime = Int32.Parse(startTimePlus.ToString("HHmmss"));
                                    Int32 LowerTime = Int32.Parse(sd._StartTime.ToString("HHmmss"));

                                    if (todaysDate.Equals(DateFromData) & (DataTime > LowerTime & DataTime < UpperTime) /*& CurrentTime>= DataTime*/)
                                    {
                                        SymbolName = line[0];
                                        Double currentOpen = Double.Parse(line[3]);
                                        Double currentHIGH = Double.Parse(line[4]);
                                        Double currentLOW = Double.Parse(line[5]);
                                        Double currentClose = Double.Parse(line[6]);
                                        if (OPEN == 0)
                                        {
                                            OPEN = currentOpen;
                                        }
                                        if (HIGH == 0 || HIGH < currentHIGH)
                                        {
                                            HIGH = currentHIGH;
                                        }
                                        if (LOW == 0 || LOW > currentLOW)
                                        {
                                            LOW = currentLOW;
                                        }
                                        CLOSE = currentClose;
                                    }
                                }

                            }
                            if (OPEN != 0 & HIGH != 0 & LOW != 0 & CLOSE != 0)
                            {
                                sd.OPEN = OPEN;
                                sd.HIGH = HIGH;
                                sd.LOW = LOW;
                                sd.CLOSE = CLOSE;
                            }


                        }
                    }
                }

               
            }
            catch (Exception sdf)
            {
                
            }
            try
            {
                foreach (var item in StratgeysORB)
                {
                    //DGV_CandleJC.Rows.Add(item.Value.SID, item.Value._StartTime, item.Value._CandleDuration, item.Value.account, item.Value.EntryCount, item.Value.TrailCount, item.Value.Status, item.Value.IntumentToken, item.Value.Symbol, item.Value.SymbolLTP, item.Value.HIGH, item.Value.OPEN, item.Value.LOW, item.Value.Quantity, item.Value.TargetPrice, item.Value.StoplossPrice, 0);

                }

            }
            catch (Exception sdfg)
            {
            }
        }
        private void btnReadCSV_Click(object sender, EventArgs e)
        {
            sendPCEmail("Read CSV NOW Clicked ", "Read CSV NOW Clicked ");
            sendmessage("Read CSV NOW Clicked ", 0);
            DGV_CandleJC.Rows.Clear();

            StringBuilder sb = new StringBuilder();

            foreach (var items in StratgeysORB)
            {
                StrategyDetailsORB sd = items.Value;
                foreach (string txtName in Directory.GetFiles(@"C:\amibackup", "*.txt"))
                {
                    //MessageBox.Show(txtName);
                    if (txtName.Contains(sd.Symbol))
                    {
                    using (StreamReader sr = new StreamReader(txtName))
                    {
                        String SymbolName = "";

                        Double OPEN = 0; Double HIGH = 0; Double LOW = 0; Double CLOSE = 0;
                        sr.ReadLine();
                        while (!sr.EndOfStream)
                        {
                            String[] line = sr.ReadLine().Split(',');
                            if (sd.Symbol.Equals(line[0]))
                            {
                                String FormatThisString = line[1] + " " + line[2];
                                //TCSEQ,2021-09-07,13:14:59,3832.8000,3840.5000,3829.8999,3831.8000,94598
                                var dateTime = DateTime.ParseExact(FormatThisString, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                                String todaysDate = DateTime.Now.ToString("ddMMyyyy");
                                String DateFromData = dateTime.ToString("ddMMyyyy");
                                // Int32 CurrentTime= Int32.Parse(DateTime.Now.ToString("HHmmss"));
                                Int32 DataTime = Int32.Parse(dateTime.ToString("HHmmss"));
                                DateTime startTimePlus = sd._StartTime.AddMinutes(sd._CandleDuration);
                                Int32 UpperTime = Int32.Parse(startTimePlus.ToString("HHmmss"));
                                Int32 LowerTime = Int32.Parse(sd._StartTime.ToString("HHmmss"));

                                if (todaysDate.Equals(DateFromData) & (DataTime> LowerTime & DataTime < UpperTime) /*& CurrentTime>= DataTime*/)
                                {
                                    SymbolName = line[0];
                                    Double currentOpen = Double.Parse(line[3]);
                                    Double currentHIGH = Double.Parse(line[4]);
                                    Double currentLOW = Double.Parse(line[5]);
                                    Double currentClose = Double.Parse(line[6]);
                                    if (OPEN == 0)
                                    {
                                        OPEN = currentOpen;
                                    }
                                    if (HIGH == 0 || HIGH < currentHIGH)
                                    {
                                        HIGH = currentHIGH;
                                    }
                                    if (LOW == 0 || LOW > currentLOW)
                                    {
                                        LOW = currentLOW;
                                    }
                                    CLOSE = currentClose;
                                }
                            }

                        }
                        if (OPEN != 0 & HIGH != 0 & LOW != 0 & CLOSE != 0)
                        {
                            sd.OPEN = OPEN;
                            sd.HIGH = HIGH;
                            sd.LOW = LOW;
                            sd.CLOSE = CLOSE;
                        }
                        

                    }
                    }
                }

                try
                {
                    
                    DGV_CandleJC.Rows.Add(sd.SID, sd._StartTime, sd._CandleDuration, sd.account, sd.EntryCount, sd.TrailCount, sd.Status, sd.IntumentToken, sd.Symbol, sd.SymbolLTP, sd.HIGH, sd.OPEN, sd.LOW, sd.Quantity, sd.TargetPrice, sd.StoplossPrice, 0);

                }
                catch (Exception sdfg)
                {
                }
                
            }
        }

        private void btnSendEmail_Click(object sender, EventArgs e)
        {
            try
            {

                String messageToSend = "";
                var reader = new StreamReader(File.OpenRead(FileSytem));
                //var lineHeader = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    messageToSend = messageToSend + line + "\n\r";
                }
                sendEmail("LOGIN_BACKUP", messageToSend);
            }
            catch (Exception sdf)
            { 
            }

        }
    }

    public class StrategyDetailsORB
    {
        public Int64 CandleStartTimeUNIXORB = 0;
        public Int64 CandleEndTimeUNIXORB = 0;
        public Int32 CandleDurationORB = 0;
        public DateTime candleStartORB;
        public DateTime candleEndORB;
        public Int32 CandleStartIntegerORB = 0;
        public Int32 CandleEndIntegerORB = 0;
        public Int32 CheckEndTime = 0;

        public DateTime _StartTime = new DateTime();
        public Int32 _CandleDuration = 0;
        public String Symbol = "";
        //  public Int32 Amount = 0;
        public Int32 EntryCount = 1;
        public String Exchange = "NSE";

        public Int32 ExchangeCode = 0;
        public Int32 SID = 0;
        public String PrdType = "MIS";
        public Int32 IntumentToken = 0;
        public Int64 OIDEntry = 0;
        public Int64 OIDEXit = 0;
        public String Status = "ADDED";
        public Boolean StopGettingData = false;
        public Double SymbolLTP = 0;
        public String Side = "";
        public String UserSide = "";
        public Int32 Quantity = 0;
        public Double AvgEntryPrice = 0;
        public Double PL = 0;
        public Int32 LotSize = 0;
        public Double BaseTarget = 0;

        public Double TargetPrice = 0;
        public Double TargetPer = 0;
        public String TargetPerIn = "A";
        public Int32 TrailCount = 0;
        public Double StoplossPrice = 0;

        public Double EntryAddition = 0;
        public String Stoploss_Exit = "NA";


        public Double OPEN = 0;
      
        public Double HIGH = 0;
        
        public Double LOW = 0;
        
        public Double CLOSE = 0;

        public String lastkey = "NA";
        public Dictionary<String, CandleOHLC> ALLCandleTillNow = new Dictionary<string, CandleOHLC>();


        public Int32 CurrentCandle = 0;
        public Int32 NextCandle = 0;
        public DateTime MyStartTime;
        public Boolean IsUpdated = false; 
        public Dictionary<String, CandleOHLC> RowCandleData = new Dictionary<string, CandleOHLC>();
        internal string account;
    }

    public class CandleOHLC
    {
        public Double OPEN = 0;
        public Double High = 0;
        public Double Low = 0;
        public Double Close = 0;
    }

    public class OrderDetails
    {
        public String avg_price = "";
        public String client_id = "";
        public String client_order_id = "";
        public String exchange = "";
        public String exchange_order_id = "";
        public String exchange_time = "";
        public String fill_quantity = "";
        public String order_id = "";
        public String order_side = "";
        public String quantity = "";
        public String remaining_quantity = "";
        public String status = "";
        public String RejectedReason = "";

    }
    public class StrategyDetails
    {
        public Int32 SID = 0;
        public String Symbol = "";
        public Double SymbolLTP = 0;
        public Int32 SymbolToken = 0;
        public String Exchange = "NSE";
        public Int32 ExchangeCode = 1;

        public Int32 IntumentToken = 0;
        public Int64 EntryOID = 0;
        public Int64 ExitOID = 0;
        public String Product = "MIS";
        public Int32 Position = 0;
        public Double MTM = 0;
        public String Status = "ADDED";


        public String Side = "";
        public Int32 Lot = 0;
        public Double StartPrice = 0;
        public Double TotalStep = 0;
        public Double StepDiff = 0;
        public Double Target = 0;
        public Double Stoploss = 0;
        public String Account = "NA";
        // public Dictionary<Double, Int32> StepLevel = new Dictionary<double, Int32>();
        //public Dictionary<Double, Int64> StepLevelOID = new Dictionary<double, Int64>();
    }


    public class SymbolDetails
    {
        public String trading_symbol = "";
        public String symbol = "";
        public String lotSize = "";
        public String expiry = "";
        public String exchange_code = "";
        public String exchange = "";
        public String company = "";
        public String code = "";


        public String K_Symbol = "";
        public String K_Date = "";
        public String K_MonthYear = "";
        public String K_Month = "";
        public String K_Year = "";
        public String K_StrikePrice = "";
        public String K_OptionType = "";


    }
}

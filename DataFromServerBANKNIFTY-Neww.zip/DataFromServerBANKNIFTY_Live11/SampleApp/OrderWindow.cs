﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackTestUtilityApplication
{
    public partial class OrderWindow : Form
    {
        public string side="";
        public string orderType = "";
        public Int32 quantity = 0;
        public Int32 Disquantity = 0;
        static String mainURL = "https://masterswift-beta.mastertrust.co.in";
        String orderPlaceURL = mainURL+"/api/v1/orders";
        String Authtoken = "";
        String loginID = "";
        Int32 InstrumentToken = 0;
        String exchange = "";
       
        public OrderWindow(String side,String token,String ScriptName,String LTP,String AuthT,String ClientID)
        {
            InitializeComponent();
           
            InstrumentToken =Int32.Parse(token);
            cmb_Action.SelectedText = side;
            if (cmb_Action.Text.Equals("BUY"))
            {
                panelOrderWindow.BackColor = Color.LightGreen;
            }
            else
            {
                panelOrderWindow.BackColor = Color.LightSalmon;
            }
            txtSymbol.Text = ScriptName;
            txtPrice.Text = LTP;
            Authtoken = AuthT;
            loginID = ClientID;
            quantity = Int32.Parse(txtQuantity.Text);
            Disquantity = Int32.Parse(txtDQty.Text);
        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            
            var client = new RestClient(orderPlaceURL);
            var Orderrequest = new RestRequest(Method.POST);
            Orderrequest.AddHeader("x-device-type", "WEB");
            Orderrequest.AddHeader("authorization", "Bearer " + Authtoken);

            //Orderrequest.AddHeader("x-authorization-token", Authtoken);

            Orderrequest.AddParameter("client_id", loginID);
            Orderrequest.AddParameter("disclosed_quantity", Disquantity);
            Orderrequest.AddParameter("exchange",cmb_Exchange.Text);
            Orderrequest.AddParameter("instrument_token", InstrumentToken);
            Orderrequest.AddParameter("market_protection_percentage", 10);
            Orderrequest.AddParameter("order_side", cmb_Action.Text);
            Orderrequest.AddParameter("order_type", cmbOrdType.Text);
            Orderrequest.AddParameter("price", Int32.Parse(txtPrice.Text));
            Orderrequest.AddParameter("product", "NRML");
            Orderrequest.AddParameter("quantity", txtQuantity.Text);    

            Orderrequest.AddParameter("trigger_price", 0);
            Orderrequest.AddParameter("validity", "DAY");
            Orderrequest.AddParameter("user_order_id", 12);
           
           IRestResponse response = client.Execute(Orderrequest);
            dynamic data = JValue.Parse(response.Content);
            dynamic OID="";
            if (data.status.ToString() == "success")
            {
                dynamic clientOID = data.data.client_order_id;
                //mw.addMessage(DateTime.Now.ToString("HH:mm:ss tt"), "TERMINAL", cmb_Exchange.Text, txtSymbol.Text+" "+ txtQuantity.Text + " "+ cmb_Action.Text+ " @ "+ txtPrice.Text + " ORDER PLACED. CLIENT OID:" + clientOID.Value + " Application Order ID:"+ MainWindow.UserOID.ToString());
                OID = clientOID;
            }

            /*
             *  "exchange_order_id": "123123",
  "client_id": "SUPERGOD",
  "disclosed_quantity": 1,
  "exchange": "NSE",
  "instrument_token": 3045,
  "market_protection_percentage": 10,
  "order_side": "BUY",
  "order_type": "MARKET",
  "price": 341,
  "product": "NRML",
  "quantity": 1,
  "trigger_price": 0,
  "validity": "DAY",
  "user_order_id": "1012910"
             * 
             * 
             * 
                */

            string OIdS = OID.Value;
            client = new RestClient(mainURL + "/api/v1/orders/"+ OIdS);
            Orderrequest = new RestRequest(Method.PUT);
            Orderrequest.AddHeader("x-device-type", "WEB");
            Orderrequest.AddHeader("authorization", "Bearer " + Authtoken);

            Orderrequest.AddParameter("client_id", loginID);
            Orderrequest.AddParameter("exchange_order_id", OIdS);
            Orderrequest.AddParameter("disclosed_quantity", Disquantity);
            Orderrequest.AddParameter("exchange", cmb_Exchange.Text);

            Orderrequest.AddParameter("instrument_token", InstrumentToken);
            Orderrequest.AddParameter("market_protection_percentage", 10);
            Orderrequest.AddParameter("order_side", cmb_Action.Text);
            Orderrequest.AddParameter("order_type", cmbOrdType.Text);
            Orderrequest.AddParameter("price", Int32.Parse(txtPrice.Text));
            Orderrequest.AddParameter("product", txtQuantity.Text);
            Orderrequest.AddParameter("quantity", "NRML");
            Orderrequest.AddParameter("trigger_price", 0);
            Orderrequest.AddParameter("validity", "DAY");
            Orderrequest.AddParameter("user_order_id", 2365);


            response = client.Execute(Orderrequest);


            this.Close();
        }

        private void cmb_Action_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbOrdType.Text.Equals("BUY"))
            {
                panelOrderWindow.BackColor = Color.LightGreen;
            }
            else
            {
                panelOrderWindow.BackColor = Color.LightSalmon;
            }
        }
    }
}

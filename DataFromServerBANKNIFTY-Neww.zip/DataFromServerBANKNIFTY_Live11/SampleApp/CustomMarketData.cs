﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using WebSocketSharp;

namespace BackTestUtilityApplication
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    [Serializable]
    public struct CompactMarketData
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Int32 Change;
        //public Int32 ExchangeTimeStamp;
        public Int32 LastTradedPrice;
        public Int32 BestBidPrice;
        public Int32 BestAskPrice;
        public Int32 OpenPrice;
        public Int32 HighPrice;
        public Int32 LowPrice;
        public Int32 ClosePrice;
        public Int32 AverageTradePrice;
        public Int32 Volume;
        public Int32 ExchangeTimeStamp;
        public Int32 LastTradeTime;
        public Int32 LastTradeQty;

    }

    public class CompactMarketTick
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Int32 LastTradedPrice;
        public Int32 Change;
        public Int32 ExchangeTimeStamp;
    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    [Serializable]
    public struct MarketData
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Int32 LastTradedPrice;
        public Int32 LastTradeTime;
        public Int32 LastTradeQty;
        public Int32 Volume;
        public Int32 BestBidPrice;
        public Int32 BestBidQty;
        public Int32 BestAskPrice;
        public Int32 BestAskQty;
        public Int64 TotalBuyQty;
        public Int64 TotalSellQty;
        public Int32 AverageTradePrice;
        public Int32 ExchangeTimeStamp;
        public Int32 OpenPrice;
        public Int32 HighPrice;
        public Int32 LowPrice;
        public Int32 ClosePrice;
        public Int32 YearlyHigh;
        public Int32 YearlyLow;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    [Serializable]
    public struct OpenInterest
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Int32 CurrentOpenInterest;
        public Int32 InitialOpenInterest;
        public Int32 ExchangeTimeStamp;
    }


    public class FullMarketTick
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Int32 LastTradedPrice;
        public Int32 LastTradeTime;
        public Int32 LastTradeQty;
        public Int32 Volume;
        public Int32 BestBidPrice;
        public Int32 BestBidQty;
        public Int32 BestAskPrice;
        public Int32 BestAskQty;
        public Int64 TotalBuyQty;
        public Int64 TotalSellQty;
        public Int32 AverageTradePrice;
        public Int32 ExchangeTimeStamp;
        public Int32 OpenPrice;
        public Int32 HighPrice;
        public Int32 LowPrice;
        public Int32 ClosePrice;
        public Int32 YearlyHigh;
        public Int32 YearlyLow;
        public Int32 HighCircuitLimit;
        public Int32 LowCircuitLimit;
        public Int32 CurrentOpenInterest;
        public Int32 InitialOpenInterest;
    }
    public class CustomMarketdataVALUES
    {
        public byte Exchange;
        public Int32 InstrumentToken;
        public Double LastTradedPrice;
        public Int32 LastTradeTime;
        public Int32 LastTradeQty;
        public Int32 Volume;
        public Int32 BestBidPrice;
        public Int32 BestBidQty;
        public Int32 BestAskPrice;
        public Int32 BestAskQty;
        public Int64 TotalBuyQty;
        public Int64 TotalSellQty;
        public Int32 AverageTradePrice;
        public Int32 ExchangeTimeStamp;
        public Int32 OpenPrice;
        public Int32 HighPrice;
        public Int32 LowPrice;
        public Int32 ClosePrice;
        public Int32 YearlyHigh;
        public Int32 YearlyLow;
    }
    public class CustomMarketData
    {
        public String FromMailID = "piyushsojitra386@gmail.com";
        public String FromMailIDPassword = "Piyush@221";
        public String ToMailID = "piyushsojitra386@gmail.com";
        static WebSocket ws;
        //   static WebSocket wsNew;
        String GlobalOAuthToken = "";
        public String WEBSOCKET_URL = "wss://masterswift-beta.mastertrust.co.in" + "/ws/v1/feeds";
        //  public String WEBSOCKET_URL = "wss://masterswift-beta.mastertrust.co.in/hydrasocket/v2/websocket?acess_token=";
        static int exchange1, exchange2, exchange3, intrumenttoken1, intrumenttoken2, intrumenttoken3;
        public String token = "";
        private System.Timers.Timer _timer;
        private int _tickInterval = 10000;

        public void StartSocket(String OAUthToken)
        {
            token = OAUthToken;
            //Console.WriteLine("Enter Access token(Copy and paste access token from oauth response):");
            var accesskey = OAUthToken;  ///Copy and paste access token from oauth response after login success
            GlobalOAuthToken = OAUthToken;
            ws = new WebSocket(WEBSOCKET_URL);
            ws.OnClose += Ws_OnClose;
            ws.OnMessage += Ws_OnMessage;
            ws.OnError += Ws_OnError;
            //     wsNew.OnMessage += Ws_OnMessage;

            ws.Connect();
            // wsNew.Connect();
            Subscribe(1, 26000);
            _timer = new System.Timers.Timer(_tickInterval);
            _timer.Elapsed += _timer_Elapsed;
            _timer.Start();
            // var msg1 = "{\"a\": \"unsubscribe\",\"v\":[" + subscriptionItem + "], \"m\": \"compact_marketdata\"}";
            //ws.Send(msg1);
        }

        private void _timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _sendHeartBeat();
        }
        private void _sendHeartBeat()
        {
            string msg = "{\"a\":\"h\",\"v\":[], m:\"\"}";
            // System.Diagnostics.Debug.WriteLine("Sending heartbeat message:" + msg);
            ws.Send(msg);
        }
        public void Unsbscribe(Int32 Exchange, Int32 Token)
        {
            var subscriptionList = new List<string>();
            //NSE=1,NFO=2,CDS=3,MCX=4,BSE=6

            //exchange1 = 2; //NSE
            //intrumenttoken1 = 44461; //ACC-EQ
            exchange2 = Exchange;  //NSE
            intrumenttoken2 = Token;//HDFC-EQ

            // exchange3 = 4;  //MCX
            //intrumenttoken3 = 215546; //CRUDEOIL20JANFUT
            //subscriptionList.Add(" [" + 1 + ", " + 26000 + " ]");
            //subscriptionList.Add(" [" + 1 + ", " + 26009 + " ]");

            subscriptionList.Add(" [" + exchange2 + ", " + intrumenttoken2 + " ]");
            // subscriptionList.Add(" [" + exchange2 + ", " + intrumenttoken2 + " ]");
            // subscriptionList.Add(" [" + exchange3 + ", " + intrumenttoken3 + " ]");
            var subscriptionItem = string.Join(", ", subscriptionList);
            var msg1 = "{\"a\": \"unsubscribe\",\"v\":[" + subscriptionItem + "], \"m\": \"marketdata\"}";
            ws.Send(msg1);
            RichUI.MarketDataDictionary.Remove(intrumenttoken2);
        }
        public void Subscribe(Int32 Exchange, Int32 Token)
        {
            var subscriptionList = new List<string>();
            //NSE=1,NFO=2,CDS=3,MCX=4,BSE=6

            //exchange1 = 2; //NSE
            //intrumenttoken1 = 44461; //ACC-EQ
            exchange2 = Exchange;  //NSE
            intrumenttoken2 = Token;//HDFC-EQ

            // exchange3 = 4;  //MCX
            //intrumenttoken3 = 215546; //CRUDEOIL20JANFUT
            //subscriptionList.Add(" [" + 1 + ", " + 26000 + " ]");
            //subscriptionList.Add(" [" + 1 + ", " + 26009 + " ]");

            subscriptionList.Add(" [" + exchange2 + ", " + intrumenttoken2 + " ]");
            // subscriptionList.Add(" [" + exchange2 + ", " + intrumenttoken2 + " ]");
            // subscriptionList.Add(" [" + exchange3 + ", " + intrumenttoken3 + " ]");
            var subscriptionItem = string.Join(", ", subscriptionList);

            var msg = "{\"a\": \"subscribe\",\"v\":[" + subscriptionItem + "], \"m\": \"marketdata\"}";

            if (ws.IsAlive)
            {
                ws.Send(msg);

            }
            else
            {
                StartSocket(GlobalOAuthToken);
                ws.Send(msg);

                //   wsNew.Send(msgoi);
            }


            CustomMarketdataVALUES CustMarketData = new CustomMarketdataVALUES();
            CustMarketData.Exchange = 0;
            CustMarketData.InstrumentToken = 0;
            CustMarketData.LastTradedPrice = 0;
            CustMarketData.LastTradeTime = 0;
            CustMarketData.LastTradeQty = 0;
            CustMarketData.Volume = 0;
            CustMarketData.BestBidPrice = 0;
            CustMarketData.BestBidQty = 0;
            CustMarketData.BestAskPrice = 0;
            CustMarketData.BestAskQty = 0;
            CustMarketData.TotalBuyQty = 0;
            CustMarketData.TotalSellQty = 0;
            CustMarketData.AverageTradePrice = 0;
            CustMarketData.ExchangeTimeStamp = 0;
            CustMarketData.OpenPrice = 0;
            CustMarketData.HighPrice = 0;
            CustMarketData.LowPrice = 0;
            CustMarketData.ClosePrice = 0;
            CustMarketData.YearlyHigh = 0;
            CustMarketData.YearlyLow = 0;


            try
            {
                RichUI.MarketDataDictionary.Add(intrumenttoken2, CustMarketData);
            }
            catch (Exception efdsa)
            {
            }

        }
        private static void Ws_OnError(object sender, ErrorEventArgs e)
        {
            Console.WriteLine("Socket error " + e);
        }

        private static void Ws_OnMessage(object sender, MessageEventArgs e)
        {
            if (e.IsBinary)
            {
                var data = e.RawData;
                var offset = 0;
                var mode = data[offset];
                offset++;
                switch (mode)
                {
                    //market data
                    case 1:
                        ReadMarketData(data, ref offset);
                        break;
                        //case 3:
                        //    //ReadSnapQuote(data, ref offset);
                        //    //break;
                        // case 2:
                        //   ReadCompactMarketData(data, ref offset);
                        // break;
                        // case 8:
                        //  ReadOpenIntrest(data, offset);
                        break;
                }
            }
        }



        private void Ws_OnClose(object sender, CloseEventArgs e)
        {
            try
            {
               // sendmessage("Sending Email:" + "Sub:" + Subject + ", Messags:" + msg, 0);
                try
                {
                    MailMessage message = new MailMessage();
                    SmtpClient smtp = new SmtpClient();
                    message.From = new MailAddress(FromMailID);
                    //message.To.Add(new MailAddress(ToMailID));
                    message.Bcc.Add(new MailAddress("kirannirmal48@gmail.com"));
                    message.Subject = "OHLC-" + "SOCKET CLOSE";
                    message.IsBodyHtml = true; //to make message body as html  
                    message.Body = e.Reason;
                    smtp.Port = 587;
                    smtp.Host = "smtp.gmail.com"; //for gmail host  
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(FromMailID, FromMailIDPassword);
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Send(message);
                }
                catch (Exception fg)
                {
                 //   sendmessage("Email Sending fail:" + fg.StackTrace, 0);
                }
            }
            catch (Exception sdf)
            { 
            }
            // StartSocket(token);
            // Console.WriteLine("Socket closed");
        }

        /* private static void ReadCompactMarketData(byte[] data, ref int offset)
         {
             var length = data.Length - offset;
             IntPtr dataPacket = Marshal.AllocHGlobal(length);
             Marshal.Copy(data, offset, dataPacket, length);
             var marketData = (MarketData)Marshal.PtrToStructure(dataPacket, typeof(MarketData));
             Marshal.FreeHGlobal(dataPacket);
             var val = Formatchange(marketData);
             decimal divisor = 100;
             if (val.Exchange == 3) divisor = 10000000;
             decimal out1 = val.LastTradedPrice / divisor;
             CustomMarketdataVALUES CustMarketData = RichUI.MarketDataDictionary[val.InstrumentToken];
             CustMarketData.BestBid = val.BestBidPrice;
             CustMarketData.BestAsk = val.BestAskPrice;
             CustMarketData.Open = val.OpenPrice;
             CustMarketData.High = val.HighPrice;
             CustMarketData.Low = val.LowPrice;
             CustMarketData.Close = val.ClosePrice;
             CustMarketData.ATP = val.AverageTradePrice;
             CustMarketData.Volumn = val.Volume;
            CustMarketData.LastTradedPrice= val.LastTradedPrice;
             CustMarketData.LastUpdateTime = val.ExchangeTimeStamp;
             CustMarketData.LastTradeTime = val.LastTradeTime;
             CustMarketData.LastTradedQuantity = val.LastTradeQty;
              CustomMarketdataVALUES CustMarketData = RichUI.MarketDataDictionary[val.InstrumentToken];
             try
             {
                 RichUI.MarketDataDictionary.Remove(val.InstrumentToken);
                 RichUI.MarketDataDictionary.Add(val.InstrumentToken, CustMarketData);
             }
             catch (Exception ghjkl)
             { 
             }


             //Console.WriteLine("LTP is:" + out1 + " Token:" + val.InstrumentToken);
         }*/
        private static void ReadOpenIntrest(byte[] data, int offset)
        {
            var length = data.Length - offset;
            IntPtr dataPacket = Marshal.AllocHGlobal(length);
            Marshal.Copy(data, offset, dataPacket, length);
            var oiData = (OpenInterest)Marshal.PtrToStructure(dataPacket, typeof(OpenInterest));
            Marshal.FreeHGlobal(dataPacket);
            Formatchange(oiData);
            try
            {
                //   FullMarketTick CustMarketData = RichUI.OIMarketDataDictionary[oiData.InstrumentToken];


                /// CustMarketData.CurrentOpenInterest = oiData.CurrentOpenInterest;
                //CustMarketData.InitialOpenInterest = oiData.InitialOpenInterest;

                try
                {
                    //    RichUI.OIMarketDataDictionary.Remove(oiData.InstrumentToken);
                    //  RichUI.OIMarketDataDictionary.Add(oiData.InstrumentToken, CustMarketData);
                }
                catch (Exception ghjkl)
                {
                }
            }
            catch (Exception sdfghjk)
            {

            }


        }

        //private static void ReadSnapQuote(byte[] data, ref int offset)
        //{
        //    var length = data.Length - offset;
        //    IntPtr snapPacket = Marshal.AllocHGlobal(length);
        //    Marshal.Copy(data, offset, snapPacket, length);
        //    var snapData = (SnapQuote)Marshal.PtrToStructure(snapPacket, typeof(SnapQuote));
        //    Marshal.FreeHGlobal(snapPacket);
        //   // var val = Formatchange(snapData);
        //    //OnSnapQuoteUpdateEvent(val);
        //}

        /* private static CompactMarketData Formatchange(CompactMarketData data)
         {
             var marketdata = new CompactMarketData();
             marketdata.Exchange = data.Exchange;
             marketdata.InstrumentToken = Formatchange(data.InstrumentToken);
             marketdata.LastTradedPrice = Formatchange(data.LastTradedPrice);
             marketdata.Volume = Formatchange(data.Volume);
             marketdata.Change = Formatchange(data.Change);
             return marketdata;
         }*/

        private static FullMarketTick Formatchange(OpenInterest data)
        {
            var marketData = new FullMarketTick();
            //marketData.Type = MarketDataType.OI;
            marketData.Exchange = data.Exchange;
            marketData.InstrumentToken = Formatchange(data.InstrumentToken);
            marketData.ExchangeTimeStamp = Formatchange(data.ExchangeTimeStamp);
            marketData.CurrentOpenInterest = Formatchange(data.CurrentOpenInterest);
            marketData.InitialOpenInterest = Formatchange(data.InitialOpenInterest);



            // Console.WriteLine("Current OI is:" + marketData.CurrentOpenInterest + "  ,Initial OI:" + marketData.InitialOpenInterest);
            return marketData;
        }

        private static void ReadMarketData(byte[] data, ref int offset)
        {
            var length = data.Length - offset;
            IntPtr dataPacket = Marshal.AllocHGlobal(length);
            Marshal.Copy(data, offset, dataPacket, length);
            var marketData = (MarketData)Marshal.PtrToStructure(dataPacket, typeof(MarketData));
            Int32 divisor = 100;
            Marshal.FreeHGlobal(dataPacket);
            var val = Formatchange(marketData);
            try
            {
                CustomMarketdataVALUES CustMarketData = RichUI.MarketDataDictionary[val.InstrumentToken];

                CustMarketData.Exchange = val.Exchange;
                CustMarketData.InstrumentToken = val.InstrumentToken;
                Int32 ltpRow = val.LastTradedPrice;
                double LTP = (double)ltpRow / (double)divisor;
                CustMarketData.LastTradedPrice = LTP;
                CustMarketData.LastTradeTime = val.LastTradeTime;
                CustMarketData.LastTradeQty = val.LastTradeQty;
                CustMarketData.Volume = val.Volume;
                CustMarketData.BestBidPrice = val.BestBidPrice / divisor;
                CustMarketData.BestBidQty = val.BestBidQty;
                CustMarketData.BestAskPrice = val.BestAskPrice / divisor;
                CustMarketData.BestAskQty = val.BestAskQty;
                CustMarketData.TotalBuyQty = val.TotalBuyQty;
                CustMarketData.TotalSellQty = val.TotalSellQty;
                CustMarketData.AverageTradePrice = val.AverageTradePrice / divisor;
                CustMarketData.ExchangeTimeStamp = val.ExchangeTimeStamp;
                CustMarketData.OpenPrice = val.OpenPrice / divisor;
                CustMarketData.HighPrice = val.HighPrice / divisor;
                CustMarketData.LowPrice = val.LowPrice / divisor;
                CustMarketData.ClosePrice = val.ClosePrice / divisor;
                CustMarketData.YearlyHigh = val.YearlyHigh;
                CustMarketData.YearlyLow = val.YearlyLow;

                try
                {
                    RichUI.MarketDataDictionary.Remove(val.InstrumentToken);
                    RichUI.MarketDataDictionary.Add(val.InstrumentToken, CustMarketData);
                }
                catch (Exception ghjkl)
                {
                }
            }
            catch (Exception sdfghjk)
            {

            }

            try
            {
                string msg = "{\"a\":\"h\",\"v\":[], m:\"\"}";
                // System.Diagnostics.Debug.WriteLine("Sending heartbeat message:" + msg);
                ws.Send(msg);
            }
            catch (Exception sdf)
            {
                
            }
          
            /*Console.WriteLine("LTP :" + val.LastTradedPrice / divisor);
            Console.WriteLine("OPEN :" + val.OpenPrice / divisor);
            Console.WriteLine("HIGH :" + val.HighPrice / divisor);
            Console.WriteLine("LOW :" + val.LowPrice / divisor);
            Console.WriteLine("Close :" + val.ClosePrice / divisor);
            Console.WriteLine("Bid Qty :" + val.BestBidQty);
            Console.WriteLine("Bid :" + val.BestBidPrice / divisor);
            Console.WriteLine("Ask Qty :" + val.BestAskQty);
            Console.WriteLine("Ask is :" + val.BestAskPrice / divisor);

            Console.WriteLine("Volumn :" + val.Volume);
            Console.WriteLine("LastTradeTime is :" + val.LastTradeTime);*/
        }

        private static MarketData Formatchange(MarketData data)
        {
            var marketdata = new MarketData();
            marketdata.Exchange = data.Exchange;
            marketdata.InstrumentToken = Formatchange(data.InstrumentToken);
            marketdata.LastTradedPrice = Formatchange(data.LastTradedPrice);
            marketdata.LastTradeTime = Formatchange(data.LastTradeTime);
            marketdata.LastTradeQty = Formatchange(data.LastTradeQty);
            marketdata.Volume = Formatchange(data.Volume);
            marketdata.BestBidPrice = Formatchange(data.BestBidPrice);
            marketdata.BestBidQty = Formatchange(data.BestBidQty);
            marketdata.BestAskPrice = Formatchange(data.BestAskPrice);
            marketdata.BestAskQty = Formatchange(data.BestAskQty);
            marketdata.TotalBuyQty = Formatchange(data.TotalBuyQty);
            marketdata.TotalSellQty = Formatchange(data.TotalSellQty);
            marketdata.AverageTradePrice = Formatchange(data.AverageTradePrice);
            marketdata.ExchangeTimeStamp = Formatchange(data.ExchangeTimeStamp);
            marketdata.OpenPrice = Formatchange(data.OpenPrice);
            marketdata.HighPrice = Formatchange(data.HighPrice);
            marketdata.LowPrice = Formatchange(data.LowPrice);
            marketdata.ClosePrice = Formatchange(data.ClosePrice);
            marketdata.YearlyHigh = Formatchange(data.YearlyHigh);
            marketdata.YearlyLow = Formatchange(data.YearlyLow);


            //marketdata.Change = Formatchange(data.Change);
            return marketdata;
        }

        private static int Formatchange(int intVal)
        {
            var temp = BitConverter.GetBytes(intVal);
            if (BitConverter.IsLittleEndian) Array.Reverse(temp);
            intVal = BitConverter.ToInt32(temp, 0);
            return intVal;
        }

        private static long Formatchange(long longVal)
        {
            var temp = BitConverter.GetBytes(longVal);
            if (BitConverter.IsLittleEndian) Array.Reverse(temp);
            longVal = BitConverter.ToInt64(temp, 0);
            return longVal;
        }

    }

}

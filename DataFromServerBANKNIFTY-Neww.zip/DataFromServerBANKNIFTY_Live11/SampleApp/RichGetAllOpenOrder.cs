﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackTestUtilityApplication
{
    
    public class classPendingOrCompleteOrder
    {
        public String rejection_reason="";
        public String target_price_type="";
        public String average_trade_price="";
        public String exchange="";
        public String average_price="";
        public String mode="";
        public String order_tag="";
        public String exchange_order_id="";
        public String rejection_code="";
        public String filled_quantity="";
        public String remaining_quantity="";
        public String trigger_price="0";


        public String oms_order_id="";
        public String trading_symbol="";
        public String order_type="";
        public String disclosed_quantity="";
        public String price="0";
        public String trailing_stop_loss="";
        public String validity="";
        public String instrument_token="";
        public String lot_size="";
        public String order_side="";
        public String exchange_time="";
        public String client_id="";
        public String quantity="";
        public String order_entry_time="";
        public String user_order_id="";
        public String product="";
        public String order_status="";

    }
    class RichGetAllOpenOrder
    {
        public String BaseURL = RichUI.BaseURL;
        public Dictionary<String, classPendingOrCompleteOrder> AllPendingOrder = new Dictionary<string, classPendingOrCompleteOrder>();
        public Dictionary<String, classPendingOrCompleteOrder> AllCompleteOrder = new Dictionary<string, classPendingOrCompleteOrder>();

        public Dictionary<String, classPendingOrCompleteOrder> GetPendingOrder(String AuthToken, String clientCode)
        {
            RestClient client = new RestClient(BaseURL + "/api/v1/orders?type=Pending&client_id=" + clientCode);

            RestRequest request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", clientCode);
            request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTMwMzk0MXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l6TkdNNFl6UXlOMlJpT1RRME5UUTVZemcxWkRJelpEZzJOekk0WlRObHxc3R4qXSO766lrMVOqrwTiAXbuIwGkjA48d4V157oNRA==; oauth2_consent_csrf=MTU4OTMwMzk1NXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1T1RFeU4yUTVNak5oWWpRMVpETTVaVGMzT1dKaU1qTXdZamRoTXpVMnwrzXmqYAd1_r_CmrrHwWa-gyBgdx4GLYf28VZIEtHj2Q==");
            IRestResponse response = client.Execute(request);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
                AllPendingOrder.Clear();

                foreach (dynamic item in data.data.orders)
                {
                    try
                    {
                        classPendingOrCompleteOrder Obj = new classPendingOrCompleteOrder();

                        dynamic client_id = item.client_id;
                        dynamic exchange_order_id = item.exchange_order_id;
                        dynamic order_status = item.order_status;
                        dynamic order_type = item.order_type;
                        dynamic order_side = item.order_side;
                        dynamic trading_symbol = item.trading_symbol;
                        dynamic quantity = item.quantity;
                        dynamic trade_price = item.trade_price;
                        dynamic trigger_price = item.trigger_price;
                        dynamic product = item.product;
                        dynamic exchange = item.exchange;
                        dynamic order_entry_time = item.order_entry_time;


                        Obj.client_id= client_id.ToString();
                        Obj.exchange_order_id=exchange_order_id.ToString();
                        Obj.order_status = order_status.ToString();
                        Obj.order_type = order_type.ToString();
                        Obj.order_side = order_side.ToString();
                        Obj.trading_symbol = trading_symbol.ToString();
                        Obj.quantity = quantity.ToString();
                        Obj.average_trade_price = trade_price.ToString();
                        Obj.trigger_price = trigger_price.ToString();
                        Obj.product = product.ToString();
                        Obj.exchange = exchange.ToString();
                        Obj.order_entry_time= order_entry_time.ToString();

                        try
                        {
                            AllPendingOrder.Add(Obj.order_entry_time + Obj.exchange_order_id, Obj);
                        }
                        catch (Exception edfsaa)
                        {
                        }


                    }
                    catch (Exception edfsaa)
                    {
                    }
                }
            }
            return AllPendingOrder;
        }
        public Dictionary<String, classPendingOrCompleteOrder> GetCompleteOrder(String AuthToken, String clientCode)
        {
            RestClient client = new RestClient(BaseURL + "/api/v1/orders?type=Complete&client_id=" + clientCode);

            RestRequest request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", clientCode);
            request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTMwMzk0MXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l6TkdNNFl6UXlOMlJpT1RRME5UUTVZemcxWkRJelpEZzJOekk0WlRObHxc3R4qXSO766lrMVOqrwTiAXbuIwGkjA48d4V157oNRA==; oauth2_consent_csrf=MTU4OTMwMzk1NXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1T1RFeU4yUTVNak5oWWpRMVpETTVaVGMzT1dKaU1qTXdZamRoTXpVMnwrzXmqYAd1_r_CmrrHwWa-gyBgdx4GLYf28VZIEtHj2Q==");
            IRestResponse response = client.Execute(request);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
                AllCompleteOrder.Clear();

                foreach (dynamic item in data.data.orders)
                {
                    try
                    {
                        classPendingOrCompleteOrder Obj = new classPendingOrCompleteOrder();

                        dynamic client_id = item.client_id;
                        dynamic exchange_order_id = item.exchange_order_id;
                        dynamic order_status = item.order_status;
                        dynamic order_type = item.order_type;
                        dynamic order_side = item.order_side;
                        dynamic trading_symbol = item.trading_symbol;
                        dynamic quantity = item.quantity;
                        dynamic trade_price = item.trade_price;
                        dynamic trigger_price = item.trigger_price;
                        dynamic product = item.product;
                        dynamic exchange = item.exchange;
                        dynamic order_entry_time = item.order_entry_time;


                        Obj.client_id = client_id.ToString();
                        Obj.exchange_order_id = exchange_order_id.ToString();
                        Obj.order_status = order_status.ToString();
                        Obj.order_type = order_type.ToString();
                        Obj.order_side = order_side.ToString();
                        Obj.trading_symbol = trading_symbol.ToString();
                        Obj.quantity = quantity.ToString();
                        Obj.average_trade_price = trade_price.ToString();
                        Obj.trigger_price = trigger_price.ToString();
                        Obj.product = product.ToString();
                        Obj.exchange = exchange.ToString();
                        Obj.order_entry_time = order_entry_time.ToString();

                        try
                        {
                            AllCompleteOrder.Add(Obj.order_entry_time + Obj.exchange_order_id, Obj);
                        }
                        catch (Exception edfsaa)
                        {
                        }


                    }
                    catch (Exception edfsaa)
                    {
                    }
                }
            }
            return AllCompleteOrder;
        }




    }
}

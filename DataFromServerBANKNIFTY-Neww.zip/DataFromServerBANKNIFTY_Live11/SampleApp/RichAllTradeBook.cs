﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackTestUtilityApplication
{
    public class TradeBookALL
    {
        public String client_id = "";
        public String exchange = "";
        public String exchange_order_id = "";
        public String exchange_time = "";
        public String filled_quantity = "";
        public String instrument_token = "";
        public String oms_order_id = "";
        public String order_entry_time = "";
        public String order_price = "";
        public String order_side = "";
        public String order_type = "";
        public String product = "";
        public String trade_price = "";
        public String trade_quantity = "";
        public String trade_time = "";
        public String trading_symbol = "";
        public String trigger_price = "";
        

    }
    class RichAllTradeBook
    {
        public String BaseURL = RichUI.BaseURL;
        public Dictionary<String, TradeBookALL> AllTradeOrders = new Dictionary<string, TradeBookALL>();
        public Dictionary<String, TradeBookALL> GetTradeOrderBook(String AuthToken, String clientCode)
        {
            var client = new RestClient(BaseURL+"/api/v1/trades?client_id="+ clientCode);
            
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", clientCode);
            request.AddHeader("Cookie", "oauth2_authentication_csrf=MTU4OTMwMzk0MXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJR0l6TkdNNFl6UXlOMlJpT1RRME5UUTVZemcxWkRJelpEZzJOekk0WlRObHxc3R4qXSO766lrMVOqrwTiAXbuIwGkjA48d4V157oNRA==; oauth2_consent_csrf=MTU4OTMwMzk1NXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFk1T1RFeU4yUTVNak5oWWpRMVpETTVaVGMzT1dKaU1qTXdZamRoTXpVMnwrzXmqYAd1_r_CmrrHwWa-gyBgdx4GLYf28VZIEtHj2Q==");
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
                AllTradeOrders.Clear();

                foreach (dynamic item in data.data.trades)
                {
                    try
                    {
                        TradeBookALL Obj = new TradeBookALL();

                        dynamic client_id = item.client_id;
                        dynamic exchange_order_id = item.exchange_order_id;
                        dynamic order_type = item.order_type;
                        dynamic order_side = item.order_side;
                        dynamic trading_symbol = item.trading_symbol;
                        dynamic filled_quantity = item.filled_quantity;
                        dynamic trade_price = item.trade_price;
                        dynamic trigger_price = item.trigger_price;
                        dynamic product = item.product;
                        dynamic exchange = item.exchange;
                        dynamic order_entry_time = item.order_entry_time;


                        Obj.client_id = client_id.ToString();
                        Obj.exchange_order_id = exchange_order_id.ToString();

                        Obj.filled_quantity = filled_quantity.ToString();
                        Obj.order_type = order_type.ToString();
                        Obj.order_side = order_side.ToString();
                        Obj.trading_symbol = trading_symbol.ToString();
          
                        Obj.trade_price = trade_price.ToString();
                        Obj.trigger_price = trigger_price.ToString();
                        Obj.product = product.ToString();
                        Obj.exchange = exchange.ToString();
                        Obj.order_entry_time = order_entry_time.ToString();

                        try
                        {
                            AllTradeOrders.Add(Obj.order_entry_time + Obj.exchange_order_id, Obj);
                        }
                        catch (Exception edfsaa)
                        {
                        }


                    }
                    catch (Exception edfsaa)
                    {
                    }
                }
            }
            return AllTradeOrders;
        }
    }

}

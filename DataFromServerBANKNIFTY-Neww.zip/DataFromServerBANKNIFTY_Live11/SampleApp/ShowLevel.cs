﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackTestUtilityApplication
{
    public partial class ShowLevel : Form
    {
        StrategyDetailsORB MailSD;
        public ShowLevel()
        {
            InitializeComponent();
        }

        internal void UpdateRowNow(StrategyDetailsORB sd)
        {
            MailSD = sd;
            foreach (var item in sd.ALLCandleTillNow)
            {
             
                DGV_ShowLEVEL.Rows.Add(item.Key, item.Value.OPEN, item.Value.High, item.Value.Low, item.Value.Close);
            }
        }

        private void DGV_ShowLEVEL_MouseClick(object sender, MouseEventArgs e)
        {
           /* if (e.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();
                m.MenuItems.Add(new MenuItem("Mark as Waiting For Entry", MarkasWaiting));
                m.MenuItems.Add(new MenuItem("Mark as Waiting for Entry", MarkasEntryExecuted));
                m.MenuItems.Add(new MenuItem("Mark as Complete", MarkasComplete));

                int currentMouseOverRow = DGV_ShowLEVEL.HitTest(e.X, e.Y).RowIndex;

                if (currentMouseOverRow >= 0)
                {
                    //        m.MenuItems.Add(new MenuItem(string.Format("Do something to row {0}", currentMouseOverRow.ToString())));
                }

                m.Show(DGV_ShowLEVEL, new Point(e.X, e.Y));

            }*/
        }

        private void MarkasComplete(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Mark as Complete?", " Change Status ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    int selectedrowindex = DGV_ShowLEVEL.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = DGV_ShowLEVEL.Rows[selectedrowindex];

                    Double StepPrice = Convert.ToDouble(selectedRow.Cells["col_Step"].Value);
                    String Status = "Complete";
                   // MailSD.StepLevel[StepPrice] = 4;
                    selectedRow.Cells["col_Status"].Value = Status;
                }
                catch (Exception sdqqq)
                {
                }

            }
        }

        private void MarkasEntryExecuted(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Mark as Waiting for Exit ?", " Change Status ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    int selectedrowindex = DGV_ShowLEVEL.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = DGV_ShowLEVEL.Rows[selectedrowindex];

                    Double StepPrice = Convert.ToDouble(selectedRow.Cells["col_Step"].Value);
                    String Status = "Waiting for Exit";
                 //   MailSD.StepLevel[StepPrice] = 2;
                    selectedRow.Cells["col_Status"].Value = Status;
                }
                catch (Exception sdqqq)
                {
                }

            }
        }

        private void MarkasWaiting(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to Mark as Waiting for Entry", " Change Status ?", MessageBoxButtons.YesNoCancel,
           MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    int selectedrowindex = DGV_ShowLEVEL.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = DGV_ShowLEVEL.Rows[selectedrowindex];

                    Double StepPrice = Convert.ToDouble(selectedRow.Cells["col_Step"].Value);
                    String Status = "Waiting for Entry";
                   // MailSD.StepLevel[StepPrice] = 0;
                    selectedRow.Cells["col_Status"].Value = Status;
                }
                catch (Exception sdqqq)
                {
                }

            }
        }

        private void DGV_ShowLEVEL_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DGV_ShowLEVEL_MouseClick_1(object sender, MouseEventArgs e)
        {
         /*   if (e.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();
                m.MenuItems.Add(new MenuItem("Mark as Waiting For Entry", MarkasWaiting));
                m.MenuItems.Add(new MenuItem("Mark as Waiting for Exit", MarkasEntryExecuted));
                m.MenuItems.Add(new MenuItem("Mark as Complete", MarkasComplete));

                int currentMouseOverRow = DGV_ShowLEVEL.HitTest(e.X, e.Y).RowIndex;

                if (currentMouseOverRow >= 0)
                {
                    //        m.MenuItems.Add(new MenuItem(string.Format("Do something to row {0}", currentMouseOverRow.ToString())));
                }

                m.Show(DGV_ShowLEVEL, new Point(e.X, e.Y));

            }*/
        }
    }
}

﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackTestUtilityApplication
{
    public class Intrument_Token
    {
        Dictionary<String, Int32> NSE_OTH = new Dictionary<string, int>();
        Dictionary<String, Int32> NSE_IND = new Dictionary<string, int>();
        Dictionary<String, Int32> NSE = new Dictionary<string, int>();
        Dictionary<String, Int32> NSE_OPT = new Dictionary<string, int>();
        Dictionary<String, Int32> NSE_FUT = new Dictionary<string, int>();
        Dictionary<String, Int32> MCX = new Dictionary<string, int>();
       
        string nse = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=NSE";
        string nfo = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=NFO";
        string mcx = "https://masterswift.mastertrust.co.in/api/v2/contracts.json?exchanges=MCX";

        public Dictionary<String, Int32> get_NSE_OTH_Dic()
        {
            var cli = new RestClient(nse);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                NSE_OTH.Clear();
            }
           // AutoCompleteDic.Clear();
            foreach (dynamic item in data["NSE-OTH"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                NSE_OTH.Add(symbol.Value, Int32.Parse(code.Value));
               // AutoCompleteDic.Add(symbol.Value);
            }
            return NSE_OTH;
        }
        public Dictionary<String, Int32> get_NSE_IND_Dic()
        {
            var cli = new RestClient(nse);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                NSE_IND.Clear();
            }
            foreach (dynamic item in data["NSE-IND"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                NSE_IND.Add(symbol.Value, Int32.Parse(code.Value));
            }
            return NSE_IND;
        }
        public Dictionary<String, Int32> get_NSE_Dic()
        {
            var cli = new RestClient(nse);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                NSE.Clear();
            }
            foreach (dynamic item in data["NSE"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                NSE.Add(symbol.Value, Int32.Parse(code.Value));
            }
            return NSE;
        }
        public Dictionary<String, Int32> get_NSE_OPT_Dic()
        {
            var cli = new RestClient(nfo);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                NSE_OPT.Clear();
            }
            foreach (dynamic item in data["NSE-OPT"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                NSE_OPT.Add(symbol.Value, Int32.Parse(code.Value));
            }
            return NSE_OPT;
        }
        public Dictionary<String, Int32> get_NSE_FUT_Dic()
        {
            var cli = new RestClient(nfo);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                NSE_FUT.Clear();
            }
            foreach (dynamic item in data["NSE-FUT"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                NSE_FUT.Add(symbol.Value, Int32.Parse(code.Value));
            }
            return NSE_FUT;
        }
        public Dictionary<String, Int32> get_MCX_Dic()
        {
            var cli = new RestClient(mcx);
            var getNSE = new RestRequest(Method.GET);
            IRestResponse response = cli.Execute(getNSE);
            dynamic data = JValue.Parse(response.Content);
            if (response.IsSuccessful)
            {
                MCX.Clear();
            }
            foreach (dynamic item in data["MCX"])
            {
                dynamic symbol = item.symbol;
                dynamic code = item.code;
                MCX.Add(symbol.Value, Int32.Parse(code.Value));
            }
            return MCX;
        }


    }
}

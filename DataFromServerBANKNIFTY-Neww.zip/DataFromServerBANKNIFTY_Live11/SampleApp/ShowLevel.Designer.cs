﻿namespace BackTestUtilityApplication
{
    partial class ShowLevel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_ShowLEVEL = new System.Windows.Forms.DataGridView();
            this.col_Step = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_high = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_low = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_close = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ShowLEVEL)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_ShowLEVEL
            // 
            this.DGV_ShowLEVEL.AllowUserToAddRows = false;
            this.DGV_ShowLEVEL.AllowUserToDeleteRows = false;
            this.DGV_ShowLEVEL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_ShowLEVEL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_Step,
            this.col_Status,
            this.col_high,
            this.col_low,
            this.col_close});
            this.DGV_ShowLEVEL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_ShowLEVEL.Location = new System.Drawing.Point(0, 0);
            this.DGV_ShowLEVEL.Name = "DGV_ShowLEVEL";
            this.DGV_ShowLEVEL.ReadOnly = true;
            this.DGV_ShowLEVEL.RowHeadersVisible = false;
            this.DGV_ShowLEVEL.Size = new System.Drawing.Size(523, 354);
            this.DGV_ShowLEVEL.TabIndex = 1;
            this.DGV_ShowLEVEL.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_ShowLEVEL_CellContentClick);
            this.DGV_ShowLEVEL.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DGV_ShowLEVEL_MouseClick_1);
            // 
            // col_Step
            // 
            this.col_Step.HeaderText = "Time";
            this.col_Step.Name = "col_Step";
            this.col_Step.ReadOnly = true;
            this.col_Step.Width = 120;
            // 
            // col_Status
            // 
            this.col_Status.HeaderText = "OPEN";
            this.col_Status.Name = "col_Status";
            this.col_Status.ReadOnly = true;
            // 
            // col_high
            // 
            this.col_high.HeaderText = "HIGH";
            this.col_high.Name = "col_high";
            this.col_high.ReadOnly = true;
            // 
            // col_low
            // 
            this.col_low.HeaderText = "LOW";
            this.col_low.Name = "col_low";
            this.col_low.ReadOnly = true;
            // 
            // col_close
            // 
            this.col_close.HeaderText = "CLOSE";
            this.col_close.Name = "col_close";
            this.col_close.ReadOnly = true;
            // 
            // ShowLevel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 354);
            this.Controls.Add(this.DGV_ShowLEVEL);
            this.Name = "ShowLevel";
            this.Text = "ShowLevel";
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ShowLEVEL)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_ShowLEVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Step;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_high;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_low;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_close;
    }
}
﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackTestUtilityApplication
{
    public class Holding
    {
        public String buy_avg = "";
        public String buy_avg_mtm = "";
        public String client_id = "";
        public String exchange = "";
        public String ltp = "";
        public String previous_close = "";
        public String quantity = "";
        public String symbol = "";
        public String token = "";

    }
    class RichHolding
    {
        String BaseURL = RichUI.BaseURL;
        public Dictionary<String, Holding> AllLivenHistoricalPosition = new Dictionary<string, Holding>();
        public Dictionary<String, Holding> getHolding(String AuthToken, String ClientID)
        {

            var client = new RestClient(BaseURL+"/api/v1/holdings?client_id="+ClientID);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("x-authorization-token", AuthToken);
            request.AddHeader("client_id", ClientID);
            //request.AddHeader("Authorization", "Bearer bW48NCDYxN2mEUCljO-bsBqhXvtyx36adAHQ21a9PSE.Y8IUXB4AJwY-EuVLt3SVXsneKtKotr9ebK6OniLK9Tc");
            request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYYVNmdG5jMnBiRDRudlZaZVhWS201ZV82.76EqMgJrrA3ul87MW_cNdcXkOKCGmlm6M0NFpUBrNz0; oauth2_authentication_csrf=MTU4OTYxNzc3OHxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRFpsT1dOak56RTROakJpTVRRNE16TmlPR1l3TWpFNU9ERmlaV1ExTnpoanw5AGewzQLK8J_G8JUYjaO3t-p-sw1k4I1X_h7THj7jlQ==; oauth2_consent_csrf=MTU4OTYxNzc4N3xEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJRGxoWVRGbU5qSmhORFZsWkRReE16UTRNMkUzTnpBeU1HTmtNemc1TWpKbHweb7i8mSR2m5xyT1Pa3upYztfk66Esnv2Cmioi5Gppaw==");
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() == "success")
            {
                AllLivenHistoricalPosition.Clear();
                foreach (dynamic item in data.data.holdings)
                {
                    try
                    {
                        Holding Obj = new Holding();

                        dynamic client_idP = item.client_id;
                        dynamic buy_avgP = item.buy_avg;
                        dynamic buy_avg_mtmP = item.buy_avg_mtm;
                        dynamic exchangeP = item.exchange;
                        dynamic ltpP = item.ltp;
                        dynamic previous_closeP = item.previous_close;
                        dynamic quantityP = item.quantity;
                        dynamic symbolP = item.symbol;
                        dynamic tokenP = item.token;

                        Obj.client_id = client_idP.ToString();
                        Obj.buy_avg = buy_avgP.ToString();
                        Obj.buy_avg_mtm = buy_avg_mtmP.ToString();
                        Obj.exchange = exchangeP.ToString();
                        Obj.ltp = ltpP.ToString();
                        Obj.previous_close = previous_closeP.ToString();
                        Obj.quantity = quantityP.ToString();
                        Obj.symbol = symbolP.ToString();
                        Obj.token = tokenP.ToString();

                        AllLivenHistoricalPosition.Add(Obj.symbol, Obj);
                    }
                    catch (Exception jhjk)
                    {
                    }

                }
            }
            return AllLivenHistoricalPosition;
        }
    }
}

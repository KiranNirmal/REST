﻿namespace BackTestUtilityApplication
{
    partial class RichUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RichUI));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.KryptonContextMenuItems7 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItems8 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItems11 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItems9 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuHelp = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.KryptonContextMenuItems3 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem14 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem22 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem23 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem15 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuTools = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.KryptonContextMenuItems4 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem16 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem17 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem18 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem19 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem21 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuOrder = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.KryptonContextMenuItems2 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem10 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem11 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem13 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem12 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuFile = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.KryptonContextMenuItems1 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem1 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem5 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem6 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem7 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem8 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem9 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonDataGridView7 = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.KryptonContextMenuCommon = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.KryptonContextMenuItems5 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem20 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonDataGridView8 = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.KryptonDataGridView9 = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.OptionPage = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.TopBottomSplit = new System.Windows.Forms.SplitContainer();
            this.kryptonPanel6 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.GrpCandleJC = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReadCSV = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.Update = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.txtNLow = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.txtNhigh = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBlow = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBhigh = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.txtstartTimeORB = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.btnStartCandleJC = new System.Windows.Forms.Button();
            this.btnAddCandleJC = new System.Windows.Forms.Button();
            this.txt_SqTimeORB = new System.Windows.Forms.DateTimePicker();
            this.txt_EndTimeORB = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.kryptonPanel10 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.btnUpdate = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.btnDeleteClient = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label25 = new System.Windows.Forms.Label();
            this.txtDeleteClient = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnDeletescript = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label24 = new System.Windows.Forms.Label();
            this.txtDeleteScript = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnScript = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label15 = new System.Windows.Forms.Label();
            this.txtScript = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnLoadClientwise = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSClientSelect = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.DGV_CandleJC = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.o_sid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_start = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_acc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_EntryC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Trail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_token = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_symbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_symbolltp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_high = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_open = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_low = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_targetPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_stoplossPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.o_PL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_EndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCurrentPLORB = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtstoplossCandleJC = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.txttargetCandleJC = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.ContextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddStrategyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KryptonButton2 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.btnStart = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.txtAdd = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.KryptonINTRUMENT = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.KryptonSEGMENT = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.KryptonEXCHNAGE = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.SaveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.kryptonContextMenuItems6 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.kryptonContextMenuItems10 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.kryptonContextMenuItems12 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonPanel5 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.btnSendEmail = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButton3 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label22 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSubscribe = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.txtClientCount = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.kryptonButton5 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.KryptonContextMenuOrderBook = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.kryptonContextMenuItems13 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.SimpleToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.kryptonContextMenuItems14 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.ModifyToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.CancelToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.OCOToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.kryptonContextMenuItems15 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.ModifyEntryToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.CancelEntryOrderToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ModifyTargetToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ModifyStoplossToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ExitToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.COToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.kryptonContextMenuItems16 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.CancelEntryToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ModifyStoplossToolStripMenuItem1 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ExitToolStripMenuItem1 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ExportOrderBookMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuMarketWatch = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.kryptonContextMenuItems17 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.KryptonContextMenuItem2 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem3 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonContextMenuItem4 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonPage2 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonPendingOB = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.T_Symbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Side = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_OMS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KryptonPanel2 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.KryptonPanel1 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.KryptonRichConfirmationPanel = new ComponentFactory.Krypton.Toolkit.KryptonRichTextBox();
            this.KryptonPanel3 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.KryptonDockableNavigator1 = new ComponentFactory.Krypton.Docking.KryptonDockableNavigator();
            this.KryptonPage1 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonPage9 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonPage3 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonContextMenuPositions = new ComponentFactory.Krypton.Toolkit.KryptonContextMenu();
            this.kryptonContextMenuItems18 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.ExitPositionToolStripMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.ExportPositionsMenuItem = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem();
            this.KryptonPage4 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonPage5 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonPage6 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.KryptonMarketWatch = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.V_Token = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Exe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Sym = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_LTP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Ltq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Bid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_BidQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Ask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_AskQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Open = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_High = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Low = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Close = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Atp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_Volumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_LastUTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V_LastTTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KryptonTradeBook = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.T_Sym = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Si = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Ty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Qt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Pri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Ti = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Statu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_OMSO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KryptonPositionDataGrid = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.P_Symbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_Privi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_LTP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_Mtm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_Change = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KryptonDataGridView4 = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.KryptonDataGridView5 = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.KryptonDockableNavigator2 = new ComponentFactory.Krypton.Docking.KryptonDockableNavigator();
            this.kryptonContextMenuItems19 = new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems();
            this.kryptonDockableNavigator3 = new ComponentFactory.Krypton.Docking.KryptonDockableNavigator();
            this.kryptonPage7 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel11 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonPage8 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel8 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.txtClientIDOrderBook = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.OrderBookRefresh = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonPage13 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel4 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.txtClientIDTradeBook = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnTradeBook = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonPage14 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel9 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.btnPosHistorical = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.txtClientIDPosition = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnPosLive = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonPage15 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel7 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.txtClientIDHoldings = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.btnHoldings = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonHolding = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kryptonPage18 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPage16 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPanel12 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonButton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.allTrades = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OptionPage)).BeginInit();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TopBottomSplit)).BeginInit();
            this.TopBottomSplit.Panel1.SuspendLayout();
            this.TopBottomSplit.Panel2.SuspendLayout();
            this.TopBottomSplit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel6)).BeginInit();
            this.kryptonPanel6.SuspendLayout();
            this.GrpCandleJC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNLow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNhigh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBlow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBhigh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel10)).BeginInit();
            this.kryptonPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeleteClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeleteScript)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScript)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSClientSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CandleJC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoplossCandleJC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttargetCandleJC)).BeginInit();
            this.ContextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonINTRUMENT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSEGMENT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonEXCHNAGE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel5)).BeginInit();
            this.KryptonPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPendingOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel2)).BeginInit();
            this.KryptonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel1)).BeginInit();
            this.KryptonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel3)).BeginInit();
            this.KryptonPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDockableNavigator1)).BeginInit();
            this.KryptonDockableNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonMarketWatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonTradeBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPositionDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDockableNavigator2)).BeginInit();
            this.KryptonDockableNavigator2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonDockableNavigator3)).BeginInit();
            this.kryptonDockableNavigator3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage7)).BeginInit();
            this.kryptonPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel11)).BeginInit();
            this.kryptonPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage8)).BeginInit();
            this.kryptonPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel8)).BeginInit();
            this.kryptonPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDOrderBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage13)).BeginInit();
            this.kryptonPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).BeginInit();
            this.kryptonPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDTradeBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage14)).BeginInit();
            this.kryptonPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel9)).BeginInit();
            this.kryptonPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage15)).BeginInit();
            this.kryptonPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).BeginInit();
            this.kryptonPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDHoldings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHolding)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage18)).BeginInit();
            this.kryptonPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage16)).BeginInit();
            this.kryptonPage16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel12)).BeginInit();
            this.kryptonPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allTrades)).BeginInit();
            this.SuspendLayout();
            // 
            // KryptonContextMenuHelp
            // 
            this.KryptonContextMenuHelp.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItems3});
            // 
            // KryptonContextMenuItems3
            // 
            this.KryptonContextMenuItems3.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem14,
            this.KryptonContextMenuItem22,
            this.KryptonContextMenuItem23,
            this.KryptonContextMenuItem15});
            // 
            // KryptonContextMenuItem14
            // 
            this.KryptonContextMenuItem14.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem14.Image")));
            this.KryptonContextMenuItem14.Text = "Help";
            // 
            // KryptonContextMenuItem22
            // 
            this.KryptonContextMenuItem22.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem22.Image")));
            this.KryptonContextMenuItem22.Text = "Disclaimer";
            // 
            // KryptonContextMenuItem23
            // 
            this.KryptonContextMenuItem23.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem23.Image")));
            this.KryptonContextMenuItem23.Text = "License";
            // 
            // KryptonContextMenuItem15
            // 
            this.KryptonContextMenuItem15.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem15.Image")));
            this.KryptonContextMenuItem15.Text = "About";
            // 
            // KryptonContextMenuTools
            // 
            this.KryptonContextMenuTools.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItems4});
            // 
            // KryptonContextMenuItems4
            // 
            this.KryptonContextMenuItems4.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem16,
            this.KryptonContextMenuItem17,
            this.KryptonContextMenuItem18,
            this.KryptonContextMenuItem19,
            this.KryptonContextMenuItem21});
            // 
            // KryptonContextMenuItem16
            // 
            this.KryptonContextMenuItem16.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem16.Image")));
            this.KryptonContextMenuItem16.Text = "Historical Data";
            // 
            // KryptonContextMenuItem17
            // 
            this.KryptonContextMenuItem17.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem17.Image")));
            this.KryptonContextMenuItem17.Text = "Batch Order";
            // 
            // KryptonContextMenuItem18
            // 
            this.KryptonContextMenuItem18.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem18.Image")));
            this.KryptonContextMenuItem18.Text = "Order Latency";
            // 
            // KryptonContextMenuItem19
            // 
            this.KryptonContextMenuItem19.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem19.Image")));
            this.KryptonContextMenuItem19.Text = "Batch Historical Data";
            // 
            // KryptonContextMenuItem21
            // 
            this.KryptonContextMenuItem21.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem21.Image")));
            this.KryptonContextMenuItem21.Text = "Clear IE Cookies";
            // 
            // KryptonContextMenuOrder
            // 
            this.KryptonContextMenuOrder.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItems2});
            // 
            // KryptonContextMenuItems2
            // 
            this.KryptonContextMenuItems2.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem10,
            this.KryptonContextMenuItem11,
            this.KryptonContextMenuItem13,
            this.KryptonContextMenuItem12});
            // 
            // KryptonContextMenuItem10
            // 
            this.KryptonContextMenuItem10.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem10.Image")));
            this.KryptonContextMenuItem10.ShortcutKeyDisplayString = "F1";
            this.KryptonContextMenuItem10.Text = "Buy Order";
            // 
            // KryptonContextMenuItem11
            // 
            this.KryptonContextMenuItem11.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem11.Image")));
            this.KryptonContextMenuItem11.ShortcutKeyDisplayString = "F2";
            this.KryptonContextMenuItem11.Text = "Sell Order";
            // 
            // KryptonContextMenuItem13
            // 
            this.KryptonContextMenuItem13.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem13.Image")));
            this.KryptonContextMenuItem13.ShortcutKeyDisplayString = "F3";
            this.KryptonContextMenuItem13.Text = "Modify Order";
            // 
            // KryptonContextMenuItem12
            // 
            this.KryptonContextMenuItem12.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem12.Image")));
            this.KryptonContextMenuItem12.ShortcutKeyDisplayString = "F4";
            this.KryptonContextMenuItem12.Text = "Bridge Order";
            // 
            // KryptonContextMenuFile
            // 
            this.KryptonContextMenuFile.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItems1});
            // 
            // KryptonContextMenuItems1
            // 
            this.KryptonContextMenuItems1.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem1,
            this.KryptonContextMenuItem5,
            this.KryptonContextMenuItem6,
            this.KryptonContextMenuItem7,
            this.KryptonContextMenuItem8,
            this.KryptonContextMenuItem9});
            // 
            // KryptonContextMenuItem1
            // 
            this.KryptonContextMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem1.Image")));
            this.KryptonContextMenuItem1.Text = "Login with IE";
            // 
            // KryptonContextMenuItem5
            // 
            this.KryptonContextMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem5.Image")));
            this.KryptonContextMenuItem5.Text = "Login with Chrome";
            // 
            // KryptonContextMenuItem6
            // 
            this.KryptonContextMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem6.Image")));
            this.KryptonContextMenuItem6.Text = "Get AccessToken";
            // 
            // KryptonContextMenuItem7
            // 
            this.KryptonContextMenuItem7.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem7.Image")));
            this.KryptonContextMenuItem7.Text = "Set AccessToken";
            // 
            // KryptonContextMenuItem8
            // 
            this.KryptonContextMenuItem8.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem8.Image")));
            this.KryptonContextMenuItem8.Text = "Logout";
            // 
            // KryptonContextMenuItem9
            // 
            this.KryptonContextMenuItem9.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem9.Image")));
            this.KryptonContextMenuItem9.Text = "Exit";
            // 
            // KryptonDataGridView7
            // 
            this.KryptonDataGridView7.AllowUserToAddRows = false;
            this.KryptonDataGridView7.AllowUserToDeleteRows = false;
            this.KryptonDataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonDataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDataGridView7.Location = new System.Drawing.Point(0, 66);
            this.KryptonDataGridView7.Name = "KryptonDataGridView7";
            this.KryptonDataGridView7.ReadOnly = true;
            this.KryptonDataGridView7.Size = new System.Drawing.Size(1370, 548);
            this.KryptonDataGridView7.TabIndex = 24;
            // 
            // KryptonContextMenuCommon
            // 
            this.KryptonContextMenuCommon.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItems5});
            // 
            // KryptonContextMenuItems5
            // 
            this.KryptonContextMenuItems5.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem20});
            // 
            // KryptonContextMenuItem20
            // 
            this.KryptonContextMenuItem20.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem20.Image")));
            this.KryptonContextMenuItem20.Text = "Export";
            // 
            // KryptonDataGridView8
            // 
            this.KryptonDataGridView8.AllowUserToAddRows = false;
            this.KryptonDataGridView8.AllowUserToDeleteRows = false;
            this.KryptonDataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonDataGridView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDataGridView8.Location = new System.Drawing.Point(0, 66);
            this.KryptonDataGridView8.Name = "KryptonDataGridView8";
            this.KryptonDataGridView8.ReadOnly = true;
            this.KryptonDataGridView8.Size = new System.Drawing.Size(1370, 548);
            this.KryptonDataGridView8.TabIndex = 25;
            // 
            // KryptonDataGridView9
            // 
            this.KryptonDataGridView9.AllowUserToAddRows = false;
            this.KryptonDataGridView9.AllowUserToDeleteRows = false;
            this.KryptonDataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonDataGridView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDataGridView9.Location = new System.Drawing.Point(0, 66);
            this.KryptonDataGridView9.Name = "KryptonDataGridView9";
            this.KryptonDataGridView9.ReadOnly = true;
            this.KryptonDataGridView9.Size = new System.Drawing.Size(1370, 548);
            this.KryptonDataGridView9.TabIndex = 27;
            // 
            // OptionPage
            // 
            this.OptionPage.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.OptionPage.Flags = 65534;
            this.OptionPage.LastVisibleSet = true;
            this.OptionPage.MinimumSize = new System.Drawing.Size(50, 50);
            this.OptionPage.Name = "OptionPage";
            this.OptionPage.Size = new System.Drawing.Size(1362, 716);
            this.OptionPage.Text = "Option Strategy";
            this.OptionPage.ToolTipTitle = "Page ToolTip";
            this.OptionPage.UniqueName = "446DDDF95C6D44496E9E497A338472E2";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Panel1.Controls.Add(this.TopBottomSplit);
            this.Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1368, 517);
            this.Panel1.TabIndex = 12;
            // 
            // TopBottomSplit
            // 
            this.TopBottomSplit.BackColor = System.Drawing.Color.Transparent;
            this.TopBottomSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TopBottomSplit.IsSplitterFixed = true;
            this.TopBottomSplit.Location = new System.Drawing.Point(0, 0);
            this.TopBottomSplit.Margin = new System.Windows.Forms.Padding(1);
            this.TopBottomSplit.Name = "TopBottomSplit";
            this.TopBottomSplit.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // TopBottomSplit.Panel1
            // 
            this.TopBottomSplit.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TopBottomSplit.Panel1.Controls.Add(this.kryptonPanel6);
            // 
            // TopBottomSplit.Panel2
            // 
            this.TopBottomSplit.Panel2.Controls.Add(this.splitContainer1);
            this.TopBottomSplit.Size = new System.Drawing.Size(1368, 517);
            this.TopBottomSplit.SplitterDistance = 92;
            this.TopBottomSplit.TabIndex = 3;
            // 
            // kryptonPanel6
            // 
            this.kryptonPanel6.Controls.Add(this.GrpCandleJC);
            this.kryptonPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel6.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel6.Name = "kryptonPanel6";
            this.kryptonPanel6.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel6.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.kryptonPanel6.Size = new System.Drawing.Size(1368, 92);
            this.kryptonPanel6.TabIndex = 40;
            // 
            // GrpCandleJC
            // 
            this.GrpCandleJC.BackColor = System.Drawing.Color.Transparent;
            this.GrpCandleJC.Controls.Add(this.label2);
            this.GrpCandleJC.Controls.Add(this.btnReadCSV);
            this.GrpCandleJC.Controls.Add(this.Update);
            this.GrpCandleJC.Controls.Add(this.txtNLow);
            this.GrpCandleJC.Controls.Add(this.label16);
            this.GrpCandleJC.Controls.Add(this.txtNhigh);
            this.GrpCandleJC.Controls.Add(this.label20);
            this.GrpCandleJC.Controls.Add(this.txtBlow);
            this.GrpCandleJC.Controls.Add(this.label13);
            this.GrpCandleJC.Controls.Add(this.txtBhigh);
            this.GrpCandleJC.Controls.Add(this.label12);
            this.GrpCandleJC.Controls.Add(this.txtstartTimeORB);
            this.GrpCandleJC.Controls.Add(this.label9);
            this.GrpCandleJC.Controls.Add(this.btnStartCandleJC);
            this.GrpCandleJC.Controls.Add(this.btnAddCandleJC);
            this.GrpCandleJC.Controls.Add(this.txt_SqTimeORB);
            this.GrpCandleJC.Controls.Add(this.txt_EndTimeORB);
            this.GrpCandleJC.Controls.Add(this.label10);
            this.GrpCandleJC.Controls.Add(this.label19);
            this.GrpCandleJC.Location = new System.Drawing.Point(6, 6);
            this.GrpCandleJC.Name = "GrpCandleJC";
            this.GrpCandleJC.Size = new System.Drawing.Size(1337, 68);
            this.GrpCandleJC.TabIndex = 2;
            this.GrpCandleJC.TabStop = false;
            this.GrpCandleJC.Text = "CandleJC Parameter";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1139, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 15);
            this.label2.TabIndex = 63;
            this.label2.Text = "OR";
            // 
            // btnReadCSV
            // 
            this.btnReadCSV.Location = new System.Drawing.Point(1182, 29);
            this.btnReadCSV.Name = "btnReadCSV";
            this.btnReadCSV.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnReadCSV.Size = new System.Drawing.Size(133, 24);
            this.btnReadCSV.TabIndex = 64;
            this.btnReadCSV.Values.Text = "Read CSV NOW";
            this.btnReadCSV.Click += new System.EventHandler(this.btnReadCSV_Click);
            // 
            // Update
            // 
            this.Update.Location = new System.Drawing.Point(1004, 29);
            this.Update.Name = "Update";
            this.Update.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.Update.Size = new System.Drawing.Size(104, 24);
            this.Update.TabIndex = 50;
            this.Update.Values.Text = "Update";
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // txtNLow
            // 
            this.txtNLow.Location = new System.Drawing.Point(883, 33);
            this.txtNLow.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txtNLow.Name = "txtNLow";
            this.txtNLow.Size = new System.Drawing.Size(98, 20);
            this.txtNLow.TabIndex = 61;
            this.txtNLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(880, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 15);
            this.label16.TabIndex = 60;
            this.label16.Text = "Nifty Low";
            // 
            // txtNhigh
            // 
            this.txtNhigh.Location = new System.Drawing.Point(779, 33);
            this.txtNhigh.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txtNhigh.Name = "txtNhigh";
            this.txtNhigh.Size = new System.Drawing.Size(98, 20);
            this.txtNhigh.TabIndex = 59;
            this.txtNhigh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(776, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 15);
            this.label20.TabIndex = 58;
            this.label20.Text = "Nifty High";
            // 
            // txtBlow
            // 
            this.txtBlow.Location = new System.Drawing.Point(673, 33);
            this.txtBlow.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txtBlow.Name = "txtBlow";
            this.txtBlow.Size = new System.Drawing.Size(98, 20);
            this.txtBlow.TabIndex = 57;
            this.txtBlow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(670, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 15);
            this.label13.TabIndex = 56;
            this.label13.Text = "BankNifty Low";
            // 
            // txtBhigh
            // 
            this.txtBhigh.Location = new System.Drawing.Point(569, 33);
            this.txtBhigh.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txtBhigh.Name = "txtBhigh";
            this.txtBhigh.Size = new System.Drawing.Size(98, 20);
            this.txtBhigh.TabIndex = 55;
            this.txtBhigh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(566, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 15);
            this.label12.TabIndex = 54;
            this.label12.Text = "BankNifty High";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // txtstartTimeORB
            // 
            this.txtstartTimeORB.CustomFormat = "HH:mm";
            this.txtstartTimeORB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtstartTimeORB.Location = new System.Drawing.Point(11, 36);
            this.txtstartTimeORB.Name = "txtstartTimeORB";
            this.txtstartTimeORB.ShowUpDown = true;
            this.txtstartTimeORB.Size = new System.Drawing.Size(65, 20);
            this.txtstartTimeORB.TabIndex = 52;
            this.txtstartTimeORB.Value = new System.DateTime(2020, 5, 16, 9, 15, 0, 0);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(8, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 15);
            this.label9.TabIndex = 51;
            this.label9.Text = "Start Time";
            // 
            // btnStartCandleJC
            // 
            this.btnStartCandleJC.Location = new System.Drawing.Point(357, 33);
            this.btnStartCandleJC.Name = "btnStartCandleJC";
            this.btnStartCandleJC.Size = new System.Drawing.Size(87, 23);
            this.btnStartCandleJC.TabIndex = 20;
            this.btnStartCandleJC.Text = "Start Strategy";
            this.btnStartCandleJC.UseVisualStyleBackColor = true;
            this.btnStartCandleJC.Click += new System.EventHandler(this.btnStartCandleJC_Click);
            // 
            // btnAddCandleJC
            // 
            this.btnAddCandleJC.Location = new System.Drawing.Point(264, 33);
            this.btnAddCandleJC.Name = "btnAddCandleJC";
            this.btnAddCandleJC.Size = new System.Drawing.Size(87, 23);
            this.btnAddCandleJC.TabIndex = 15;
            this.btnAddCandleJC.Text = "Browse File";
            this.btnAddCandleJC.UseVisualStyleBackColor = true;
            this.btnAddCandleJC.Click += new System.EventHandler(this.btnAddCandleJC_Click);
            // 
            // txt_SqTimeORB
            // 
            this.txt_SqTimeORB.CustomFormat = "HH:mm";
            this.txt_SqTimeORB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_SqTimeORB.Location = new System.Drawing.Point(86, 36);
            this.txt_SqTimeORB.Name = "txt_SqTimeORB";
            this.txt_SqTimeORB.ShowUpDown = true;
            this.txt_SqTimeORB.Size = new System.Drawing.Size(65, 20);
            this.txt_SqTimeORB.TabIndex = 2;
            this.txt_SqTimeORB.Value = new System.DateTime(2020, 5, 16, 15, 15, 0, 0);
            // 
            // txt_EndTimeORB
            // 
            this.txt_EndTimeORB.CustomFormat = "HH:mm";
            this.txt_EndTimeORB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_EndTimeORB.Location = new System.Drawing.Point(159, 36);
            this.txt_EndTimeORB.Name = "txt_EndTimeORB";
            this.txt_EndTimeORB.ShowUpDown = true;
            this.txt_EndTimeORB.Size = new System.Drawing.Size(68, 20);
            this.txt_EndTimeORB.TabIndex = 3;
            this.txt_EndTimeORB.Value = new System.DateTime(2020, 5, 16, 15, 30, 0, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(84, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 8;
            this.label10.Text = "SQ Time";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(156, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 15);
            this.label19.TabIndex = 6;
            this.label19.Text = "End Time";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.kryptonPanel10);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.DGV_CandleJC);
            this.splitContainer1.Size = new System.Drawing.Size(1368, 421);
            this.splitContainer1.SplitterDistance = 157;
            this.splitContainer1.TabIndex = 2;
            // 
            // kryptonPanel10
            // 
            this.kryptonPanel10.Controls.Add(this.btnUpdate);
            this.kryptonPanel10.Controls.Add(this.btnDeleteClient);
            this.kryptonPanel10.Controls.Add(this.label25);
            this.kryptonPanel10.Controls.Add(this.txtDeleteClient);
            this.kryptonPanel10.Controls.Add(this.btnDeletescript);
            this.kryptonPanel10.Controls.Add(this.label24);
            this.kryptonPanel10.Controls.Add(this.txtDeleteScript);
            this.kryptonPanel10.Controls.Add(this.btnScript);
            this.kryptonPanel10.Controls.Add(this.label15);
            this.kryptonPanel10.Controls.Add(this.txtScript);
            this.kryptonPanel10.Controls.Add(this.btnLoadClientwise);
            this.kryptonPanel10.Controls.Add(this.label14);
            this.kryptonPanel10.Controls.Add(this.txtSClientSelect);
            this.kryptonPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel10.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel10.Name = "kryptonPanel10";
            this.kryptonPanel10.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel10.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.kryptonPanel10.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.SeparatorHighProfile;
            this.kryptonPanel10.Size = new System.Drawing.Size(157, 421);
            this.kryptonPanel10.TabIndex = 150;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(9, 57);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnUpdate.Size = new System.Drawing.Size(22, 24);
            this.btnUpdate.TabIndex = 295;
            this.btnUpdate.Values.Text = "Update";
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDeleteClient
            // 
            this.btnDeleteClient.Location = new System.Drawing.Point(55, 333);
            this.btnDeleteClient.Name = "btnDeleteClient";
            this.btnDeleteClient.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnDeleteClient.Size = new System.Drawing.Size(94, 24);
            this.btnDeleteClient.TabIndex = 200;
            this.btnDeleteClient.Values.Text = "Delete";
            this.btnDeleteClient.Click += new System.EventHandler(this.btnDeleteClient_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(10, 279);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 15);
            this.label25.TabIndex = 294;
            this.label25.Text = "Delete Client";
            // 
            // txtDeleteClient
            // 
            this.txtDeleteClient.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDeleteClient.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtDeleteClient.DropDownWidth = 67;
            this.txtDeleteClient.Items.AddRange(new object[] {
            "ALL"});
            this.txtDeleteClient.Location = new System.Drawing.Point(11, 297);
            this.txtDeleteClient.Name = "txtDeleteClient";
            this.txtDeleteClient.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtDeleteClient.Size = new System.Drawing.Size(137, 21);
            this.txtDeleteClient.TabIndex = 195;
            // 
            // btnDeletescript
            // 
            this.btnDeletescript.Location = new System.Drawing.Point(55, 240);
            this.btnDeletescript.Name = "btnDeletescript";
            this.btnDeletescript.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnDeletescript.Size = new System.Drawing.Size(94, 24);
            this.btnDeletescript.TabIndex = 190;
            this.btnDeletescript.Values.Text = "Delete";
            this.btnDeletescript.Click += new System.EventHandler(this.btnDeletescript_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(10, 185);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 15);
            this.label24.TabIndex = 291;
            this.label24.Text = "Delete Script";
            // 
            // txtDeleteScript
            // 
            this.txtDeleteScript.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDeleteScript.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtDeleteScript.DropDownWidth = 67;
            this.txtDeleteScript.Items.AddRange(new object[] {
            "ALL"});
            this.txtDeleteScript.Location = new System.Drawing.Point(12, 203);
            this.txtDeleteScript.Name = "txtDeleteScript";
            this.txtDeleteScript.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtDeleteScript.Size = new System.Drawing.Size(137, 21);
            this.txtDeleteScript.TabIndex = 185;
            // 
            // btnScript
            // 
            this.btnScript.Location = new System.Drawing.Point(55, 143);
            this.btnScript.Name = "btnScript";
            this.btnScript.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnScript.Size = new System.Drawing.Size(94, 24);
            this.btnScript.TabIndex = 180;
            this.btnScript.Values.Text = "Load";
            this.btnScript.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(10, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 15);
            this.label15.TabIndex = 28;
            this.label15.Text = "Select Script";
            // 
            // txtScript
            // 
            this.txtScript.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtScript.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtScript.DropDownWidth = 67;
            this.txtScript.Items.AddRange(new object[] {
            "ALL"});
            this.txtScript.Location = new System.Drawing.Point(12, 116);
            this.txtScript.Name = "txtScript";
            this.txtScript.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtScript.Size = new System.Drawing.Size(137, 21);
            this.txtScript.TabIndex = 175;
            // 
            // btnLoadClientwise
            // 
            this.btnLoadClientwise.Location = new System.Drawing.Point(55, 57);
            this.btnLoadClientwise.Name = "btnLoadClientwise";
            this.btnLoadClientwise.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnLoadClientwise.Size = new System.Drawing.Size(93, 24);
            this.btnLoadClientwise.TabIndex = 170;
            this.btnLoadClientwise.Values.Text = "Load";
            this.btnLoadClientwise.Click += new System.EventHandler(this.btnLoadClientwise_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(10, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 15);
            this.label14.TabIndex = 25;
            this.label14.Text = "Select Client";
            // 
            // txtSClientSelect
            // 
            this.txtSClientSelect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtSClientSelect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtSClientSelect.DropDownWidth = 67;
            this.txtSClientSelect.Items.AddRange(new object[] {
            "ALL"});
            this.txtSClientSelect.Location = new System.Drawing.Point(11, 30);
            this.txtSClientSelect.Name = "txtSClientSelect";
            this.txtSClientSelect.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtSClientSelect.Size = new System.Drawing.Size(138, 21);
            this.txtSClientSelect.TabIndex = 165;
            // 
            // DGV_CandleJC
            // 
            this.DGV_CandleJC.AllowUserToAddRows = false;
            this.DGV_CandleJC.AllowUserToDeleteRows = false;
            this.DGV_CandleJC.ColumnHeadersHeight = 20;
            this.DGV_CandleJC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_CandleJC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.o_sid,
            this.col_start,
            this.col_duration,
            this.col_acc,
            this.o_EntryC,
            this.col_Trail,
            this.o_status,
            this.o_token,
            this.o_symbol,
            this.o_symbolltp,
            this.o_high,
            this.o_open,
            this.o_low,
            this.o_quantity,
            this.o_targetPrice,
            this.o_stoplossPrice,
            this.o_PL,
            this.col_EndTime});
            this.DGV_CandleJC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_CandleJC.Location = new System.Drawing.Point(0, 0);
            this.DGV_CandleJC.MultiSelect = false;
            this.DGV_CandleJC.Name = "DGV_CandleJC";
            this.DGV_CandleJC.ReadOnly = true;
            this.DGV_CandleJC.RowHeadersVisible = false;
            this.DGV_CandleJC.RowHeadersWidth = 20;
            this.DGV_CandleJC.Size = new System.Drawing.Size(1207, 421);
            this.DGV_CandleJC.StateCommon.BackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.GridBackgroundList;
            this.DGV_CandleJC.StateCommon.HeaderColumn.Content.TextH = ComponentFactory.Krypton.Toolkit.PaletteRelativeAlign.Center;
            this.DGV_CandleJC.StateCommon.HeaderColumn.Content.TextV = ComponentFactory.Krypton.Toolkit.PaletteRelativeAlign.Center;
            this.DGV_CandleJC.TabIndex = 30;
            this.DGV_CandleJC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_CandleJC_CellContentClick);
            this.DGV_CandleJC.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DGV_CandleJC_MouseClick);
            // 
            // o_sid
            // 
            this.o_sid.HeaderText = "Sid";
            this.o_sid.Name = "o_sid";
            this.o_sid.ReadOnly = true;
            // 
            // col_start
            // 
            this.col_start.HeaderText = "Start Time";
            this.col_start.Name = "col_start";
            this.col_start.ReadOnly = true;
            // 
            // col_duration
            // 
            this.col_duration.HeaderText = "Duration";
            this.col_duration.Name = "col_duration";
            this.col_duration.ReadOnly = true;
            // 
            // col_acc
            // 
            this.col_acc.HeaderText = "Account";
            this.col_acc.Name = "col_acc";
            this.col_acc.ReadOnly = true;
            // 
            // o_EntryC
            // 
            this.o_EntryC.HeaderText = "Entry Count";
            this.o_EntryC.Name = "o_EntryC";
            this.o_EntryC.ReadOnly = true;
            // 
            // col_Trail
            // 
            this.col_Trail.HeaderText = "Trail Count";
            this.col_Trail.Name = "col_Trail";
            this.col_Trail.ReadOnly = true;
            // 
            // o_status
            // 
            this.o_status.HeaderText = "Status";
            this.o_status.Name = "o_status";
            this.o_status.ReadOnly = true;
            // 
            // o_token
            // 
            this.o_token.HeaderText = "Token";
            this.o_token.Name = "o_token";
            this.o_token.ReadOnly = true;
            // 
            // o_symbol
            // 
            this.o_symbol.HeaderText = "Symbol";
            this.o_symbol.Name = "o_symbol";
            this.o_symbol.ReadOnly = true;
            // 
            // o_symbolltp
            // 
            this.o_symbolltp.HeaderText = "Ltp";
            this.o_symbolltp.Name = "o_symbolltp";
            this.o_symbolltp.ReadOnly = true;
            // 
            // o_high
            // 
            this.o_high.HeaderText = "High";
            this.o_high.Name = "o_high";
            this.o_high.ReadOnly = true;
            // 
            // o_open
            // 
            this.o_open.HeaderText = "Open";
            this.o_open.Name = "o_open";
            this.o_open.ReadOnly = true;
            // 
            // o_low
            // 
            this.o_low.HeaderText = "Low";
            this.o_low.Name = "o_low";
            this.o_low.ReadOnly = true;
            // 
            // o_quantity
            // 
            this.o_quantity.HeaderText = "Quantity";
            this.o_quantity.Name = "o_quantity";
            this.o_quantity.ReadOnly = true;
            // 
            // o_targetPrice
            // 
            this.o_targetPrice.HeaderText = "TargetPrice";
            this.o_targetPrice.Name = "o_targetPrice";
            this.o_targetPrice.ReadOnly = true;
            // 
            // o_stoplossPrice
            // 
            this.o_stoplossPrice.HeaderText = "Stoploss";
            this.o_stoplossPrice.Name = "o_stoplossPrice";
            this.o_stoplossPrice.ReadOnly = true;
            // 
            // o_PL
            // 
            this.o_PL.HeaderText = "PL";
            this.o_PL.Name = "o_PL";
            this.o_PL.ReadOnly = true;
            this.o_PL.Visible = false;
            // 
            // col_EndTime
            // 
            this.col_EndTime.HeaderText = "EndTime";
            this.col_EndTime.Name = "col_EndTime";
            this.col_EndTime.ReadOnly = true;
            // 
            // txtCurrentPLORB
            // 
            this.txtCurrentPLORB.AutoSize = true;
            this.txtCurrentPLORB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentPLORB.Location = new System.Drawing.Point(1047, 29);
            this.txtCurrentPLORB.Name = "txtCurrentPLORB";
            this.txtCurrentPLORB.Size = new System.Drawing.Size(14, 15);
            this.txtCurrentPLORB.TabIndex = 49;
            this.txtCurrentPLORB.Text = "0";
            this.txtCurrentPLORB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtCurrentPLORB.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(976, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 15);
            this.label21.TabIndex = 48;
            this.label21.Text = "Current PL";
            this.label21.Visible = false;
            // 
            // txtstoplossCandleJC
            // 
            this.txtstoplossCandleJC.Location = new System.Drawing.Point(1189, 28);
            this.txtstoplossCandleJC.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txtstoplossCandleJC.Name = "txtstoplossCandleJC";
            this.txtstoplossCandleJC.Size = new System.Drawing.Size(107, 20);
            this.txtstoplossCandleJC.TabIndex = 44;
            this.txtstoplossCandleJC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtstoplossCandleJC.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1186, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 15);
            this.label11.TabIndex = 43;
            this.label11.Text = "Stoploss";
            this.label11.Visible = false;
            // 
            // txttargetCandleJC
            // 
            this.txttargetCandleJC.Location = new System.Drawing.Point(1076, 28);
            this.txttargetCandleJC.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.txttargetCandleJC.Name = "txttargetCandleJC";
            this.txttargetCandleJC.Size = new System.Drawing.Size(107, 20);
            this.txttargetCandleJC.TabIndex = 42;
            this.txttargetCandleJC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txttargetCandleJC.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1073, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 41;
            this.label7.Text = "Target";
            this.label7.Visible = false;
            // 
            // ContextMenuStrip1
            // 
            this.ContextMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddStrategyToolStripMenuItem});
            this.ContextMenuStrip1.Name = "ContextMenuStrip1";
            this.ContextMenuStrip1.Size = new System.Drawing.Size(195, 26);
            // 
            // AddStrategyToolStripMenuItem
            // 
            this.AddStrategyToolStripMenuItem.Name = "AddStrategyToolStripMenuItem";
            this.AddStrategyToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.AddStrategyToolStripMenuItem.Text = "Add Strategy (Ctrl + A)";
            // 
            // KryptonButton2
            // 
            this.KryptonButton2.Location = new System.Drawing.Point(364, 29);
            this.KryptonButton2.Name = "KryptonButton2";
            this.KryptonButton2.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonButton2.Size = new System.Drawing.Size(67, 24);
            this.KryptonButton2.TabIndex = 30;
            this.KryptonButton2.Values.Text = "Exit ";
            this.KryptonButton2.Click += new System.EventHandler(this.KryptonButton2_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(181, 29);
            this.btnStart.Name = "btnStart";
            this.btnStart.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnStart.Size = new System.Drawing.Size(67, 24);
            this.btnStart.TabIndex = 11;
            this.btnStart.Values.Text = "start";
            this.btnStart.Click += new System.EventHandler(this.KryptonButton1_Click);
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(381, 24);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtAdd.Size = new System.Drawing.Size(46, 24);
            this.txtAdd.TabIndex = 3;
            this.txtAdd.Values.Text = "ADD";
            this.txtAdd.Click += new System.EventHandler(this.KryptonButton4_Click_1);
            // 
            // KryptonINTRUMENT
            // 
            this.KryptonINTRUMENT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.KryptonINTRUMENT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.KryptonINTRUMENT.DropDownWidth = 67;
            this.KryptonINTRUMENT.Items.AddRange(new object[] {
            "AXISBANK",
            "ICICIBANK"});
            this.KryptonINTRUMENT.Location = new System.Drawing.Point(189, 27);
            this.KryptonINTRUMENT.Name = "KryptonINTRUMENT";
            this.KryptonINTRUMENT.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonINTRUMENT.Size = new System.Drawing.Size(179, 21);
            this.KryptonINTRUMENT.TabIndex = 2;
            this.KryptonINTRUMENT.SelectedIndexChanged += new System.EventHandler(this.KryptonINTRUMENT_SelectedIndexChanged);
            // 
            // KryptonSEGMENT
            // 
            this.KryptonSEGMENT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.KryptonSEGMENT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.KryptonSEGMENT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.KryptonSEGMENT.DropDownWidth = 67;
            this.KryptonSEGMENT.Items.AddRange(new object[] {
            "EQ"});
            this.KryptonSEGMENT.Location = new System.Drawing.Point(93, 27);
            this.KryptonSEGMENT.Name = "KryptonSEGMENT";
            this.KryptonSEGMENT.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonSEGMENT.Size = new System.Drawing.Size(80, 21);
            this.KryptonSEGMENT.TabIndex = 1;
            this.KryptonSEGMENT.SelectedIndexChanged += new System.EventHandler(this.KryptonSEGMENT_SelectedIndexChanged);
            // 
            // KryptonEXCHNAGE
            // 
            this.KryptonEXCHNAGE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.KryptonEXCHNAGE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.KryptonEXCHNAGE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.KryptonEXCHNAGE.DropDownWidth = 67;
            this.KryptonEXCHNAGE.Items.AddRange(new object[] {
            "NSE"});
            this.KryptonEXCHNAGE.Location = new System.Drawing.Point(6, 27);
            this.KryptonEXCHNAGE.Name = "KryptonEXCHNAGE";
            this.KryptonEXCHNAGE.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonEXCHNAGE.Size = new System.Drawing.Size(76, 21);
            this.KryptonEXCHNAGE.TabIndex = 0;
            this.KryptonEXCHNAGE.SelectedIndexChanged += new System.EventHandler(this.KryptonEXCHNAGE_SelectedIndexChanged);
            // 
            // KryptonPanel5
            // 
            this.KryptonPanel5.Controls.Add(this.btnSendEmail);
            this.KryptonPanel5.Controls.Add(this.kryptonButton3);
            this.KryptonPanel5.Controls.Add(this.label22);
            this.KryptonPanel5.Controls.Add(this.label8);
            this.KryptonPanel5.Controls.Add(this.btnSubscribe);
            this.KryptonPanel5.Controls.Add(this.txtClientCount);
            this.KryptonPanel5.Controls.Add(this.label18);
            this.KryptonPanel5.Controls.Add(this.label11);
            this.KryptonPanel5.Controls.Add(this.txtstoplossCandleJC);
            this.KryptonPanel5.Controls.Add(this.txtCurrentPLORB);
            this.KryptonPanel5.Controls.Add(this.kryptonButton5);
            this.KryptonPanel5.Controls.Add(this.label7);
            this.KryptonPanel5.Controls.Add(this.txttargetCandleJC);
            this.KryptonPanel5.Controls.Add(this.label21);
            this.KryptonPanel5.Controls.Add(this.label3);
            this.KryptonPanel5.Controls.Add(this.label1);
            this.KryptonPanel5.Controls.Add(this.KryptonButton2);
            this.KryptonPanel5.Controls.Add(this.btnStart);
            this.KryptonPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.KryptonPanel5.Location = new System.Drawing.Point(0, 0);
            this.KryptonPanel5.Name = "KryptonPanel5";
            this.KryptonPanel5.Padding = new System.Windows.Forms.Padding(3);
            this.KryptonPanel5.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalOffice2003;
            this.KryptonPanel5.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderCustom2;
            this.KryptonPanel5.Size = new System.Drawing.Size(1370, 66);
            this.KryptonPanel5.TabIndex = 32;
            this.KryptonPanel5.Paint += new System.Windows.Forms.PaintEventHandler(this.KryptonPanel5_Paint);
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Location = new System.Drawing.Point(806, 28);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnSendEmail.Size = new System.Drawing.Size(104, 24);
            this.btnSendEmail.TabIndex = 52;
            this.btnSendEmail.Values.Text = "Send Email";
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // kryptonButton3
            // 
            this.kryptonButton3.Location = new System.Drawing.Point(85, 28);
            this.kryptonButton3.Name = "kryptonButton3";
            this.kryptonButton3.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.kryptonButton3.Size = new System.Drawing.Size(67, 24);
            this.kryptonButton3.TabIndex = 50;
            this.kryptonButton3.Values.Text = "Browse";
            this.kryptonButton3.Click += new System.EventHandler(this.kryptonButton3_Click_2);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(84, 9);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 15);
            this.label22.TabIndex = 51;
            this.label22.Text = "New Login";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(677, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 15);
            this.label8.TabIndex = 33;
            this.label8.Text = "Feed Subscribe";
            // 
            // btnSubscribe
            // 
            this.btnSubscribe.Location = new System.Drawing.Point(680, 28);
            this.btnSubscribe.Name = "btnSubscribe";
            this.btnSubscribe.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.btnSubscribe.Size = new System.Drawing.Size(104, 24);
            this.btnSubscribe.TabIndex = 32;
            this.btnSubscribe.Values.Text = "Subscribe";
            this.btnSubscribe.Click += new System.EventHandler(this.btnSubscribe_Click);
            // 
            // txtClientCount
            // 
            this.txtClientCount.AutoSize = true;
            this.txtClientCount.BackColor = System.Drawing.Color.Transparent;
            this.txtClientCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClientCount.Location = new System.Drawing.Point(543, 29);
            this.txtClientCount.Name = "txtClientCount";
            this.txtClientCount.Size = new System.Drawing.Size(15, 15);
            this.txtClientCount.TabIndex = 31;
            this.txtClientCount.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(178, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 15);
            this.label18.TabIndex = 12;
            this.label18.Text = "Start";
            // 
            // kryptonButton5
            // 
            this.kryptonButton5.Location = new System.Drawing.Point(12, 29);
            this.kryptonButton5.Name = "kryptonButton5";
            this.kryptonButton5.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.kryptonButton5.Size = new System.Drawing.Size(67, 24);
            this.kryptonButton5.TabIndex = 0;
            this.kryptonButton5.Values.Text = "Browse";
            this.kryptonButton5.Click += new System.EventHandler(this.kryptonButton5_Click_2);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(361, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Exit Application";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Old Login";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Cornsilk;
            this.label6.Location = new System.Drawing.Point(186, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Script";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Cornsilk;
            this.label5.Location = new System.Drawing.Point(90, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Option Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Cornsilk;
            this.label4.Location = new System.Drawing.Point(5, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Exchange";
            // 
            // KryptonContextMenuOrderBook
            // 
            this.KryptonContextMenuOrderBook.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems13});
            // 
            // kryptonContextMenuItems13
            // 
            this.kryptonContextMenuItems13.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.SimpleToolStripMenuItem,
            this.OCOToolStripMenuItem,
            this.COToolStripMenuItem,
            this.ExportOrderBookMenuItem});
            // 
            // SimpleToolStripMenuItem
            // 
            this.SimpleToolStripMenuItem.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems14});
            this.SimpleToolStripMenuItem.Text = "Simple";
            // 
            // kryptonContextMenuItems14
            // 
            this.kryptonContextMenuItems14.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.ModifyToolStripMenuItem,
            this.CancelToolStripMenuItem});
            // 
            // ModifyToolStripMenuItem
            // 
            this.ModifyToolStripMenuItem.Text = "Modify";
            // 
            // CancelToolStripMenuItem
            // 
            this.CancelToolStripMenuItem.Text = "Cancel";
            // 
            // OCOToolStripMenuItem
            // 
            this.OCOToolStripMenuItem.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems15});
            this.OCOToolStripMenuItem.Text = "OCO";
            // 
            // kryptonContextMenuItems15
            // 
            this.kryptonContextMenuItems15.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.ModifyEntryToolStripMenuItem,
            this.CancelEntryOrderToolStripMenuItem,
            this.ModifyTargetToolStripMenuItem,
            this.ModifyStoplossToolStripMenuItem,
            this.ExitToolStripMenuItem});
            // 
            // ModifyEntryToolStripMenuItem
            // 
            this.ModifyEntryToolStripMenuItem.Text = "Modify Entry";
            // 
            // CancelEntryOrderToolStripMenuItem
            // 
            this.CancelEntryOrderToolStripMenuItem.Text = "Cancel Entry";
            // 
            // ModifyTargetToolStripMenuItem
            // 
            this.ModifyTargetToolStripMenuItem.Text = "Modify Target";
            // 
            // ModifyStoplossToolStripMenuItem
            // 
            this.ModifyStoplossToolStripMenuItem.Text = "Modify Stoploss";
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Text = "Exit Position";
            // 
            // COToolStripMenuItem
            // 
            this.COToolStripMenuItem.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems16});
            this.COToolStripMenuItem.Text = "CO";
            // 
            // kryptonContextMenuItems16
            // 
            this.kryptonContextMenuItems16.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.CancelEntryToolStripMenuItem,
            this.ModifyStoplossToolStripMenuItem1,
            this.ExitToolStripMenuItem1});
            // 
            // CancelEntryToolStripMenuItem
            // 
            this.CancelEntryToolStripMenuItem.Text = "Cancel Entry";
            // 
            // ModifyStoplossToolStripMenuItem1
            // 
            this.ModifyStoplossToolStripMenuItem1.Text = "Modify Stoploss";
            // 
            // ExitToolStripMenuItem1
            // 
            this.ExitToolStripMenuItem1.Text = "Exit Position";
            // 
            // ExportOrderBookMenuItem
            // 
            this.ExportOrderBookMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ExportOrderBookMenuItem.Image")));
            this.ExportOrderBookMenuItem.Text = "Export";
            // 
            // KryptonContextMenuMarketWatch
            // 
            this.KryptonContextMenuMarketWatch.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems17});
            // 
            // kryptonContextMenuItems17
            // 
            this.kryptonContextMenuItems17.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.KryptonContextMenuItem2,
            this.KryptonContextMenuItem3,
            this.KryptonContextMenuItem4});
            // 
            // KryptonContextMenuItem2
            // 
            this.KryptonContextMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem2.Image")));
            this.KryptonContextMenuItem2.Text = "Buy";
            // 
            // KryptonContextMenuItem3
            // 
            this.KryptonContextMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem3.Image")));
            this.KryptonContextMenuItem3.Text = "Sell";
            // 
            // KryptonContextMenuItem4
            // 
            this.KryptonContextMenuItem4.Image = ((System.Drawing.Image)(resources.GetObject("KryptonContextMenuItem4.Image")));
            this.KryptonContextMenuItem4.Text = "Export";
            // 
            // KryptonPage2
            // 
            this.KryptonPage2.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage2.Flags = 65534;
            this.KryptonPage2.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage2.ImageSmall")));
            this.KryptonPage2.KryptonContextMenu = this.KryptonContextMenuOrderBook;
            this.KryptonPage2.LastVisibleSet = true;
            this.KryptonPage2.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage2.Name = "KryptonPage2";
            this.KryptonPage2.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage2.Text = "Order Book";
            this.KryptonPage2.ToolTipTitle = "Page ToolTip";
            this.KryptonPage2.UniqueName = "4842924DA2D14EC7B483C7C2593C1DB9";
            // 
            // KryptonPendingOB
            // 
            this.KryptonPendingOB.AllowUserToAddRows = false;
            this.KryptonPendingOB.AllowUserToDeleteRows = false;
            this.KryptonPendingOB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonPendingOB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.T_Symbol,
            this.T_Side,
            this.T_Type,
            this.T_Qty,
            this.T_Price,
            this.T_Time,
            this.T_Status,
            this.T_OMS});
            this.KryptonPendingOB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonPendingOB.Location = new System.Drawing.Point(0, 0);
            this.KryptonPendingOB.Name = "KryptonPendingOB";
            this.KryptonPendingOB.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.KryptonPendingOB.ReadOnly = true;
            this.KryptonPendingOB.RowHeadersVisible = false;
            this.KryptonPendingOB.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.KryptonPendingOB.Size = new System.Drawing.Size(1368, 517);
            this.KryptonPendingOB.TabIndex = 20;
            this.KryptonPendingOB.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KryptonPendingOB_CellContentClick);
            // 
            // T_Symbol
            // 
            this.T_Symbol.HeaderText = "Symbol";
            this.T_Symbol.Name = "T_Symbol";
            this.T_Symbol.ReadOnly = true;
            // 
            // T_Side
            // 
            this.T_Side.HeaderText = "Side";
            this.T_Side.Name = "T_Side";
            this.T_Side.ReadOnly = true;
            // 
            // T_Type
            // 
            this.T_Type.HeaderText = "Type";
            this.T_Type.Name = "T_Type";
            this.T_Type.ReadOnly = true;
            // 
            // T_Qty
            // 
            this.T_Qty.HeaderText = "Qty";
            this.T_Qty.Name = "T_Qty";
            this.T_Qty.ReadOnly = true;
            // 
            // T_Price
            // 
            this.T_Price.HeaderText = "Price";
            this.T_Price.Name = "T_Price";
            this.T_Price.ReadOnly = true;
            // 
            // T_Time
            // 
            this.T_Time.HeaderText = "Time";
            this.T_Time.Name = "T_Time";
            this.T_Time.ReadOnly = true;
            // 
            // T_Status
            // 
            this.T_Status.HeaderText = "Status";
            this.T_Status.Name = "T_Status";
            this.T_Status.ReadOnly = true;
            // 
            // T_OMS
            // 
            this.T_OMS.HeaderText = "OMS ID";
            this.T_OMS.Name = "T_OMS";
            this.T_OMS.ReadOnly = true;
            // 
            // KryptonPanel2
            // 
            this.KryptonPanel2.Controls.Add(this.KryptonPanel1);
            this.KryptonPanel2.Controls.Add(this.KryptonRichConfirmationPanel);
            this.KryptonPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.KryptonPanel2.Location = new System.Drawing.Point(0, 614);
            this.KryptonPanel2.Name = "KryptonPanel2";
            this.KryptonPanel2.Padding = new System.Windows.Forms.Padding(3);
            this.KryptonPanel2.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonPanel2.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.KryptonPanel2.Size = new System.Drawing.Size(1370, 135);
            this.KryptonPanel2.TabIndex = 29;
            // 
            // KryptonPanel1
            // 
            this.KryptonPanel1.Controls.Add(this.label17);
            this.KryptonPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.KryptonPanel1.Location = new System.Drawing.Point(3, 102);
            this.KryptonPanel1.Name = "KryptonPanel1";
            this.KryptonPanel1.Padding = new System.Windows.Forms.Padding(3);
            this.KryptonPanel1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.KryptonPanel1.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.KryptonPanel1.Size = new System.Drawing.Size(1364, 30);
            this.KryptonPanel1.TabIndex = 29;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.Lime;
            this.label17.Location = new System.Drawing.Point(1249, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "8.6 Version Live";
            // 
            // KryptonRichConfirmationPanel
            // 
            this.KryptonRichConfirmationPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonRichConfirmationPanel.Location = new System.Drawing.Point(3, 3);
            this.KryptonRichConfirmationPanel.Name = "KryptonRichConfirmationPanel";
            this.KryptonRichConfirmationPanel.ReadOnly = true;
            this.KryptonRichConfirmationPanel.Size = new System.Drawing.Size(1364, 129);
            this.KryptonRichConfirmationPanel.StateCommon.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.KryptonRichConfirmationPanel.TabIndex = 2500;
            this.KryptonRichConfirmationPanel.Text = "Welcome To Master REST API";
            // 
            // KryptonPanel3
            // 
            this.KryptonPanel3.Controls.Add(this.KryptonDockableNavigator1);
            this.KryptonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonPanel3.Location = new System.Drawing.Point(0, 0);
            this.KryptonPanel3.Name = "KryptonPanel3";
            this.KryptonPanel3.Padding = new System.Windows.Forms.Padding(3);
            this.KryptonPanel3.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.KryptonPanel3.Size = new System.Drawing.Size(1370, 749);
            this.KryptonPanel3.TabIndex = 30;
            // 
            // KryptonDockableNavigator1
            // 
            this.KryptonDockableNavigator1.AllowPageReorder = false;
            this.KryptonDockableNavigator1.Bar.ItemSizing = ComponentFactory.Krypton.Navigator.BarItemSizing.SameWidthAndHeight;
            this.KryptonDockableNavigator1.Button.CloseButtonAction = ComponentFactory.Krypton.Navigator.CloseButtonAction.None;
            this.KryptonDockableNavigator1.Button.CloseButtonDisplay = ComponentFactory.Krypton.Navigator.ButtonDisplay.Hide;
            this.KryptonDockableNavigator1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDockableNavigator1.Location = new System.Drawing.Point(3, 3);
            this.KryptonDockableNavigator1.Name = "KryptonDockableNavigator1";
            this.KryptonDockableNavigator1.Pages.AddRange(new ComponentFactory.Krypton.Navigator.KryptonPage[] {
            this.KryptonPage1,
            this.KryptonPage2,
            this.KryptonPage9,
            this.KryptonPage3,
            this.KryptonPage4,
            this.KryptonPage5,
            this.KryptonPage6,
            this.OptionPage});
            this.KryptonDockableNavigator1.SelectedIndex = 7;
            this.KryptonDockableNavigator1.Size = new System.Drawing.Size(1364, 743);
            this.KryptonDockableNavigator1.TabIndex = 0;
            this.KryptonDockableNavigator1.Text = "KryptonDockableNavigator1";
            // 
            // KryptonPage1
            // 
            this.KryptonPage1.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage1.Flags = 65534;
            this.KryptonPage1.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage1.ImageSmall")));
            this.KryptonPage1.KryptonContextMenu = this.KryptonContextMenuMarketWatch;
            this.KryptonPage1.LastVisibleSet = true;
            this.KryptonPage1.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage1.Name = "KryptonPage1";
            this.KryptonPage1.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage1.Text = "Market Watch";
            this.KryptonPage1.ToolTipTitle = "Page ToolTip";
            this.KryptonPage1.UniqueName = "D4E80BFB45E540864DAD9CD84BB101AE";
            // 
            // KryptonPage9
            // 
            this.KryptonPage9.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage9.Flags = 65534;
            this.KryptonPage9.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage9.ImageSmall")));
            this.KryptonPage9.KryptonContextMenu = this.KryptonContextMenuCommon;
            this.KryptonPage9.LastVisibleSet = true;
            this.KryptonPage9.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage9.Name = "KryptonPage9";
            this.KryptonPage9.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage9.Text = "Trade Book";
            this.KryptonPage9.ToolTipTitle = "Page ToolTip";
            this.KryptonPage9.UniqueName = "96713E1B817041D2F88BEF5B1D475E3B";
            // 
            // KryptonPage3
            // 
            this.KryptonPage3.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage3.Flags = 65534;
            this.KryptonPage3.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage3.ImageSmall")));
            this.KryptonPage3.KryptonContextMenu = this.KryptonContextMenuPositions;
            this.KryptonPage3.LastVisibleSet = true;
            this.KryptonPage3.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage3.Name = "KryptonPage3";
            this.KryptonPage3.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage3.Text = "Positions";
            this.KryptonPage3.ToolTipTitle = "Page ToolTip";
            this.KryptonPage3.UniqueName = "FF0391ADAAC342FA21BEA0E9395EFEE0";
            // 
            // KryptonContextMenuPositions
            // 
            this.KryptonContextMenuPositions.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.kryptonContextMenuItems18});
            // 
            // kryptonContextMenuItems18
            // 
            this.kryptonContextMenuItems18.Items.AddRange(new ComponentFactory.Krypton.Toolkit.KryptonContextMenuItemBase[] {
            this.ExitPositionToolStripMenuItem,
            this.ExportPositionsMenuItem});
            // 
            // ExitPositionToolStripMenuItem
            // 
            this.ExitPositionToolStripMenuItem.Text = "Exit Position";
            // 
            // ExportPositionsMenuItem
            // 
            this.ExportPositionsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ExportPositionsMenuItem.Image")));
            this.ExportPositionsMenuItem.Text = "Export";
            // 
            // KryptonPage4
            // 
            this.KryptonPage4.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage4.Flags = 65534;
            this.KryptonPage4.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage4.ImageSmall")));
            this.KryptonPage4.KryptonContextMenu = this.KryptonContextMenuCommon;
            this.KryptonPage4.LastVisibleSet = true;
            this.KryptonPage4.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage4.Name = "KryptonPage4";
            this.KryptonPage4.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage4.Text = "Holdings";
            this.KryptonPage4.ToolTipTitle = "Page ToolTip";
            this.KryptonPage4.UniqueName = "0A401C869D8341727F81532CE58E4713";
            // 
            // KryptonPage5
            // 
            this.KryptonPage5.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage5.Flags = 65534;
            this.KryptonPage5.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage5.ImageSmall")));
            this.KryptonPage5.KryptonContextMenu = this.KryptonContextMenuCommon;
            this.KryptonPage5.LastVisibleSet = true;
            this.KryptonPage5.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage5.Name = "KryptonPage5";
            this.KryptonPage5.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage5.Text = "Funds";
            this.KryptonPage5.ToolTipTitle = "Page ToolTip";
            this.KryptonPage5.UniqueName = "AF541D9A07C24668FC85226081D9B21D";
            // 
            // KryptonPage6
            // 
            this.KryptonPage6.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.KryptonPage6.Flags = 65534;
            this.KryptonPage6.ImageSmall = ((System.Drawing.Image)(resources.GetObject("KryptonPage6.ImageSmall")));
            this.KryptonPage6.LastVisibleSet = true;
            this.KryptonPage6.MinimumSize = new System.Drawing.Size(50, 50);
            this.KryptonPage6.Name = "KryptonPage6";
            this.KryptonPage6.Size = new System.Drawing.Size(906, 223);
            this.KryptonPage6.Text = "Bridge";
            this.KryptonPage6.ToolTipTitle = "Page ToolTip";
            this.KryptonPage6.UniqueName = "135D60B4E97249744293DB5BD1E96025";
            // 
            // KryptonMarketWatch
            // 
            this.KryptonMarketWatch.AllowUserToAddRows = false;
            this.KryptonMarketWatch.AllowUserToDeleteRows = false;
            this.KryptonMarketWatch.ColumnHeadersHeight = 20;
            this.KryptonMarketWatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.KryptonMarketWatch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.V_Token,
            this.V_Exe,
            this.V_Sym,
            this.V_LTP,
            this.V_Ltq,
            this.V_Bid,
            this.V_BidQ,
            this.V_Ask,
            this.V_AskQ,
            this.V_Open,
            this.V_High,
            this.V_Low,
            this.V_Close,
            this.V_Atp,
            this.V_Volumn,
            this.V_LastUTime,
            this.V_LastTTime});
            this.KryptonMarketWatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonMarketWatch.Location = new System.Drawing.Point(0, 0);
            this.KryptonMarketWatch.MultiSelect = false;
            this.KryptonMarketWatch.Name = "KryptonMarketWatch";
            this.KryptonMarketWatch.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.KryptonMarketWatch.ReadOnly = true;
            this.KryptonMarketWatch.RowHeadersVisible = false;
            this.KryptonMarketWatch.RowHeadersWidth = 20;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
            this.KryptonMarketWatch.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.KryptonMarketWatch.Size = new System.Drawing.Size(1368, 517);
            this.KryptonMarketWatch.StateCommon.BackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.GridBackgroundList;
            this.KryptonMarketWatch.StateCommon.HeaderColumn.Content.TextH = ComponentFactory.Krypton.Toolkit.PaletteRelativeAlign.Center;
            this.KryptonMarketWatch.StateCommon.HeaderColumn.Content.TextV = ComponentFactory.Krypton.Toolkit.PaletteRelativeAlign.Center;
            this.KryptonMarketWatch.TabIndex = 13;
            this.KryptonMarketWatch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KryptonDataGridView1_CellContentClick);
            // 
            // V_Token
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.V_Token.DefaultCellStyle = dataGridViewCellStyle1;
            this.V_Token.HeaderText = "Intrument Token";
            this.V_Token.Name = "V_Token";
            this.V_Token.ReadOnly = true;
            // 
            // V_Exe
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.V_Exe.DefaultCellStyle = dataGridViewCellStyle2;
            this.V_Exe.HeaderText = "Exchange";
            this.V_Exe.Name = "V_Exe";
            this.V_Exe.ReadOnly = true;
            // 
            // V_Sym
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.V_Sym.DefaultCellStyle = dataGridViewCellStyle3;
            this.V_Sym.HeaderText = "Symbol";
            this.V_Sym.Name = "V_Sym";
            this.V_Sym.ReadOnly = true;
            // 
            // V_LTP
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_LTP.DefaultCellStyle = dataGridViewCellStyle4;
            this.V_LTP.HeaderText = "LTP";
            this.V_LTP.Name = "V_LTP";
            this.V_LTP.ReadOnly = true;
            this.V_LTP.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // V_Ltq
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Ltq.DefaultCellStyle = dataGridViewCellStyle5;
            this.V_Ltq.HeaderText = "LTQ";
            this.V_Ltq.Name = "V_Ltq";
            this.V_Ltq.ReadOnly = true;
            // 
            // V_Bid
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Bid.DefaultCellStyle = dataGridViewCellStyle6;
            this.V_Bid.HeaderText = "Bid";
            this.V_Bid.Name = "V_Bid";
            this.V_Bid.ReadOnly = true;
            // 
            // V_BidQ
            // 
            this.V_BidQ.HeaderText = "Bid Qty";
            this.V_BidQ.Name = "V_BidQ";
            this.V_BidQ.ReadOnly = true;
            // 
            // V_Ask
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Ask.DefaultCellStyle = dataGridViewCellStyle7;
            this.V_Ask.HeaderText = "Ask";
            this.V_Ask.Name = "V_Ask";
            this.V_Ask.ReadOnly = true;
            // 
            // V_AskQ
            // 
            this.V_AskQ.HeaderText = "Ask Qty";
            this.V_AskQ.Name = "V_AskQ";
            this.V_AskQ.ReadOnly = true;
            // 
            // V_Open
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Open.DefaultCellStyle = dataGridViewCellStyle8;
            this.V_Open.HeaderText = "Open";
            this.V_Open.Name = "V_Open";
            this.V_Open.ReadOnly = true;
            // 
            // V_High
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_High.DefaultCellStyle = dataGridViewCellStyle9;
            this.V_High.HeaderText = "High";
            this.V_High.Name = "V_High";
            this.V_High.ReadOnly = true;
            // 
            // V_Low
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Low.DefaultCellStyle = dataGridViewCellStyle10;
            this.V_Low.HeaderText = "Low";
            this.V_Low.Name = "V_Low";
            this.V_Low.ReadOnly = true;
            // 
            // V_Close
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Close.DefaultCellStyle = dataGridViewCellStyle11;
            this.V_Close.HeaderText = "Close";
            this.V_Close.Name = "V_Close";
            this.V_Close.ReadOnly = true;
            // 
            // V_Atp
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Atp.DefaultCellStyle = dataGridViewCellStyle12;
            this.V_Atp.HeaderText = "ATP";
            this.V_Atp.Name = "V_Atp";
            this.V_Atp.ReadOnly = true;
            // 
            // V_Volumn
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.V_Volumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.V_Volumn.HeaderText = "Volumn";
            this.V_Volumn.Name = "V_Volumn";
            this.V_Volumn.ReadOnly = true;
            // 
            // V_LastUTime
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.V_LastUTime.DefaultCellStyle = dataGridViewCellStyle14;
            this.V_LastUTime.HeaderText = "LAST UPDATE TIME";
            this.V_LastUTime.Name = "V_LastUTime";
            this.V_LastUTime.ReadOnly = true;
            // 
            // V_LastTTime
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.V_LastTTime.DefaultCellStyle = dataGridViewCellStyle15;
            this.V_LastTTime.HeaderText = "LAST TRADE TIME";
            this.V_LastTTime.Name = "V_LastTTime";
            this.V_LastTTime.ReadOnly = true;
            // 
            // KryptonTradeBook
            // 
            this.KryptonTradeBook.AllowUserToAddRows = false;
            this.KryptonTradeBook.AllowUserToDeleteRows = false;
            this.KryptonTradeBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonTradeBook.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.T_Sym,
            this.T_Si,
            this.T_Ty,
            this.T_Qt,
            this.T_Pri,
            this.col_Ti,
            this.T_Statu,
            this.T_OMSO});
            this.KryptonTradeBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonTradeBook.Location = new System.Drawing.Point(0, 0);
            this.KryptonTradeBook.Name = "KryptonTradeBook";
            this.KryptonTradeBook.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.KryptonTradeBook.ReadOnly = true;
            this.KryptonTradeBook.RowHeadersVisible = false;
            this.KryptonTradeBook.Size = new System.Drawing.Size(1368, 517);
            this.KryptonTradeBook.TabIndex = 23;
            this.KryptonTradeBook.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KryptonTradeBook_CellContentClick);
            // 
            // T_Sym
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            this.T_Sym.DefaultCellStyle = dataGridViewCellStyle17;
            this.T_Sym.HeaderText = "Symbol";
            this.T_Sym.Name = "T_Sym";
            this.T_Sym.ReadOnly = true;
            // 
            // T_Si
            // 
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            this.T_Si.DefaultCellStyle = dataGridViewCellStyle18;
            this.T_Si.HeaderText = "Side";
            this.T_Si.Name = "T_Si";
            this.T_Si.ReadOnly = true;
            // 
            // T_Ty
            // 
            this.T_Ty.HeaderText = "OrderType";
            this.T_Ty.Name = "T_Ty";
            this.T_Ty.ReadOnly = true;
            // 
            // T_Qt
            // 
            this.T_Qt.HeaderText = "Quantity";
            this.T_Qt.Name = "T_Qt";
            this.T_Qt.ReadOnly = true;
            // 
            // T_Pri
            // 
            this.T_Pri.HeaderText = "Price";
            this.T_Pri.Name = "T_Pri";
            this.T_Pri.ReadOnly = true;
            // 
            // col_Ti
            // 
            this.col_Ti.HeaderText = "Time";
            this.col_Ti.Name = "col_Ti";
            this.col_Ti.ReadOnly = true;
            // 
            // T_Statu
            // 
            this.T_Statu.HeaderText = "Status";
            this.T_Statu.Name = "T_Statu";
            this.T_Statu.ReadOnly = true;
            // 
            // T_OMSO
            // 
            this.T_OMSO.HeaderText = "OMS ID";
            this.T_OMSO.Name = "T_OMSO";
            this.T_OMSO.ReadOnly = true;
            // 
            // KryptonPositionDataGrid
            // 
            this.KryptonPositionDataGrid.AllowUserToAddRows = false;
            this.KryptonPositionDataGrid.AllowUserToDeleteRows = false;
            this.KryptonPositionDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonPositionDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.P_Symbol,
            this.P_qty,
            this.P_Privi,
            this.P_LTP,
            this.P_Mtm,
            this.P_Change});
            this.KryptonPositionDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonPositionDataGrid.Location = new System.Drawing.Point(0, 0);
            this.KryptonPositionDataGrid.Name = "KryptonPositionDataGrid";
            this.KryptonPositionDataGrid.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.KryptonPositionDataGrid.ReadOnly = true;
            this.KryptonPositionDataGrid.RowHeadersVisible = false;
            this.KryptonPositionDataGrid.Size = new System.Drawing.Size(1368, 483);
            this.KryptonPositionDataGrid.TabIndex = 11;
            // 
            // P_Symbol
            // 
            this.P_Symbol.HeaderText = "Symbol";
            this.P_Symbol.Name = "P_Symbol";
            this.P_Symbol.ReadOnly = true;
            // 
            // P_qty
            // 
            this.P_qty.HeaderText = "Quantity";
            this.P_qty.Name = "P_qty";
            this.P_qty.ReadOnly = true;
            // 
            // P_Privi
            // 
            this.P_Privi.HeaderText = "PriviousClose";
            this.P_Privi.Name = "P_Privi";
            this.P_Privi.ReadOnly = true;
            // 
            // P_LTP
            // 
            this.P_LTP.HeaderText = "LTP";
            this.P_LTP.Name = "P_LTP";
            this.P_LTP.ReadOnly = true;
            // 
            // P_Mtm
            // 
            this.P_Mtm.HeaderText = "MTM";
            this.P_Mtm.Name = "P_Mtm";
            this.P_Mtm.ReadOnly = true;
            // 
            // P_Change
            // 
            this.P_Change.HeaderText = "% Change";
            this.P_Change.Name = "P_Change";
            this.P_Change.ReadOnly = true;
            // 
            // KryptonDataGridView4
            // 
            this.KryptonDataGridView4.AllowUserToAddRows = false;
            this.KryptonDataGridView4.AllowUserToDeleteRows = false;
            this.KryptonDataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonDataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDataGridView4.Location = new System.Drawing.Point(0, 0);
            this.KryptonDataGridView4.Name = "KryptonDataGridView4";
            this.KryptonDataGridView4.ReadOnly = true;
            this.KryptonDataGridView4.Size = new System.Drawing.Size(1368, 483);
            this.KryptonDataGridView4.TabIndex = 9;
            // 
            // KryptonDataGridView5
            // 
            this.KryptonDataGridView5.AllowUserToAddRows = false;
            this.KryptonDataGridView5.AllowUserToDeleteRows = false;
            this.KryptonDataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KryptonDataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDataGridView5.Location = new System.Drawing.Point(0, 0);
            this.KryptonDataGridView5.Name = "KryptonDataGridView5";
            this.KryptonDataGridView5.ReadOnly = true;
            this.KryptonDataGridView5.Size = new System.Drawing.Size(1368, 517);
            this.KryptonDataGridView5.TabIndex = 26;
            // 
            // KryptonDockableNavigator2
            // 
            this.KryptonDockableNavigator2.AllowPageReorder = false;
            this.KryptonDockableNavigator2.Bar.ItemSizing = ComponentFactory.Krypton.Navigator.BarItemSizing.SameWidthAndHeight;
            this.KryptonDockableNavigator2.Button.ButtonDisplayLogic = ComponentFactory.Krypton.Navigator.ButtonDisplayLogic.None;
            this.KryptonDockableNavigator2.Button.CloseButtonAction = ComponentFactory.Krypton.Navigator.CloseButtonAction.None;
            this.KryptonDockableNavigator2.Button.CloseButtonDisplay = ComponentFactory.Krypton.Navigator.ButtonDisplay.Hide;
            this.KryptonDockableNavigator2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonDockableNavigator2.Location = new System.Drawing.Point(0, 0);
            this.KryptonDockableNavigator2.Name = "KryptonDockableNavigator2";
            this.KryptonDockableNavigator2.Size = new System.Drawing.Size(1011, 245);
            this.KryptonDockableNavigator2.TabIndex = 10;
            this.KryptonDockableNavigator2.Text = "KryptonDockableNavigator2";
            // 
            // kryptonDockableNavigator3
            // 
            this.kryptonDockableNavigator3.AllowPageReorder = false;
            this.kryptonDockableNavigator3.Bar.CheckButtonStyle = ComponentFactory.Krypton.Toolkit.ButtonStyle.FormClose;
            this.kryptonDockableNavigator3.Bar.TabBorderStyle = ComponentFactory.Krypton.Toolkit.TabBorderStyle.SlantEqualNear;
            this.kryptonDockableNavigator3.Bar.TabStyle = ComponentFactory.Krypton.Toolkit.TabStyle.Dock;
            this.kryptonDockableNavigator3.Button.CloseButtonAction = ComponentFactory.Krypton.Navigator.CloseButtonAction.None;
            this.kryptonDockableNavigator3.Button.CloseButtonDisplay = ComponentFactory.Krypton.Navigator.ButtonDisplay.Hide;
            this.kryptonDockableNavigator3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonDockableNavigator3.Group.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderCustom1;
            this.kryptonDockableNavigator3.Group.GroupBorderStyle = ComponentFactory.Krypton.Toolkit.PaletteBorderStyle.HeaderForm;
            this.kryptonDockableNavigator3.Header.HeaderPositionBar = ComponentFactory.Krypton.Toolkit.VisualOrientation.Bottom;
            this.kryptonDockableNavigator3.Location = new System.Drawing.Point(0, 66);
            this.kryptonDockableNavigator3.Name = "kryptonDockableNavigator3";
            this.kryptonDockableNavigator3.NavigatorMode = ComponentFactory.Krypton.Navigator.NavigatorMode.HeaderBarCheckButtonGroup;
            this.kryptonDockableNavigator3.PageBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonGallery;
            this.kryptonDockableNavigator3.Pages.AddRange(new ComponentFactory.Krypton.Navigator.KryptonPage[] {
            this.kryptonPage7,
            this.kryptonPage8,
            this.kryptonPage13,
            this.kryptonPage14,
            this.kryptonPage15,
            this.kryptonPage18,
            this.kryptonPage16});
            this.kryptonDockableNavigator3.SelectedIndex = 5;
            this.kryptonDockableNavigator3.Size = new System.Drawing.Size(1370, 548);
            this.kryptonDockableNavigator3.TabIndex = 34;
            this.kryptonDockableNavigator3.Text = "kryptonDockableNavigator3";
            // 
            // kryptonPage7
            // 
            this.kryptonPage7.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage7.Controls.Add(this.kryptonPanel11);
            this.kryptonPage7.Controls.Add(this.KryptonMarketWatch);
            this.kryptonPage7.Flags = 65534;
            this.kryptonPage7.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage7.ImageSmall")));
            this.kryptonPage7.LastVisibleSet = true;
            this.kryptonPage7.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage7.Name = "kryptonPage7";
            this.kryptonPage7.Size = new System.Drawing.Size(1368, 517);
            this.kryptonPage7.Text = "Market Watch";
            this.kryptonPage7.ToolTipTitle = "Page ToolTip";
            this.kryptonPage7.UniqueName = "D4E80BFB45E540864DAD9CD84BB101AE";
            // 
            // kryptonPanel11
            // 
            this.kryptonPanel11.Controls.Add(this.label6);
            this.kryptonPanel11.Controls.Add(this.label5);
            this.kryptonPanel11.Controls.Add(this.label4);
            this.kryptonPanel11.Controls.Add(this.txtAdd);
            this.kryptonPanel11.Controls.Add(this.KryptonEXCHNAGE);
            this.kryptonPanel11.Controls.Add(this.KryptonINTRUMENT);
            this.kryptonPanel11.Controls.Add(this.KryptonSEGMENT);
            this.kryptonPanel11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel11.Location = new System.Drawing.Point(0, 463);
            this.kryptonPanel11.Name = "kryptonPanel11";
            this.kryptonPanel11.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel11.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2007Black;
            this.kryptonPanel11.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ControlGroupBox;
            this.kryptonPanel11.Size = new System.Drawing.Size(1368, 54);
            this.kryptonPanel11.TabIndex = 22;
            // 
            // kryptonPage8
            // 
            this.kryptonPage8.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage8.Controls.Add(this.kryptonPanel8);
            this.kryptonPage8.Controls.Add(this.KryptonPendingOB);
            this.kryptonPage8.Flags = 65534;
            this.kryptonPage8.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage8.ImageSmall")));
            this.kryptonPage8.LastVisibleSet = true;
            this.kryptonPage8.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage8.Name = "kryptonPage8";
            this.kryptonPage8.Size = new System.Drawing.Size(1368, 517);
            this.kryptonPage8.Text = "Order Book";
            this.kryptonPage8.ToolTipTitle = "Page ToolTip";
            this.kryptonPage8.UniqueName = "4842924DA2D14EC7B483C7C2593C1DB9";
            // 
            // kryptonPanel8
            // 
            this.kryptonPanel8.Controls.Add(this.txtClientIDOrderBook);
            this.kryptonPanel8.Controls.Add(this.OrderBookRefresh);
            this.kryptonPanel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel8.Location = new System.Drawing.Point(0, 487);
            this.kryptonPanel8.Name = "kryptonPanel8";
            this.kryptonPanel8.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel8.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.kryptonPanel8.Size = new System.Drawing.Size(1368, 30);
            this.kryptonPanel8.TabIndex = 21;
            // 
            // txtClientIDOrderBook
            // 
            this.txtClientIDOrderBook.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtClientIDOrderBook.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtClientIDOrderBook.DropDownWidth = 67;
            this.txtClientIDOrderBook.Location = new System.Drawing.Point(3, 4);
            this.txtClientIDOrderBook.Name = "txtClientIDOrderBook";
            this.txtClientIDOrderBook.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtClientIDOrderBook.Size = new System.Drawing.Size(171, 21);
            this.txtClientIDOrderBook.TabIndex = 4;
            // 
            // OrderBookRefresh
            // 
            this.OrderBookRefresh.Location = new System.Drawing.Point(180, 4);
            this.OrderBookRefresh.Name = "OrderBookRefresh";
            this.OrderBookRefresh.Size = new System.Drawing.Size(104, 24);
            this.OrderBookRefresh.TabIndex = 1;
            this.OrderBookRefresh.Values.Text = "Get Order Book";
            this.OrderBookRefresh.Click += new System.EventHandler(this.kryptonButton5_Click_1);
            // 
            // kryptonPage13
            // 
            this.kryptonPage13.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage13.Controls.Add(this.kryptonPanel4);
            this.kryptonPage13.Controls.Add(this.KryptonTradeBook);
            this.kryptonPage13.Flags = 65534;
            this.kryptonPage13.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage13.ImageSmall")));
            this.kryptonPage13.LastVisibleSet = true;
            this.kryptonPage13.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage13.Name = "kryptonPage13";
            this.kryptonPage13.Size = new System.Drawing.Size(1368, 517);
            this.kryptonPage13.Text = "Trade Book";
            this.kryptonPage13.ToolTipTitle = "Page ToolTip";
            this.kryptonPage13.UniqueName = "96713E1B817041D2F88BEF5B1D475E3B";
            // 
            // kryptonPanel4
            // 
            this.kryptonPanel4.Controls.Add(this.txtClientIDTradeBook);
            this.kryptonPanel4.Controls.Add(this.btnTradeBook);
            this.kryptonPanel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel4.Location = new System.Drawing.Point(0, 487);
            this.kryptonPanel4.Name = "kryptonPanel4";
            this.kryptonPanel4.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel4.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.kryptonPanel4.Size = new System.Drawing.Size(1368, 30);
            this.kryptonPanel4.TabIndex = 24;
            // 
            // txtClientIDTradeBook
            // 
            this.txtClientIDTradeBook.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtClientIDTradeBook.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtClientIDTradeBook.DropDownWidth = 67;
            this.txtClientIDTradeBook.Location = new System.Drawing.Point(3, 4);
            this.txtClientIDTradeBook.Name = "txtClientIDTradeBook";
            this.txtClientIDTradeBook.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtClientIDTradeBook.Size = new System.Drawing.Size(171, 21);
            this.txtClientIDTradeBook.TabIndex = 4;
            // 
            // btnTradeBook
            // 
            this.btnTradeBook.Location = new System.Drawing.Point(180, 4);
            this.btnTradeBook.Name = "btnTradeBook";
            this.btnTradeBook.Size = new System.Drawing.Size(104, 24);
            this.btnTradeBook.TabIndex = 1;
            this.btnTradeBook.Values.Text = "Get Trade Book";
            this.btnTradeBook.Click += new System.EventHandler(this.btnTradeBook_Click);
            // 
            // kryptonPage14
            // 
            this.kryptonPage14.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage14.Controls.Add(this.kryptonPanel9);
            this.kryptonPage14.Controls.Add(this.KryptonPositionDataGrid);
            this.kryptonPage14.Flags = 65534;
            this.kryptonPage14.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage14.ImageSmall")));
            this.kryptonPage14.LastVisibleSet = true;
            this.kryptonPage14.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage14.Name = "kryptonPage14";
            this.kryptonPage14.Size = new System.Drawing.Size(1368, 483);
            this.kryptonPage14.Text = "Positions";
            this.kryptonPage14.ToolTipTitle = "Page ToolTip";
            this.kryptonPage14.UniqueName = "FF0391ADAAC342FA21BEA0E9395EFEE0";
            // 
            // kryptonPanel9
            // 
            this.kryptonPanel9.Controls.Add(this.btnPosHistorical);
            this.kryptonPanel9.Controls.Add(this.txtClientIDPosition);
            this.kryptonPanel9.Controls.Add(this.btnPosLive);
            this.kryptonPanel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel9.Location = new System.Drawing.Point(0, 453);
            this.kryptonPanel9.Name = "kryptonPanel9";
            this.kryptonPanel9.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel9.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.kryptonPanel9.Size = new System.Drawing.Size(1368, 30);
            this.kryptonPanel9.TabIndex = 22;
            // 
            // btnPosHistorical
            // 
            this.btnPosHistorical.Location = new System.Drawing.Point(290, 6);
            this.btnPosHistorical.Name = "btnPosHistorical";
            this.btnPosHistorical.Size = new System.Drawing.Size(104, 24);
            this.btnPosHistorical.TabIndex = 5;
            this.btnPosHistorical.Values.Text = "Historical";
            this.btnPosHistorical.Click += new System.EventHandler(this.btnPosHistorical_Click);
            // 
            // txtClientIDPosition
            // 
            this.txtClientIDPosition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtClientIDPosition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtClientIDPosition.DropDownWidth = 67;
            this.txtClientIDPosition.Location = new System.Drawing.Point(3, 4);
            this.txtClientIDPosition.Name = "txtClientIDPosition";
            this.txtClientIDPosition.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtClientIDPosition.Size = new System.Drawing.Size(171, 21);
            this.txtClientIDPosition.TabIndex = 4;
            // 
            // btnPosLive
            // 
            this.btnPosLive.Location = new System.Drawing.Point(180, 4);
            this.btnPosLive.Name = "btnPosLive";
            this.btnPosLive.Size = new System.Drawing.Size(104, 24);
            this.btnPosLive.TabIndex = 1;
            this.btnPosLive.Values.Text = "Live";
            this.btnPosLive.Click += new System.EventHandler(this.btnPosLive_Click);
            // 
            // kryptonPage15
            // 
            this.kryptonPage15.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage15.Controls.Add(this.kryptonPanel7);
            this.kryptonPage15.Controls.Add(this.kryptonHolding);
            this.kryptonPage15.Controls.Add(this.KryptonDataGridView4);
            this.kryptonPage15.Flags = 65534;
            this.kryptonPage15.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage15.ImageSmall")));
            this.kryptonPage15.LastVisibleSet = true;
            this.kryptonPage15.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage15.Name = "kryptonPage15";
            this.kryptonPage15.Size = new System.Drawing.Size(1368, 483);
            this.kryptonPage15.Text = "Holdings";
            this.kryptonPage15.ToolTipTitle = "Page ToolTip";
            this.kryptonPage15.UniqueName = "0A401C869D8341727F81532CE58E4713";
            this.kryptonPage15.Click += new System.EventHandler(this.kryptonPage15_Click);
            // 
            // kryptonPanel7
            // 
            this.kryptonPanel7.Controls.Add(this.txtClientIDHoldings);
            this.kryptonPanel7.Controls.Add(this.btnHoldings);
            this.kryptonPanel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel7.Location = new System.Drawing.Point(0, 453);
            this.kryptonPanel7.Name = "kryptonPanel7";
            this.kryptonPanel7.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel7.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.kryptonPanel7.Size = new System.Drawing.Size(1368, 30);
            this.kryptonPanel7.TabIndex = 25;
            // 
            // txtClientIDHoldings
            // 
            this.txtClientIDHoldings.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtClientIDHoldings.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtClientIDHoldings.DropDownWidth = 67;
            this.txtClientIDHoldings.Location = new System.Drawing.Point(3, 4);
            this.txtClientIDHoldings.Name = "txtClientIDHoldings";
            this.txtClientIDHoldings.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.SparklePurple;
            this.txtClientIDHoldings.Size = new System.Drawing.Size(171, 21);
            this.txtClientIDHoldings.TabIndex = 4;
            // 
            // btnHoldings
            // 
            this.btnHoldings.Location = new System.Drawing.Point(180, 4);
            this.btnHoldings.Name = "btnHoldings";
            this.btnHoldings.Size = new System.Drawing.Size(104, 24);
            this.btnHoldings.TabIndex = 1;
            this.btnHoldings.Values.Text = "Get Holdings";
            this.btnHoldings.Click += new System.EventHandler(this.btnHoldings_Click);
            // 
            // kryptonHolding
            // 
            this.kryptonHolding.AllowUserToAddRows = false;
            this.kryptonHolding.AllowUserToDeleteRows = false;
            this.kryptonHolding.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kryptonHolding.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.kryptonHolding.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonHolding.Location = new System.Drawing.Point(0, 0);
            this.kryptonHolding.Name = "kryptonHolding";
            this.kryptonHolding.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.kryptonHolding.ReadOnly = true;
            this.kryptonHolding.RowHeadersVisible = false;
            this.kryptonHolding.Size = new System.Drawing.Size(1368, 483);
            this.kryptonHolding.TabIndex = 12;
            this.kryptonHolding.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.kryptonHolding_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Symbol";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "PriviousClose";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "LTP";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "MTM";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "% Change";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // kryptonPage18
            // 
            this.kryptonPage18.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage18.Controls.Add(this.Panel1);
            this.kryptonPage18.Flags = 65534;
            this.kryptonPage18.ImageSmall = ((System.Drawing.Image)(resources.GetObject("kryptonPage18.ImageSmall")));
            this.kryptonPage18.LastVisibleSet = true;
            this.kryptonPage18.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage18.Name = "kryptonPage18";
            this.kryptonPage18.Size = new System.Drawing.Size(1368, 517);
            this.kryptonPage18.Text = "OHLC";
            this.kryptonPage18.ToolTipTitle = "Page ToolTip";
            this.kryptonPage18.UniqueName = "446DDDF95C6D44496E9E497A338472E2";
            this.kryptonPage18.Click += new System.EventHandler(this.kryptonPage18_Click);
            // 
            // kryptonPage16
            // 
            this.kryptonPage16.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage16.Controls.Add(this.kryptonPanel12);
            this.kryptonPage16.Controls.Add(this.allTrades);
            this.kryptonPage16.Controls.Add(this.KryptonDataGridView5);
            this.kryptonPage16.Flags = 65534;
            this.kryptonPage16.LastVisibleSet = true;
            this.kryptonPage16.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage16.Name = "kryptonPage16";
            this.kryptonPage16.Size = new System.Drawing.Size(1368, 517);
            this.kryptonPage16.Text = "All Trades";
            this.kryptonPage16.ToolTipTitle = "Page ToolTip";
            this.kryptonPage16.UniqueName = "AF541D9A07C24668FC85226081D9B21D";
            // 
            // kryptonPanel12
            // 
            this.kryptonPanel12.Controls.Add(this.kryptonButton1);
            this.kryptonPanel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonPanel12.Location = new System.Drawing.Point(0, 487);
            this.kryptonPanel12.Name = "kryptonPanel12";
            this.kryptonPanel12.Padding = new System.Windows.Forms.Padding(3);
            this.kryptonPanel12.PanelBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.HeaderForm;
            this.kryptonPanel12.Size = new System.Drawing.Size(1368, 30);
            this.kryptonPanel12.TabIndex = 28;
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Location = new System.Drawing.Point(6, 3);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.Size = new System.Drawing.Size(104, 24);
            this.kryptonButton1.TabIndex = 1;
            this.kryptonButton1.Values.Text = "Get Trade Book";
            this.kryptonButton1.Click += new System.EventHandler(this.kryptonButton1_Click_1);
            // 
            // allTrades
            // 
            this.allTrades.AllowUserToAddRows = false;
            this.allTrades.AllowUserToDeleteRows = false;
            this.allTrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.allTrades.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.allTrades.Dock = System.Windows.Forms.DockStyle.Fill;
            this.allTrades.Location = new System.Drawing.Point(0, 0);
            this.allTrades.Name = "allTrades";
            this.allTrades.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Black;
            this.allTrades.ReadOnly = true;
            this.allTrades.RowHeadersVisible = false;
            this.allTrades.Size = new System.Drawing.Size(1368, 517);
            this.allTrades.TabIndex = 27;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridViewTextBoxColumn7.HeaderText = "Symbol";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn8.HeaderText = "Side";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "OrderType";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Price";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Time";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Status";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "OMS ID";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // RichUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.kryptonDockableNavigator3);
            this.Controls.Add(this.KryptonDataGridView7);
            this.Controls.Add(this.KryptonDataGridView8);
            this.Controls.Add(this.KryptonDataGridView9);
            this.Controls.Add(this.KryptonPanel5);
            this.Controls.Add(this.KryptonPanel2);
            this.Controls.Add(this.KryptonPanel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RichUI";
            this.Text = "OHLC";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OptionPage)).EndInit();
            this.Panel1.ResumeLayout(false);
            this.TopBottomSplit.Panel1.ResumeLayout(false);
            this.TopBottomSplit.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TopBottomSplit)).EndInit();
            this.TopBottomSplit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel6)).EndInit();
            this.kryptonPanel6.ResumeLayout(false);
            this.GrpCandleJC.ResumeLayout(false);
            this.GrpCandleJC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNLow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNhigh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBlow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBhigh)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel10)).EndInit();
            this.kryptonPanel10.ResumeLayout(false);
            this.kryptonPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeleteClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDeleteScript)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScript)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSClientSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CandleJC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoplossCandleJC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttargetCandleJC)).EndInit();
            this.ContextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonINTRUMENT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSEGMENT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonEXCHNAGE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel5)).EndInit();
            this.KryptonPanel5.ResumeLayout(false);
            this.KryptonPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPendingOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel2)).EndInit();
            this.KryptonPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel1)).EndInit();
            this.KryptonPanel1.ResumeLayout(false);
            this.KryptonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPanel3)).EndInit();
            this.KryptonPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDockableNavigator1)).EndInit();
            this.KryptonDockableNavigator1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPage6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonMarketWatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonTradeBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonPositionDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonDockableNavigator2)).EndInit();
            this.KryptonDockableNavigator2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonDockableNavigator3)).EndInit();
            this.kryptonDockableNavigator3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage7)).EndInit();
            this.kryptonPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel11)).EndInit();
            this.kryptonPanel11.ResumeLayout(false);
            this.kryptonPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage8)).EndInit();
            this.kryptonPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel8)).EndInit();
            this.kryptonPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDOrderBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage13)).EndInit();
            this.kryptonPage13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).EndInit();
            this.kryptonPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDTradeBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage14)).EndInit();
            this.kryptonPage14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel9)).EndInit();
            this.kryptonPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage15)).EndInit();
            this.kryptonPage15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).EndInit();
            this.kryptonPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtClientIDHoldings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHolding)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage18)).EndInit();
            this.kryptonPage18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage16)).EndInit();
            this.kryptonPage16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel12)).EndInit();
            this.kryptonPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.allTrades)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems7;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems8;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems11;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems9;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuHelp;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems3;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem14;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem22;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem23;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem15;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuTools;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems4;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem16;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem17;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem18;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem19;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem21;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuOrder;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems2;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem10;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem11;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem13;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem12;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuFile;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems1;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem1;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem5;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem6;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem7;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem8;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem9;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonDataGridView7;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuCommon;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems KryptonContextMenuItems5;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem20;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonDataGridView8;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonDataGridView9;
        internal ComponentFactory.Krypton.Navigator.KryptonPage OptionPage;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton KryptonButton2;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnStart;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton txtAdd;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox KryptonINTRUMENT;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox KryptonSEGMENT;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox KryptonEXCHNAGE;
        internal System.Windows.Forms.SaveFileDialog SaveFileDialog1;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems6;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems10;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems12;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel KryptonPanel5;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuOrderBook;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems13;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem SimpleToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems14;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ModifyToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem CancelToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem OCOToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems15;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ModifyEntryToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem CancelEntryOrderToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ModifyTargetToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ModifyStoplossToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ExitToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem COToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems16;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem CancelEntryToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ModifyStoplossToolStripMenuItem1;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ExitToolStripMenuItem1;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ExportOrderBookMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuMarketWatch;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems17;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem2;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem3;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem KryptonContextMenuItem4;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage2;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonPendingOB;
        internal System.Windows.Forms.ToolStripMenuItem AddStrategyToolStripMenuItem;
        internal System.Windows.Forms.ContextMenuStrip ContextMenuStrip1;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel KryptonPanel2;
        internal ComponentFactory.Krypton.Toolkit.KryptonRichTextBox KryptonRichConfirmationPanel;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel KryptonPanel3;
        internal ComponentFactory.Krypton.Docking.KryptonDockableNavigator KryptonDockableNavigator1;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage1;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage9;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage3;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenu KryptonContextMenuPositions;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems18;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ExitPositionToolStripMenuItem;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItem ExportPositionsMenuItem;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage4;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage5;
        internal ComponentFactory.Krypton.Navigator.KryptonPage KryptonPage6;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonMarketWatch;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonTradeBook;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonPositionDataGrid;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonDataGridView4;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView KryptonDataGridView5;
        internal ComponentFactory.Krypton.Docking.KryptonDockableNavigator KryptonDockableNavigator2;
        internal ComponentFactory.Krypton.Toolkit.KryptonContextMenuItems kryptonContextMenuItems19;
        internal ComponentFactory.Krypton.Docking.KryptonDockableNavigator kryptonDockableNavigator3;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage7;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage8;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage13;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage14;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage15;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage16;
        //internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage17;
        internal ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage18;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel KryptonPanel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Symbol;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Side;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Time;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_OMS;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Sym;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Si;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Ty;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Qt;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Pri;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Ti;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_Statu;
        private System.Windows.Forms.DataGridViewTextBoxColumn T_OMSO;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_Symbol;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_Privi;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_LTP;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_Mtm;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_Change;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView kryptonHolding;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel8;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton OrderBookRefresh;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Token;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Exe;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Sym;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_LTP;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Ltq;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Bid;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_BidQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Ask;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_AskQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Open;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_High;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Low;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Close;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Atp;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_Volumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_LastUTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn V_LastTTime;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtClientIDOrderBook;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel4;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtClientIDTradeBook;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnTradeBook;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel9;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnPosHistorical;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtClientIDPosition;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnPosLive;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel7;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtClientIDHoldings;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnHoldings;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer TopBottomSplit;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel6;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel10;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnLoadClientwise;
        private System.Windows.Forms.Label label14;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtSClientSelect;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel11;
        private System.Windows.Forms.Label label15;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtScript;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnScript;
        private System.Windows.Forms.Label label18;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton5;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnDeleteClient;
        private System.Windows.Forms.Label label25;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtDeleteClient;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnDeletescript;
        private System.Windows.Forms.Label label24;
        internal ComponentFactory.Krypton.Toolkit.KryptonComboBox txtDeleteScript;
        internal System.Windows.Forms.Panel Panel1;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnUpdate;
        private System.Windows.Forms.GroupBox GrpCandleJC;
        private System.Windows.Forms.Label txtCurrentPLORB;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown txtstoplossCandleJC;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown txttargetCandleJC;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnStartCandleJC;
        private System.Windows.Forms.Button btnAddCandleJC;
        private System.Windows.Forms.DateTimePicker txt_SqTimeORB;
        private System.Windows.Forms.DateTimePicker txt_EndTimeORB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label19;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView DGV_CandleJC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker txtstartTimeORB;
        private System.Windows.Forms.Label txtClientCount;
        internal ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel12;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton1;
        internal ComponentFactory.Krypton.Toolkit.KryptonDataGridView allTrades;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.Label label8;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnSubscribe;
        private System.Windows.Forms.NumericUpDown txtBhigh;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown txtNLow;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown txtNhigh;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown txtBlow;
        private System.Windows.Forms.Label label13;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton Update;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label2;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnReadCSV;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_sid;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_start;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_acc;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_EntryC;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Trail;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_status;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_token;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_symbol;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_symbolltp;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_high;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_open;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_low;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_targetPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_stoplossPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn o_PL;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_EndTime;
        internal ComponentFactory.Krypton.Toolkit.KryptonButton btnSendEmail;
    }
}
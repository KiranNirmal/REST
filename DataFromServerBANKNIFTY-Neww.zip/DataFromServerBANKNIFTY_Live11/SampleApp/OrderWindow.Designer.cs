﻿namespace BackTestUtilityApplication
{
    partial class OrderWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelOrderWindow = new System.Windows.Forms.GroupBox();
            this.cmb_Exchange = new System.Windows.Forms.ComboBox();
            this.btnADD = new System.Windows.Forms.Button();
            this.txtSymbol = new System.Windows.Forms.TextBox();
            this.lblExc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_Action = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDQty = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbOrdType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelOrderWindow.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.flowLayoutPanel1.Controls.Add(this.panelOrderWindow);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(645, 137);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // panelOrderWindow
            // 
            this.panelOrderWindow.Controls.Add(this.cmbOrdType);
            this.panelOrderWindow.Controls.Add(this.label6);
            this.panelOrderWindow.Controls.Add(this.txtDQty);
            this.panelOrderWindow.Controls.Add(this.label5);
            this.panelOrderWindow.Controls.Add(this.txtPrice);
            this.panelOrderWindow.Controls.Add(this.label4);
            this.panelOrderWindow.Controls.Add(this.txtQuantity);
            this.panelOrderWindow.Controls.Add(this.label3);
            this.panelOrderWindow.Controls.Add(this.cmb_Action);
            this.panelOrderWindow.Controls.Add(this.label2);
            this.panelOrderWindow.Controls.Add(this.cmb_Exchange);
            this.panelOrderWindow.Controls.Add(this.btnADD);
            this.panelOrderWindow.Controls.Add(this.txtSymbol);
            this.panelOrderWindow.Controls.Add(this.lblExc);
            this.panelOrderWindow.Controls.Add(this.label1);
            this.panelOrderWindow.Location = new System.Drawing.Point(3, 3);
            this.panelOrderWindow.Name = "panelOrderWindow";
            this.panelOrderWindow.Size = new System.Drawing.Size(638, 131);
            this.panelOrderWindow.TabIndex = 9;
            this.panelOrderWindow.TabStop = false;
            this.panelOrderWindow.Text = "Order Parameter";
            // 
            // cmb_Exchange
            // 
            this.cmb_Exchange.FormattingEnabled = true;
            this.cmb_Exchange.Items.AddRange(new object[] {
            "NSE",
            "NSE-OTH",
            "NSE-IND",
            "NSE-OPT",
            "NSE-FUT",
            "MCX"});
            this.cmb_Exchange.Location = new System.Drawing.Point(9, 53);
            this.cmb_Exchange.Name = "cmb_Exchange";
            this.cmb_Exchange.Size = new System.Drawing.Size(73, 21);
            this.cmb_Exchange.TabIndex = 0;
            this.cmb_Exchange.Text = "NSE";
            // 
            // btnADD
            // 
            this.btnADD.Location = new System.Drawing.Point(552, 90);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(75, 23);
            this.btnADD.TabIndex = 7;
            this.btnADD.Text = "Place";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // txtSymbol
            // 
            this.txtSymbol.Location = new System.Drawing.Point(186, 53);
            this.txtSymbol.Multiline = true;
            this.txtSymbol.Name = "txtSymbol";
            this.txtSymbol.Size = new System.Drawing.Size(119, 23);
            this.txtSymbol.TabIndex = 2;
            // 
            // lblExc
            // 
            this.lblExc.AutoSize = true;
            this.lblExc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExc.Location = new System.Drawing.Point(9, 27);
            this.lblExc.Name = "lblExc";
            this.lblExc.Size = new System.Drawing.Size(71, 15);
            this.lblExc.TabIndex = 4;
            this.lblExc.Text = "Exchange";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(183, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Symbol";
            // 
            // cmb_Action
            // 
            this.cmb_Action.FormattingEnabled = true;
            this.cmb_Action.Items.AddRange(new object[] {
            "BUY",
            "SELL"});
            this.cmb_Action.Location = new System.Drawing.Point(97, 53);
            this.cmb_Action.Name = "cmb_Action";
            this.cmb_Action.Size = new System.Drawing.Size(73, 21);
            this.cmb_Action.TabIndex = 1;
            this.cmb_Action.Text = "BUY";
            this.cmb_Action.SelectedValueChanged += new System.EventHandler(this.cmb_Action_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(97, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Action";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(320, 53);
            this.txtQuantity.Multiline = true;
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(61, 23);
            this.txtQuantity.TabIndex = 3;
            this.txtQuantity.Text = "0";
            this.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(317, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Quantity";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(396, 53);
            this.txtPrice.Multiline = true;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(61, 23);
            this.txtPrice.TabIndex = 4;
            this.txtPrice.Text = "0";
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(393, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "Price";
            // 
            // txtDQty
            // 
            this.txtDQty.Location = new System.Drawing.Point(472, 53);
            this.txtDQty.Multiline = true;
            this.txtDQty.Name = "txtDQty";
            this.txtDQty.Size = new System.Drawing.Size(61, 23);
            this.txtDQty.TabIndex = 5;
            this.txtDQty.Text = "0";
            this.txtDQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(469, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "D. Qty";
            // 
            // cmbOrdType
            // 
            this.cmbOrdType.FormattingEnabled = true;
            this.cmbOrdType.Items.AddRange(new object[] {
            "LIMIT",
            "MARKET"});
            this.cmbOrdType.Location = new System.Drawing.Point(552, 53);
            this.cmbOrdType.Name = "cmbOrdType";
            this.cmbOrdType.Size = new System.Drawing.Size(73, 21);
            this.cmbOrdType.TabIndex = 6;
            this.cmbOrdType.Text = "LIMIT";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(549, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Ord Type";
            // 
            // OrderWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 137);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "OrderWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Place Order";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelOrderWindow.ResumeLayout(false);
            this.panelOrderWindow.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox panelOrderWindow;
        private System.Windows.Forms.ComboBox cmb_Exchange;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.TextBox txtSymbol;
        private System.Windows.Forms.Label lblExc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_Action;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbOrdType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDQty;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label label3;
    }
}
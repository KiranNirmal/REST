﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Threading.Tasks;

namespace AutoLogin
{
    class Program
    {
        public static String BaseURL = "https://masterswift-beta.mastertrust.co.in";
        public static String loginURL = "/api/v1/user/login";
        public static String TwoFAuthURL = "/api/v1/user/twofa";
        public static String Host = "masterswift-beta.mastertrust.co.in";
        public static String OAuthAcessToken = "";
        public static String ClientID = "INV54-CHND";
        public static String password = "abc12345";
        public static String TFA = "2000";
        static void Main(string[] args)
        {
                CheckProfile();   
        }
        private static async void CheckProfile()
        {
            while (true)
            {
                try
                {
                    await CheckProfileNow();
                }
                catch (Exception fds)
                {
                    // sendmessage("Message:" + fds.StackTrace, 0);
                }
            }
        }
        private static async Task<string> CheckProfileNow()
        {

            var client = new RestClient(BaseURL + "/api/v1/user/profile?client_id=" + ClientID);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("x-device-type", "WEB");
            request.AddHeader("device", "WEB");
            request.AddHeader("x-authorization-token", OAuthAcessToken);
            request.AddHeader("Cookie", "_primus_web_key=SFMyNTY.g3QAAAABbQAAAAtfY3NyZl90b2tlbm0AAAAYRWxfd2JNcExqMWREbUlzQXhoLWNaUkEz.3Zb38UQLAOGF-GBiYzH4Xn8NYl9n4cE5JPC3tgkWK_Q; oauth2_authentication_csrf=MTU5MjMxMzYyNnxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREl3TnpVNFlUbGxNVEF6WmpRME5ETTVNMk5sWm1Zd1l6WTNPV1JqWkRsaHzTlRa9tY5-Tm2s-oRio9aENn5jNrGdbQEmSbgHfbyX6g==; oauth2_consent_csrf=MTU5MjMxMzY1MXxEdi1CQkFFQ180SUFBUkFCRUFBQVB2LUNBQUVHYzNSeWFXNW5EQVlBQkdOemNtWUdjM1J5YVc1bkRDSUFJREJqWlRjNVlUTXpaV1ZpTlRRNE9EUmlaRE13WXpKak5ETXhZemRrT0RVeXzestyu_FRn6ht7z-zHVgqp_a1w5ux6UqGKmBRORd6IoA==");
            IRestResponse response = client.Execute(request);
            dynamic data = JValue.Parse(response.Content);

            if (data.status.ToString() != "success")
            {
                Console.WriteLine("TOKEN INVALID:"+ OAuthAcessToken);
                Autologin(ClientID, password, TFA);
            }
            else
            {
               
            }
            await Task.Delay(10000);
            return DateTime.Now.Ticks.ToString();
        }

        private static void Autologin(string clientID, string password, string tFA)
        {
            var client = new RestClient(BaseURL + loginURL);
            var request = new RestRequest(Method.POST);
            request.AddHeader("x-device-type", "WEB");
            request.AddParameter("device", "WEB");
            request.AddParameter("login_id", clientID);
            request.AddParameter("password", password);
            IRestResponse response = client.Execute(request);
          
            String token = "";
            try
            {
                dynamic resp = JObject.Parse(response.Content);
                dynamic tokendata = resp.data;
                dynamic tokenObject = tokendata.twofa_token;
                token = tokenObject.Value;
                String FirstToken = token;

                client = new RestClient(BaseURL + TwoFAuthURL);
                request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("Connection", "keep-alive");
                request.AddHeader("Content-Length", "326");
                request.AddHeader("Accept-Encoding", "gzip, deflate");
                // request.AddHeader("Host", "masterswift-beta.mastertrust.co.in");
                request.AddHeader("Host", Host);

                request.AddHeader("Cache-Control", "no-cache");
                request.AddHeader("Accept", "*/*");
                request.AddHeader("User-Agent", "PostmanRuntime/7.20.1");
                request.AddHeader("X-Device-Type", "web");
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("undefined", "{\r\n    \"login_id\": \"" + clientID + "\",\r\n    \"twofa\": [\r\n        {\r\n            \"question_id\": 1,\r\n            \"answer\": \"" + TFA + "\"\r\n        }\r\n    ],\r\n    \"twofa_token\": \"" + FirstToken + "\"\r\n}", ParameterType.RequestBody);
                response = client.Execute(request);
                String Authtoken = "";
                try
                {
                    dynamic respNEW = JObject.Parse(response.Content);
                    dynamic tokendataNEW = respNEW.data;
                    dynamic authToken = tokendataNEW.auth_token;
                    Authtoken = authToken.Value;
                    String OAuthToken = Authtoken;
                    OAuthAcessToken = OAuthToken;
                    Console.WriteLine("NEW TOKEN :" + OAuthAcessToken);
                }
                catch (Exception egfd)
                {
                  
                }




            }
            catch (Exception efgh)
            {
                // MessageBox.Show("Invalid Client ID Or Password:");

            }
        }
    }
}
